﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using PhotoValidator.Models;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.IO;


namespace PhotoValidator.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class photoValidationController : ControllerBase
    {



        public static IWebHostEnvironment environment;
        public photoValidationController(IWebHostEnvironment env)
        {
            environment = env;
        }

       
        [HttpPost]
        public string Post([FromForm] Photo objphoto)
        {


            try
            {
                string fileName = string.Empty;
                string path = string.Empty;

                if (objphoto.file == null)
                { 
                    return "file not selected."; 
                }
                else if (objphoto.file.Length > 0)
                {

                    if (!Directory.Exists(environment.WebRootPath + "\\Upload\\"))
                    {
                        Directory.CreateDirectory(environment.WebRootPath + "\\Upload\\");
                    }

                    fileName = Guid.NewGuid() + Path.GetExtension(objphoto.file.FileName);
                    path = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\Upload"));

                    string fullpath = Path.Combine(path, fileName);

                    using (var image = Image.Load(objphoto.file.OpenReadStream()))
                    {
                        if(image.Width < 230 || image.Height < 240)
                        {
                            return false.ToString();
                        }
                        else
                        {
                            
                            string newsize = objphoto.GetPhotoResizeDimentions(image, 240, 320);
                            string[] sizearray = newsize.Split(',');
                            image.Mutate(x => x.Resize(Convert.ToInt32(sizearray[0]), Convert.ToInt32(sizearray[1])));
                            image.Save(fullpath);
                            PhotoValidationAPI photo = new PhotoValidationAPI();
                            Photo p = new Photo();
                            var result = photo.IsValid(fullpath).ToString();
                            p.DeleteFile(environment.WebRootPath + "\\Upload\\");

                            return result;

                        }
                    }

                }
                else
                {
                    return "Unexpected error occured please try again.";
                }
            }
            catch (Exception e)
            {

                return e.Message.ToString();
            }
        }
    }
}
