﻿using System.Collections.Generic;
using System.Drawing;
using VisioForge.Libs.Accord.Vision.Detection;
using VisioForge.Libs.Accord.Vision.Detection.Cascades;
using AForge.Imaging.Filters;
using System;

namespace PhotoValidator.Models
{
    public class AccordFaceDetector
    {
        public static List<Rectangle> DetectFaces(Bitmap image)
        {
            try
            {
                List<Rectangle> xfaces = new List<Rectangle>();
                HaarObjectDetector detector;
                detector = new HaarObjectDetector(new FaceHaarCascade(), 20, ObjectDetectorSearchMode.Average, 1.1f, ObjectDetectorScalingMode.SmallerToGreater);
                detector.UseParallelProcessing = true;
                detector.Suppression = 5;
                var grayImage = Grayscale.CommonAlgorithms.BT709.Apply(image);
                HistogramEqualization filter = new HistogramEqualization();
                filter.ApplyInPlace(grayImage);
                Rectangle[] faces = detector.ProcessFrame(grayImage);
                xfaces.AddRange(faces);
                return xfaces;
            }
            catch (Exception ex)
            {

                return new List<Rectangle>();
            }

        }
    }
 }

