﻿using Microsoft.AspNetCore.Http;
using SixLabors.ImageSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PhotoValidator.Models
{
    public class Photo
    {
        public IFormFile file { get; set; }

        public string GetPhotoResizeDimentions(Image img, int MaxWidth, int MaxHeight)
        {
            if (img.Width > MaxWidth || img.Height > MaxHeight)
            {
                double widthRatio = (double)img.Width / (double)MaxWidth;
                double heightRatio = (double)img.Height / (double)MaxHeight;
                double ratio = Math.Max(widthRatio, heightRatio);
                int newWidth = (int)(img.Width / ratio);
                int newHeight = (int)(img.Height / ratio);
                return newWidth + "," + newHeight;
            }
            else
            {
                return img.Width + "," + img.Height;

            }

        }
        public bool DeleteFile(string path)
        {
            try
            {
                
                foreach (string filename in Directory.GetFiles(path))
                {
                    File.Delete(filename);

                }
                
                return true;

            }
            catch (Exception ex)
            {

                return false;
            }

        }

    }
}
