﻿using Microsoft.AspNetCore.Http;
using System;
using System.Drawing;
using System.IO;
using System.Linq;

namespace PhotoValidator.Models
{
    public class PhotoValidationAPI
    {
        

        public bool IsValid(String path)
        {
            try
            {

                var Image = new Bitmap(path);
                int vote = 0;
                int score = 0;
                bool voteResult = false;


                if (Image.Width > Image.Height)
                {
                    return false;
                }
                else
                {
                    var faces = AccordFaceDetector.DetectFaces(Image);
                    var position = new Location();


                    if (faces.Count == 1)
                    {

                        var face = faces.FirstOrDefault<Rectangle>();
                        position.X = face.X;
                        position.Y = face.Y;
                        position.Width = face.Width;
                        position.Height = face.Height;

                        for (int i = 100; i < Image.Height - 100; i++)
                        {
                            vote = 0;

                            for (int j = 0; j < Image.Width; j++)
                            {
                                Color x = Image.GetPixel(i, j);

                                if (i > 20 && j == 70)
                                {
                                    j = Image.Width - 70;

                                }

                                if ((int)(x.R + x.G + x.B) >= 720)
                                {
                                    vote++;
                                }

                            }

                            if (vote >= 30)
                            {
                                score++;
                            }

                        }

                        if (score > 30)
                        {
                            voteResult = true;
                        }
                        else
                        {
                            voteResult = false;

                        }


                        if (position.Width < (Image.Width * 20) / 100 || position.Width > (Image.Width * 65) / 100 || position.Height < (Image.Height * 20) / 100 || position.Height > (Image.Height * 75) / 100 || voteResult != true)
                        {
                            return false;
                        }
                        else
                        {
                            return true;

                        }

                    }
                    else
                    {
                        return false;
                    }



                }

                

            }
            catch (Exception ex)
            {

                return false;
            }
        }

    }

}
