﻿using _Airport_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.User_Forms
{
    public partial class AddUser : Form
    {
        public AddUser()
        {
            InitializeComponent();
        }


        void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            cbDepartment.SelectedIndex = 0;
            cbWorkType.SelectedIndex = 0;
            cbUserType.SelectedIndex = 0;
            tbFullName.Clear();
            dtpFDate.Value = DateTime.Now;
            rbFemale.Checked = false;
            rbMale.Checked = false;
            tbAddress.Clear();
            mtbphonenum.Clear();
            tbEmail.Clear();
            tbPassword.Clear();
            tbConfirmPassword.Clear();

        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }
        void refreshDepartments()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Departments = db.Department.ToList();
                Departments.Add(new Department
                {
                    DeptName = "--Select--"

                });
                Departments.Reverse();
                cbDepartment.DisplayMember = "DeptName";
                cbDepartment.ValueMember = "DeptId";
                cbDepartment.DataSource = Departments;
                cbDepartment.Refresh();
            }
        }
        void refreshWorkTypes()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var WorkTypes = db.WorkType.ToList();
                WorkTypes.Add(new WorkType
                {
                    WorkName = "--Select--"

                });
                WorkTypes.Reverse();
                cbWorkType.DisplayMember = "WorkName";
                cbWorkType.ValueMember = "WorkTypeId";
                cbWorkType.DataSource = WorkTypes;
                cbWorkType.Refresh();
            }
        }

        void refreshUserTypes()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var UserTypes = db.UserType.ToList();
                UserTypes.Add(new UserType
                {
                    UserType1 = "--Select--"

                });
                UserTypes.Reverse();
                cbUserType.DisplayMember = "UserType1";
                cbUserType.ValueMember = "UserTypeId";
                cbUserType.DataSource = UserTypes;
                cbUserType.Refresh();
            }
        }
        private void AddUser_Load(object sender, EventArgs e)
        {
            refreshAirports();
            refreshDepartments();
            refreshWorkTypes();
            refreshUserTypes();
            LoadTheme();

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label6.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label2.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;
            label10.ForeColor = ThemeColor.SecondaryColor;
            label11.ForeColor = ThemeColor.SecondaryColor;
            label12.ForeColor = ThemeColor.SecondaryColor;
            label13.ForeColor = ThemeColor.SecondaryColor;
            label14.ForeColor = ThemeColor.SecondaryColor;
            rbMale.ForeColor = ThemeColor.SecondaryColor;
            rbFemale.ForeColor = ThemeColor.SecondaryColor;
            label1.ForeColor = ThemeColor.SecondaryColor;


        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbDepartment.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Department.";
                    cbDepartment.Focus();
                    return;
                }
                if (cbWorkType.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Work Type.";
                    cbWorkType.Focus();
                    return;
                }
                if (cbUserType.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select User Type.";
                    cbUserType.Focus();
                    return;
                }
                if (tbFullName.Text == "")
                {
                    lblMessage.Text = "Please Enter Full Name.";
                    tbFullName.Focus();
                    return;
                }
                if (tbFullName.Text.Trim().Length > 50)
                {

                    lblMessage.Text = "Full Name Can Be maximum 50 \r\nCharacters.";
                    tbFullName.Focus();
                    return;
                }
                if (!rbMale.Checked && !rbFemale.Checked)
                {
                    lblMessage.Text = "Please Select Gender.";
                    return;
                }
                if (tbAddress.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Address.";
                    tbAddress.Focus();
                    return;

                }
                if (tbAddress.Text.Trim().Length > 100)
                {

                    lblMessage.Text = "Address Can Be Maximum 100 \r\nCharacters.";
                    tbAddress.Focus();
                    return;

                }
                if (mtbphonenum.Text.Length == 10)
                {
                    lblMessage.Text = "Please Enter Phone Number.";
                    mtbphonenum.Focus();
                    return;
                }
                if (mtbphonenum.Text.Length < 14)
                {
                    lblMessage.Text = "Please Enter Valid Phone Number.";
                    mtbphonenum.Focus();
                    return;
                }
                if (tbEmail.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Email.";
                    tbEmail.Focus();
                    return;
                }
                if (!tbEmail.Text.Trim().Contains('@') && tbEmail.Text.Trim().Length < 6)
                {
                    lblMessage.Text = "Please Enter Valid Email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Trim().Length > 30)
                {

                    lblMessage.Text = "Email Can be Maximum 30 characters.";
                    tbEmail.Focus();
                    return;
                }
                if (tbPassword.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Password.";
                    tbPassword.Focus();
                    return;

                }
                if (tbPassword.Text.Trim().Length < 8 || tbPassword.Text.Trim().Length > 30)
                {

                    lblMessage.Text = "Password Must Be Between 8 And 30 \r\nCharacters.";
                    tbPassword.Focus();
                    return;

                }
                if (tbConfirmPassword.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Confirm Password.";
                    tbConfirmPassword.Focus();
                    return;

                }

                if (tbConfirmPassword.Text.Trim().Length < 8 || tbConfirmPassword.Text.Trim().Length > 50)
                {

                    lblMessage.Text = "Password Must Be Between 8 And 30 \r\nCharacters.";
                    tbConfirmPassword.Focus();
                    return;
                }
                if (tbPassword.Text.Trim() != tbConfirmPassword.Text.Trim())
                {
                    lblMessage.Text = "Passwords Is Not Match!";
                    tbConfirmPassword.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {

                    Users u = new Users();
                    u.AirportCode = cbAirportName.SelectedValue.ToString();
                    u.DeptId = int.Parse(cbDepartment.SelectedValue.ToString());
                    u.WorkTypeId = int.Parse(cbWorkType.SelectedValue.ToString());
                    u.UserTypeId = int.Parse(cbUserType.SelectedValue.ToString());
                    u.FullName = tbFullName.Text.Trim();
                    u.BirthDate = dtpFDate.Value.Date;
                    u.Gender = rbMale.Checked ? rbMale.Text : rbFemale.Text;
                    u.Address = tbAddress.Text.Trim();
                    u.PhoneNum = mtbphonenum.Text.Trim();
                    u.Email = tbEmail.Text.Trim();
                    u.Password = tbPassword.Text.Trim();
                    db.Users.Add(u);
                    db.SaveChanges();
                    MessageBox.Show("Registered Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                this.Close();
                LoadProfile.Titlelbl.Text = "Users Informations";

            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }


        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
            LoadProfile.Titlelbl.Text = "Users Informations";
        }
    }
}
