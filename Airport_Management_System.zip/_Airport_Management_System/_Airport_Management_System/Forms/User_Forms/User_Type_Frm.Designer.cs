﻿namespace _Airport_Management_System.Forms.User_Forms
{
    partial class User_Type_Frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User_Type_Frm));
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnedit = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.tbUserType = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbAll = new System.Windows.Forms.CheckBox();
            this.cbSettings = new System.Windows.Forms.CheckBox();
            this.cbPassengers = new System.Windows.Forms.CheckBox();
            this.cbSuppliers = new System.Windows.Forms.CheckBox();
            this.cbTickets = new System.Windows.Forms.CheckBox();
            this.cbFlights = new System.Windows.Forms.CheckBox();
            this.cbAirplanes = new System.Windows.Forms.CheckBox();
            this.cbAirlines = new System.Windows.Forms.CheckBox();
            this.cbTransportations = new System.Windows.Forms.CheckBox();
            this.cbLanding = new System.Windows.Forms.CheckBox();
            this.cbAirport = new System.Windows.Forms.CheckBox();
            this.dgvUsertypesList = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsertypesList)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbSearch
            // 
            this.tbSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSearch.Location = new System.Drawing.Point(908, 195);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(684, 34);
            this.tbSearch.TabIndex = 66;
            this.tbSearch.TextChanged += new System.EventHandler(this.tbSearch_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(785, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 31);
            this.label5.TabIndex = 65;
            this.label5.Text = "Search";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblMessage.Location = new System.Drawing.Point(262, 204);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 29);
            this.lblMessage.TabIndex = 64;
            // 
            // btncancel
            // 
            this.btncancel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btncancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btncancel.Enabled = false;
            this.btncancel.FlatAppearance.BorderSize = 0;
            this.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.ForeColor = System.Drawing.Color.White;
            this.btncancel.Location = new System.Drawing.Point(261, 1095);
            this.btncancel.Margin = new System.Windows.Forms.Padding(2);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(485, 65);
            this.btncancel.TabIndex = 62;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = false;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnedit
            // 
            this.btnedit.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnedit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnedit.Enabled = false;
            this.btnedit.FlatAppearance.BorderSize = 0;
            this.btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedit.ForeColor = System.Drawing.Color.White;
            this.btnedit.Location = new System.Drawing.Point(261, 999);
            this.btnedit.Margin = new System.Windows.Forms.Padding(2);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(485, 65);
            this.btnedit.TabIndex = 61;
            this.btnedit.Text = "Update";
            this.btnedit.UseVisualStyleBackColor = false;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // btnclear
            // 
            this.btnclear.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnclear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnclear.FlatAppearance.BorderSize = 0;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.White;
            this.btnclear.Location = new System.Drawing.Point(261, 904);
            this.btnclear.Margin = new System.Windows.Forms.Padding(2);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(485, 65);
            this.btnclear.TabIndex = 60;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnsave
            // 
            this.btnsave.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnsave.FlatAppearance.BorderSize = 0;
            this.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.Color.White;
            this.btnsave.Location = new System.Drawing.Point(261, 808);
            this.btnsave.Margin = new System.Windows.Forms.Padding(2);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(485, 65);
            this.btnsave.TabIndex = 59;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // tbUserType
            // 
            this.tbUserType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbUserType.Location = new System.Drawing.Point(264, 251);
            this.tbUserType.Name = "tbUserType";
            this.tbUserType.Size = new System.Drawing.Size(492, 34);
            this.tbUserType.TabIndex = 57;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(45, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 29);
            this.label4.TabIndex = 56;
            this.label4.Text = "Permissions :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(46, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 29);
            this.label3.TabIndex = 55;
            this.label3.Text = "User Type Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(28, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(453, 39);
            this.label2.TabIndex = 54;
            this.label2.Text = "Fill User Type Information :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbAll);
            this.panel1.Controls.Add(this.cbSettings);
            this.panel1.Controls.Add(this.cbPassengers);
            this.panel1.Controls.Add(this.cbSuppliers);
            this.panel1.Controls.Add(this.cbTickets);
            this.panel1.Controls.Add(this.cbFlights);
            this.panel1.Controls.Add(this.cbAirplanes);
            this.panel1.Controls.Add(this.cbAirlines);
            this.panel1.Controls.Add(this.cbTransportations);
            this.panel1.Controls.Add(this.cbLanding);
            this.panel1.Controls.Add(this.cbAirport);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(264, 321);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(488, 476);
            this.panel1.TabIndex = 67;
            // 
            // cbAll
            // 
            this.cbAll.AutoSize = true;
            this.cbAll.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbAll.Location = new System.Drawing.Point(0, 430);
            this.cbAll.Name = "cbAll";
            this.cbAll.Padding = new System.Windows.Forms.Padding(5);
            this.cbAll.Size = new System.Drawing.Size(488, 43);
            this.cbAll.TabIndex = 88;
            this.cbAll.Text = "All";
            this.cbAll.UseVisualStyleBackColor = true;
            this.cbAll.CheckedChanged += new System.EventHandler(this.cbAll_CheckedChanged);
            // 
            // cbSettings
            // 
            this.cbSettings.AutoSize = true;
            this.cbSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSettings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbSettings.Location = new System.Drawing.Point(0, 387);
            this.cbSettings.Name = "cbSettings";
            this.cbSettings.Padding = new System.Windows.Forms.Padding(5);
            this.cbSettings.Size = new System.Drawing.Size(488, 43);
            this.cbSettings.TabIndex = 87;
            this.cbSettings.Text = "Settings Management";
            this.cbSettings.UseVisualStyleBackColor = true;
            // 
            // cbPassengers
            // 
            this.cbPassengers.AutoSize = true;
            this.cbPassengers.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbPassengers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPassengers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbPassengers.Location = new System.Drawing.Point(0, 344);
            this.cbPassengers.Name = "cbPassengers";
            this.cbPassengers.Padding = new System.Windows.Forms.Padding(5);
            this.cbPassengers.Size = new System.Drawing.Size(488, 43);
            this.cbPassengers.TabIndex = 86;
            this.cbPassengers.Text = "Suppliers Management";
            this.cbPassengers.UseVisualStyleBackColor = true;
            // 
            // cbSuppliers
            // 
            this.cbSuppliers.AutoSize = true;
            this.cbSuppliers.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbSuppliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSuppliers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbSuppliers.Location = new System.Drawing.Point(0, 301);
            this.cbSuppliers.Name = "cbSuppliers";
            this.cbSuppliers.Padding = new System.Windows.Forms.Padding(5);
            this.cbSuppliers.Size = new System.Drawing.Size(488, 43);
            this.cbSuppliers.TabIndex = 85;
            this.cbSuppliers.Text = "Passengers Management";
            this.cbSuppliers.UseVisualStyleBackColor = true;
            // 
            // cbTickets
            // 
            this.cbTickets.AutoSize = true;
            this.cbTickets.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbTickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTickets.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbTickets.Location = new System.Drawing.Point(0, 258);
            this.cbTickets.Name = "cbTickets";
            this.cbTickets.Padding = new System.Windows.Forms.Padding(5);
            this.cbTickets.Size = new System.Drawing.Size(488, 43);
            this.cbTickets.TabIndex = 84;
            this.cbTickets.Text = "Tickets Management";
            this.cbTickets.UseVisualStyleBackColor = true;
            // 
            // cbFlights
            // 
            this.cbFlights.AutoSize = true;
            this.cbFlights.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbFlights.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbFlights.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbFlights.Location = new System.Drawing.Point(0, 215);
            this.cbFlights.Name = "cbFlights";
            this.cbFlights.Padding = new System.Windows.Forms.Padding(5);
            this.cbFlights.Size = new System.Drawing.Size(488, 43);
            this.cbFlights.TabIndex = 83;
            this.cbFlights.Text = "Flights Management";
            this.cbFlights.UseVisualStyleBackColor = true;
            // 
            // cbAirplanes
            // 
            this.cbAirplanes.AutoSize = true;
            this.cbAirplanes.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbAirplanes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAirplanes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbAirplanes.Location = new System.Drawing.Point(0, 172);
            this.cbAirplanes.Name = "cbAirplanes";
            this.cbAirplanes.Padding = new System.Windows.Forms.Padding(5);
            this.cbAirplanes.Size = new System.Drawing.Size(488, 43);
            this.cbAirplanes.TabIndex = 82;
            this.cbAirplanes.Text = "Airplanes Management";
            this.cbAirplanes.UseVisualStyleBackColor = true;
            // 
            // cbAirlines
            // 
            this.cbAirlines.AutoSize = true;
            this.cbAirlines.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbAirlines.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAirlines.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbAirlines.Location = new System.Drawing.Point(0, 129);
            this.cbAirlines.Name = "cbAirlines";
            this.cbAirlines.Padding = new System.Windows.Forms.Padding(5);
            this.cbAirlines.Size = new System.Drawing.Size(488, 43);
            this.cbAirlines.TabIndex = 81;
            this.cbAirlines.Text = "Airline Companies Management";
            this.cbAirlines.UseVisualStyleBackColor = true;
            // 
            // cbTransportations
            // 
            this.cbTransportations.AutoSize = true;
            this.cbTransportations.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbTransportations.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTransportations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbTransportations.Location = new System.Drawing.Point(0, 86);
            this.cbTransportations.Name = "cbTransportations";
            this.cbTransportations.Padding = new System.Windows.Forms.Padding(5);
            this.cbTransportations.Size = new System.Drawing.Size(488, 43);
            this.cbTransportations.TabIndex = 80;
            this.cbTransportations.Text = "Transportations Management";
            this.cbTransportations.UseVisualStyleBackColor = true;
            // 
            // cbLanding
            // 
            this.cbLanding.AutoSize = true;
            this.cbLanding.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbLanding.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbLanding.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbLanding.Location = new System.Drawing.Point(0, 43);
            this.cbLanding.Name = "cbLanding";
            this.cbLanding.Padding = new System.Windows.Forms.Padding(5);
            this.cbLanding.Size = new System.Drawing.Size(488, 43);
            this.cbLanding.TabIndex = 79;
            this.cbLanding.Text = "Landing Areas Management";
            this.cbLanding.UseVisualStyleBackColor = true;
            // 
            // cbAirport
            // 
            this.cbAirport.AutoSize = true;
            this.cbAirport.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbAirport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAirport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cbAirport.Location = new System.Drawing.Point(0, 0);
            this.cbAirport.Name = "cbAirport";
            this.cbAirport.Padding = new System.Windows.Forms.Padding(5);
            this.cbAirport.Size = new System.Drawing.Size(488, 43);
            this.cbAirport.TabIndex = 78;
            this.cbAirport.Text = "Airports Mangement";
            this.cbAirport.UseVisualStyleBackColor = true;
            // 
            // dgvUsertypesList
            // 
            this.dgvUsertypesList.AllowUserToAddRows = false;
            this.dgvUsertypesList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUsertypesList.BackgroundColor = System.Drawing.Color.White;
            this.dgvUsertypesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvUsertypesList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvUsertypesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsertypesList.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvUsertypesList.Location = new System.Drawing.Point(780, 250);
            this.dgvUsertypesList.Margin = new System.Windows.Forms.Padding(2);
            this.dgvUsertypesList.MultiSelect = false;
            this.dgvUsertypesList.Name = "dgvUsertypesList";
            this.dgvUsertypesList.ReadOnly = true;
            this.dgvUsertypesList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvUsertypesList.RowHeadersVisible = false;
            this.dgvUsertypesList.RowHeadersWidth = 82;
            this.dgvUsertypesList.RowTemplate.Height = 33;
            this.dgvUsertypesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUsertypesList.Size = new System.Drawing.Size(812, 961);
            this.dgvUsertypesList.TabIndex = 131;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 4000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(241, 84);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.editToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editToolStripMenuItem.Image")));
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.editToolStripMenuItem.Size = new System.Drawing.Size(240, 40);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.deleteToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("deleteToolStripMenuItem.Image")));
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(240, 40);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // User_Type_Frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1603, 1222);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.dgvUsertypesList);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbSearch);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.tbUserType);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "User_Type_Frm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.User_Type_Frm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsertypesList)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox tbUserType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cbAll;
        private System.Windows.Forms.CheckBox cbSettings;
        private System.Windows.Forms.CheckBox cbPassengers;
        private System.Windows.Forms.CheckBox cbSuppliers;
        private System.Windows.Forms.CheckBox cbTickets;
        private System.Windows.Forms.CheckBox cbFlights;
        private System.Windows.Forms.CheckBox cbAirplanes;
        private System.Windows.Forms.CheckBox cbAirlines;
        private System.Windows.Forms.CheckBox cbTransportations;
        private System.Windows.Forms.CheckBox cbLanding;
        private System.Windows.Forms.CheckBox cbAirport;
        private System.Windows.Forms.DataGridView dgvUsertypesList;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
    }
}