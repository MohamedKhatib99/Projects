﻿using _Airport_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.User_Forms
{
    public partial class Login_Frm : Form
    {

        public Login_Frm()
        {
            InitializeComponent();
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                db.Users.ToList();
            }

        }

        private void tbEmail_Enter(object sender, EventArgs e)
        {
            if(tbEmail.Text == "someone@example.com")
            {
                tbEmail.Text = "";
                tbEmail.ForeColor = Color.Black;

            }
        }

        private void tbEmail_Leave(object sender, EventArgs e)
        {
            if (tbEmail.Text == "")
            {
                tbEmail.Text = "someone@example.com";
                tbEmail.ForeColor = Color.Silver;

            }
        }
        private void tbPassword_Enter(object sender, EventArgs e)
        {
            if (tbPassword.Text == "Password")
            {
                tbPassword.Text = "";
                tbPassword.ForeColor = Color.Black;
                tbPassword.UseSystemPasswordChar = true;

            }
        }

        private void tbPassword_Leave(object sender, EventArgs e)
        {
            if (tbPassword.Text == "")
            {
                tbPassword.Text = "Password";
                tbPassword.ForeColor = Color.Silver;
                tbPassword.UseSystemPasswordChar = false;

            }
        }

        private void lblexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_Frm_Load(object sender, EventArgs e)
        {
            this.ActiveControl = label1;

        }

        private void lblClear_Click(object sender, EventArgs e)
        {
            tbEmail.Text = "";
            tbPassword.Text = "";
            tbEmail_Leave(sender, e);
            tbPassword_Leave(sender,e);
            tbEmail.Focus();
            this.ActiveControl = null;
        }

   

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if(tbEmail.Text == "someone@example.com")
                {
                    lblMessage.Text = "Please enter email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Length < 6 || tbEmail.Text.Length > 30)
                {
                    lblMessage.Text = "Email must be between 6 and 30 charachters.";
                    tbEmail.Focus();
                    return;
                }
                if (!tbEmail.Text.Contains('@'))
                {
                    lblMessage.Text = "Please enter valid email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbPassword.Text == "Password")
                {
                    lblMessage1.Text = "Please enter password.";
                    tbPassword.Focus();
                    return;
                }
                if (tbPassword.Text.Length < 8)
                {
                    lblMessage1.Text = "Password must be at least 8 charachters.";
                    tbPassword.Focus();
                    return;
                }
                var res = login(tbEmail.Text.Trim(), tbPassword.Text.Trim());
                if (res)
                {
                    Main_Frm m = new Main_Frm(this);
                    this.Hide();
                    m.Show();
                }
                else
                {
                    lblMessage1.Text = "Email or password is incorrect!";

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage1.Text = "";
            lblMessage.Text = "";
        }

        private bool login(string email, string password)
        {
            try
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    Users result = db.Users.Where(x => x.Email.ToLower() == email.ToLower() && x.Password == password).FirstOrDefault();
                    if (result != null)
                    {
                        LoadProfile.u = result;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception e)
            {

                throw;
            }


        }

        private void panellogin_MouseClick(object sender, MouseEventArgs e)
        {
            tbEmail.Focus();
            this.ActiveControl = null;
        }
    }
}
