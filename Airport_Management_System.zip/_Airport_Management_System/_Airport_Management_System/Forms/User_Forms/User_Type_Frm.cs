﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.User_Forms
{
    public partial class User_Type_Frm : Form
    {
        public User_Type_Frm()
        {
            InitializeComponent();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvUsertypesList.DataSource = (from b in db.UserType
                                                         select new
                                                         {
                                                             ID = b.UserTypeId,
                                                             User_Type_Name = b.UserType1,
                                                             Permissions = b.AccessRights
                                                         }).ToList();
                        dgvUsertypesList.Columns[0].Width = 150;
                        dgvUsertypesList.Columns[1].Width = 150;
                        dgvUsertypesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvUsertypesList.DataSource = (from b in db.UserType
                                                       where b.UserType1.Contains(searchvalue) || b.AccessRights.Contains(searchvalue)
                                                       select new
                                                       {
                                                           ID = b.UserTypeId,
                                                           User_Type_Name = b.UserType1,
                                                           Permissions = b.AccessRights
                                                       }).ToList();
                        dgvUsertypesList.Columns[0].Width = 150;
                        dgvUsertypesList.Columns[1].Width = 150;
                        dgvUsertypesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clear() 
        {
            tbUserType.Clear();
            tbSearch.Clear();
            cbAirport.Checked = false;
            cbLanding.Checked = false;
            cbTransportations.Checked = false;
            cbAirlines.Checked = false;
            cbAirplanes.Checked = false;
            cbFlights.Checked = false;
            cbTickets.Checked = false;
            cbSuppliers.Checked = false;
            cbPassengers.Checked = false;
            cbSettings.Checked = false;

        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvUsertypesList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvUsertypesList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }


        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();

        }
        
        private void cbAll_CheckedChanged(object sender, EventArgs e)
        {
            if(cbAll.Checked == true)
            {
                cbAirport.Checked = true;
                cbLanding.Checked = true;
                cbTransportations.Checked = true;
                cbAirlines.Checked = true;
                cbAirplanes.Checked = true;
                cbFlights.Checked = true;
                cbTickets.Checked = true;
                cbSuppliers.Checked = true;
                cbPassengers.Checked = true;
                cbSettings.Checked = true;
            }
            else
            {
                cbAirport.Checked = false;
                cbLanding.Checked = false;
                cbTransportations.Checked = false;
                cbAirlines.Checked = false;
                cbAirplanes.Checked = false;
                cbFlights.Checked = false;
                cbTickets.Checked = false;
                cbSuppliers.Checked = false;
                cbPassengers.Checked = false;
                cbSettings.Checked = false;
            }
            


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }
        private string check( CheckBox cb)
        {
            if(cb.Checked == true)
            {
                return "1";
            }
            else
            {
                return "0";

            }
        }
        string code = "";
        private string accessRightsCode()
        {
            if(cbAll.Checked == true)
            {
                code =  "1111111111";
                return code;
            }
            else
            {

                code = check(cbAirport) + check(cbLanding) + check(cbTransportations) + check(cbAirlines) + check(cbAirplanes) + check(cbFlights)
                    + check(cbTickets) + check(cbSuppliers) + check(cbPassengers) + check(cbSettings);
                return code;
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            accessRightsCode();

            try
            {
                if (tbUserType.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter User Type Name.";
                    tbUserType.Focus();
                    return;
                }
                if (tbUserType.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "User Type Name Can Be Maximum 20 Characters.";
                    tbUserType.Focus();
                    return;
                }
                if (!code.Contains("1"))
                {
                    lblMessage.Text = "Please Select One Permission At Least.";
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {

                    var result = db.UserType.Where(x => x.UserType1.ToLower() == tbUserType.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbUserType.Focus();
                        return;
                    }
                    UserType u = new UserType();
                    u.UserType1 = tbUserType.Text.Trim();
                    u.AccessRights = code;
                    db.UserType.Add(u);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void User_Type_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            cbAirport.ForeColor = ThemeColor.SecondaryColor;
            cbLanding.ForeColor = ThemeColor.SecondaryColor;
            cbTransportations.ForeColor = ThemeColor.SecondaryColor;
            cbAirlines.ForeColor = ThemeColor.SecondaryColor;
            cbAirplanes.ForeColor = ThemeColor.SecondaryColor;
            cbFlights.ForeColor = ThemeColor.SecondaryColor;
            cbTickets.ForeColor = ThemeColor.SecondaryColor;
            cbSuppliers.ForeColor = ThemeColor.SecondaryColor;
            cbPassengers.ForeColor = ThemeColor.SecondaryColor;
            cbSettings.ForeColor = ThemeColor.SecondaryColor;
            cbAll.ForeColor = ThemeColor.SecondaryColor;

        }


        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvUsertypesList != null && dgvUsertypesList.Rows.Count > 0)
                {
                    if (dgvUsertypesList.SelectedRows.Count == 1)
                    {
                        tbUserType.Text = Convert.ToString(dgvUsertypesList.CurrentRow.Cells[1].Value);
                        string permissions = Convert.ToString(dgvUsertypesList.CurrentRow.Cells[2].Value);
                        int[] array = new int[10];
                        for (int i = 0; i < permissions.Length; i++)
                        {
                            var num = int.Parse(permissions[i].ToString());
                            array[i] = num;
                        }
                        
                        
                        if (array[0] == 1)
                        {
                            cbAirport.Checked = true;
                            
                        }
                        if (array[1] == 1)
                        {
                            cbLanding.Checked = true;

                        }
                        if (array[2] == 1)
                        {
                            cbTransportations.Checked = true;

                        }
                        
                        if (array[3] == 1)
                        {
                            cbAirlines.Checked = true;

                        }
                        if (array[4] == 1)
                        {
                            cbAirplanes.Checked = true;

                        }
                        if (array[5] == 1)
                        {
                            cbFlights.Checked = true;

                        }
                        if (array[6] == 1)
                        {
                            cbTickets.Checked = true;

                        }
                        if (array[7] == 1)
                        {
                            cbPassengers.Checked = true;


                        }
                        if (array[8] == 1)
                        {
                            cbSuppliers.Checked = true;

                        }
                        if (array[9] == 1)
                        {
                            cbSettings.Checked = true;

                        }

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            accessRightsCode();
            try
            {
                if (tbUserType.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter User Type Name.";
                    tbUserType.Focus();
                    return;
                }
                if (tbUserType.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "User Type Name Can Be Maximum 20 Characters.";
                    tbUserType.Focus();
                    return;
                }
                if (!code.Contains("1"))
                {
                    lblMessage.Text = "Please Select One Permission At Least.";
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvUsertypesList.CurrentRow.Cells[0].Value);  
                    var result = db.UserType.Where(x => x.UserType1.ToLower() == tbUserType.Text.ToLower() && x.UserTypeId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbUserType.Focus();
                        return;
                    }
                    UserType u = db.UserType.Where(x => x.UserTypeId == int.Parse(ID)).FirstOrDefault();
                    u.UserType1 = tbUserType.Text.Trim();
                    u.AccessRights = code;
                    db.UserType.Update(u);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvUsertypesList != null && dgvUsertypesList.Rows.Count > 0)
                {
                    if (dgvUsertypesList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvUsertypesList.CurrentRow.Cells[0].Value);
                                UserType d = new UserType();
                                var entry = db.Entry(d);
                                d.UserTypeId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.UserType.Attach(d);
                                    db.UserType.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
