﻿using _Airport_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.User_Forms
{
    public partial class Users_Frm : Form
    {
        public Users_Frm()
        {
            InitializeComponent();
        }


        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvUsersList.DataSource = (from a in db.Airport
                                                     from d in db.Department
                                                     from w in db.WorkType
                                                     from ut in db.UserType
                                                     from u in db.Users
                                                     where a.AirportCode == u.AirportCode && d.DeptId == u.DeptId && w.WorkTypeId == u.WorkTypeId && ut.UserTypeId == u.UserTypeId 
                                                     select new
                                                     {
                                                         ID = u.UserId,
                                                         Airport = a.AirportName,
                                                         Department = d.DeptName,
                                                         User_Type = ut.UserType1,
                                                         Work_Type = w.WorkName,
                                                         Full_Name = u.FullName,
                                                         Birth_Date = u.BirthDate.ToString("dd/MMMM/yyyy"),
                                                         Gender = u.Gender,
                                                         Email = u.Email,
                                                         Phone_Number = u.PhoneNum,
                                                         Address = u.Address
                                                     }).ToList();
                        dgvUsersList.Columns[0].Width = 70;
                        dgvUsersList.Columns[1].Width = 130;
                        dgvUsersList.Columns[2].Width = 130;
                        dgvUsersList.Columns[3].Width = 130;
                        dgvUsersList.Columns[4].Width = 130;
                        dgvUsersList.Columns[5].Width = 130;
                        dgvUsersList.Columns[6].Width = 130;
                        dgvUsersList.Columns[7].Width = 130;
                        dgvUsersList.Columns[8].Width = 130;
                        dgvUsersList.Columns[9].Width = 130;
                        dgvUsersList.Columns[10].Width = 150;


                    }
                    else
                    {
                        dgvUsersList.DataSource = (from a in db.Airport
                                                   from d in db.Department
                                                   from w in db.WorkType
                                                   from ut in db.UserType
                                                   from u in db.Users
                                                   where a.AirportCode == u.AirportCode && d.DeptId == u.DeptId && w.WorkTypeId == u.WorkTypeId && ut.UserTypeId == u.UserTypeId
                                                   &&(a.AirportName.Contains(searchvalue)||d.DeptName.Contains(searchvalue)||ut.UserType1.Contains(searchvalue)||w.WorkName.Contains(searchvalue)||u.FullName.Contains(searchvalue)|| u.Gender.Contains(searchvalue)||u.BirthDate.ToString().Contains(searchvalue)||u.Email.Contains(searchvalue)||u.PhoneNum.Contains(searchvalue)||u.Address.Contains(searchvalue))
                                                   select new
                                                   {
                                                       ID = u.UserId,
                                                       Airport = a.AirportName,
                                                       Department = d.DeptName,
                                                       User_Type = ut.UserType1,
                                                       Work_Type = w.WorkName,
                                                       Full_Name = u.FullName,
                                                       Birth_Date = u.BirthDate.ToString("dd/MMMM/yyyy"),
                                                       Gender = u.Gender,
                                                       Email = u.Email,
                                                       Phone_Number = u.PhoneNum,
                                                       Address = u.Address
                                                   }).ToList();
                        dgvUsersList.Columns[0].Width = 70;
                        dgvUsersList.Columns[1].Width = 130;
                        dgvUsersList.Columns[2].Width = 130;
                        dgvUsersList.Columns[3].Width = 130;
                        dgvUsersList.Columns[4].Width = 130;
                        dgvUsersList.Columns[5].Width = 130;
                        dgvUsersList.Columns[6].Width = 130;
                        dgvUsersList.Columns[7].Width = 130;
                        dgvUsersList.Columns[8].Width = 130;
                        dgvUsersList.Columns[9].Width = 130;
                        dgvUsersList.Columns[10].Width = 150;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Users_Frm_Load(object sender, EventArgs e)
        {
            FillGrid("");
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }

            label6.ForeColor = ThemeColor.SecondaryColor;



        }
        private void OpenChildForm(Form childForm, string title)
        {
            if (LoadProfile.ActiveForm != null)
                LoadProfile.ActiveForm.Close();
            LoadProfile.ActiveForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            LoadProfile.DesktopPanel.Controls.Add(childForm);
            LoadProfile.DesktopPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            LoadProfile.Titlelbl.Text = title;
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AddUser(),"User Registeration");
            FillGrid("");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ID = Convert.ToString(dgvUsersList.CurrentRow.Cells[0].Value);
            
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                Users u = db.Users.Where(x => x.UserId == int.Parse(ID)).FirstOrDefault();
                LoadProfile.UserId = int.Parse(ID);
                LoadProfile.AirportCode = u.AirportCode;
                LoadProfile.DeptId = u.DeptId;
                LoadProfile.WorkTypeId = u.WorkTypeId;
                LoadProfile.UserTypeId = u.UserTypeId;
                LoadProfile.FullName = u.FullName;
                LoadProfile.BirthDate = u.BirthDate.Date;
                LoadProfile.Gender = u.Gender;
                LoadProfile.Address = u.Address;
                LoadProfile.PhoneNum = u.PhoneNum;
                LoadProfile.Email = u.Email;
                LoadProfile.Password = u.Password;
            }
            OpenChildForm(new UpdateUser(), "Update User Information");

            FillGrid("");
        }


        private void button3_Click(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvUsersList != null && dgvUsersList.Rows.Count > 0)
                {
                    if (dgvUsersList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvUsersList.CurrentRow.Cells[0].Value);
                                Users d = db.Users.Where(x => x.UserId == int.Parse(ID)).FirstOrDefault();
                                db.Users.Attach(d);
                                db.Users.Remove(d);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
