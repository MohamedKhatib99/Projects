﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _Airport_Management_System.Forms.Airport_Forms;
using _Airport_Management_System.Forms.Passenger_Forms;
using _Airport_Management_System.Forms.Supplier_Forms;
using _Airport_Management_System.Forms.User_Forms;
using _Airport_Management_System.Model;

namespace _Airport_Management_System.Forms
{
    public partial class Main_Frm : Form
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm = null;
        private Form loginfrm;


        public Main_Frm(Login_Frm login_Frm)
        {
            InitializeComponent();
            CustomizeDesign();
            random = new Random();
            btnCloseChildForm.Visible = false;
            this.Text = string.Empty;
            this.ControlBox = false;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
            loginfrm = login_Frm;

            LoadProfile.DesktopPanel = this.panelDesktopPane;
            LoadProfile.Titlelbl = this.lblTitle;
        }

        private void Main_Frm_Load(object sender, EventArgs e)
        {

            Color color = SelectThemeColor();
            panelTitleBar.BackColor = color;
            panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
            ThemeColor.PrimaryColor = color;
            ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3);

            btnAirport.BackColor = ThemeColor.SecondaryColor;
            btnLanding.BackColor = ThemeColor.SecondaryColor;
            btnTransportations.BackColor = ThemeColor.SecondaryColor;
            btnAirlineCompany.BackColor = ThemeColor.SecondaryColor;
            btnAirplane.BackColor = ThemeColor.SecondaryColor;
            btnFlight.BackColor = ThemeColor.SecondaryColor;
            btnTicket.BackColor = ThemeColor.SecondaryColor;
            btnPassenger.BackColor = ThemeColor.SecondaryColor;
            btnSupplier.BackColor = ThemeColor.SecondaryColor;
            btnSettings.BackColor = ThemeColor.SecondaryColor;
            btnlgout.BackColor = ThemeColor.SecondaryColor;






            if (LoadProfile.u != null)
            {
                btnUsettings.Text = " " + LoadProfile.u.FullName;

            }
            setUserPermissions();

        }
        private void setUserPermissions()
        {
            UserType ut;
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                 ut = db.UserType.Where(x => x.UserTypeId == LoadProfile.u.UserTypeId).FirstOrDefault();
            }
            string permissions = ut.AccessRights;
            int[] array = new int[10];
            for (int i = 0; i < permissions.Length; i++)
            {
                var num = int.Parse(permissions[i].ToString());
                array[i] = num;
            }


            if (array[0] == 0)
            {
                btnAirport.Enabled = false;
            }
            if (array[1] == 0)
            {
                btnLanding.Enabled = false;

            }
            if (array[2] == 0)
            {
                btnTransportations.Enabled = false;

            }

            if (array[3] == 0)
            {
                btnAirlineCompany.Enabled = false;

            }
            if (array[4] == 0)
            {
                btnAirplane.Enabled = false;

            }
            if (array[5] == 0)
            {
                btnFlight.Enabled = false;

            }
            if (array[6] == 0)
            {
                btnTicket.Enabled = false;


            }
            if (array[7] == 0)
            {
                btnPassenger.Enabled = false;

            }
            if (array[8] == 0)
            {
                btnSupplier.Enabled = false;

            }
            if (array[9] == 0)
            {
                btnSettings.Enabled = false;

            }
        }


        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        //Methods
        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[4];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnSender)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelTitleBar.BackColor = color;
                    panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    ThemeColor.PrimaryColor = color;
                    ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                }
            }
        }

        private void DisableButton()
        {
            foreach (Control previousBtn in MenuPanel.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = ThemeColor.SecondaryColor;
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }
        private void OpenChildForm(Form childForm,string title)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktopPane.Controls.Add(childForm);
            this.panelDesktopPane.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = title;
            btnCloseChildForm.Visible = true;
            hideSubMenu();


        }
        private void Reset()
        {
            DisableButton();
            lblTitle.Text = "HOME";

            Color color = SelectThemeColor();
            panelTitleBar.BackColor = color;
            panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
            ThemeColor.PrimaryColor = color;
            ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3);

            currentButton = null;
            btnCloseChildForm.Visible = false;
        }
        private void CustomizeDesign()
        {
            panelSubAirportMenu.Visible = false;
            panelSubairplaneMenu.Visible = false;
            panelSubTransportationMenu.Visible = false;
            panelSubLandingMenu.Visible = false;
            panelSubFlightMenu.Visible = false;
            panelSubTicketMenu.Visible = false;
            panelSubPassengerMenu.Visible = false;
            panelSubSettingsMenu.Visible = false;
            panelUsettings.Visible = false;
           
        } 
        private void hideSubMenu()
        {
            if (panelSubAirportMenu.Visible == true)
            {
                panelSubAirportMenu.Visible = false;

            }
            if (panelSubairplaneMenu.Visible == true)
            {
                panelSubairplaneMenu.Visible = false;

            }
            if (panelSubLandingMenu.Visible == true)
            {
                panelSubLandingMenu.Visible = false;

            }
            if (panelSubTransportationMenu.Visible == true)
            {
                panelSubTransportationMenu.Visible = false;

            }

            if (panelSubFlightMenu.Visible == true)
            {
                panelSubFlightMenu.Visible = false;

            }
            if (panelSubTicketMenu.Visible == true)
            {
                panelSubTicketMenu.Visible = false;

            }
            if (panelSubPassengerMenu.Visible == true)
            {
                panelSubPassengerMenu.Visible = false;

            }
            if (panelSubSettingsMenu.Visible == true)
            {
                panelSubSettingsMenu.Visible = false;

            }

        }
        private void showSubMenu(Panel subMenu)
        {
            if(subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }

        private void btnAirport_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubAirportMenu);
            ActivateButton(sender);
        }

      
        private void btnAirplane_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubairplaneMenu);
            ActivateButton(sender);

        }
        private void btnLanding_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubLandingMenu);
            ActivateButton(sender);

        }
        private void btnTransportations_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubTransportationMenu);
            ActivateButton(sender);

        }


        private void btnFlight_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubFlightMenu);
            ActivateButton(sender);

        }

        private void btnTicket_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubTicketMenu);
            ActivateButton(sender);

        }
        private void btnPassenger_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubPassengerMenu);
            ActivateButton(sender);

        }


        private void btnSettings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubSettingsMenu);
            ActivateButton(sender);

        }


        
        private void btnAirportss_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Airport_Frm(),"Airports Information");

        }

        

     

        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            Reset();
        }

        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnCloseChildForm_Click_1(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            if (LoadProfile.ActiveForm != null)
                LoadProfile.ActiveForm.Close();
            Reset();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
                loginfrm.Show();
            }
            else
            {
                panelUsettings.Visible = false;

            }
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void btnAirlineCompany_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
            OpenChildForm(new Airline_Company_Frm(), "Airline Companies Information");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Department_Frm(), "Departments Information");

        }

        private void btnControlTower_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Control_Towers_Frm(), "Control Towers Information");

        }

        private void btnGates_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Gate_Frm(), "Gates Information");

        }

        private void btnFlights_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Flights_Frm(), "Flights Information");

        }

        private void btnGateHouses_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Gate_House_Frm(), "Gate Houses Information");

        }

        private void btnParkings_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Parking_Frm(), "Parkings Information");

        }

        private void btnCities_Click(object sender, EventArgs e)
        {
            OpenChildForm(new CIty_Frm(), "Cities Information");

        }

        private void btnAirplanes_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Airplane_Frm(), "Airplanes Information");

        }

        private void btnFlightsPrices_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Flights_prices(), "Flight Prices Information");

        }

        private void btnSeats_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Seats_Frm(), "Seats Information");

        }

        private void btnpassengers_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Passengers_Frm(), "Passengers Information");

        }

        private void btnLugage_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Lugage_Frm(), "Lugages Information");

        }

        private void btnTickets_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Tickets_Frm(), "Tickets Information");

        }

        private void btnTicketTypes_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Ticket_Type_Frm(), "Ticket Types Information");

        }

        private void btnLandingAreas_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Landing_Area_Frm(), "Landing Areas Information");

        }

        private void btnHelipads_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Helipad_Frm(), "Helipads Information");

        }

        private void btnRunways_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Runway_Frm(), "Runways Information");

        }

        private void btnBuses_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Bus_Frm(), "Buses Information");

        }

        private void btninternalTransportations_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Internal_Transportation_Frm(), "Internal Transportations Information");

        }

        private void btnGHAPT_Click(object sender, EventArgs e)
        {
            OpenChildForm(new GHouse_Airplane_Transportation_Frm(), "Gate Houses && Airplanes && Transportations Informations");

        }

        private void button26_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Users_Frm(), "Users Informations");
            
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
            OpenChildForm(new Supplier_Frm(), "Supplier Informations");

        }
        private void btnUserTypes_Click(object sender, EventArgs e)
        {
            OpenChildForm(new User_Type_Frm(), "User Types && Permissions Informations");

        }
        private void btnWorkType_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Work_Type_Frm(), "Work Types && Salaries Informations");

        }


        ToolTip t1 = new ToolTip();
        

        private void btnClose_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Close", btnClose);

        }

        private void btnMaximize_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Restore Down", btnMaximize);

        }

        private void btnMinimize_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Minimize", btnMinimize);

        }

        private void btnCloseChildForm_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Close", btnCloseChildForm);

        }

        private void btnUsettings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUsettings);
        }

        private void Usettings_Click(object sender, EventArgs e)
        {
            panelUsettings.Visible = false;
            OpenChildForm(new Update_User_Profile(), "Update Profile Informations");
            LoadProfile.ActiveForm = activeForm;

        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure you want to logout ?", "Question", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
                loginfrm.Show();
            }
            else
            {
                panelUsettings.Visible = false;

            }

        }

        private void panelDesktopPane_MouseClick(object sender, MouseEventArgs e)
        {
            panelUsettings.Visible = false;

        }

        private void panelTitleBar_MouseClick(object sender, MouseEventArgs e)
        {
            panelUsettings.Visible = false;

        }

        private void btnlgout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
                loginfrm.Show();
            }
            else
            {
                panelUsettings.Visible = false;

            }
        }

        private void btnCheckin_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Check_In_Frm(), "Check In Informations");

        }
    }
}
