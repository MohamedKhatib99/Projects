﻿namespace _Airport_Management_System.Forms
{
    partial class Main_Frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Frm));
            this.MenuPanel = new System.Windows.Forms.Panel();
            this.btnlgout = new System.Windows.Forms.Button();
            this.panelSubSettingsMenu = new System.Windows.Forms.Panel();
            this.btnWorkType = new System.Windows.Forms.Button();
            this.btnUserTypes = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.panelSubPassengerMenu = new System.Windows.Forms.Panel();
            this.btnLugage = new System.Windows.Forms.Button();
            this.btnpassengers = new System.Windows.Forms.Button();
            this.btnPassenger = new System.Windows.Forms.Button();
            this.panelSubTicketMenu = new System.Windows.Forms.Panel();
            this.btnCheckin = new System.Windows.Forms.Button();
            this.btnTicketTypes = new System.Windows.Forms.Button();
            this.btnTickets = new System.Windows.Forms.Button();
            this.btnTicket = new System.Windows.Forms.Button();
            this.panelSubFlightMenu = new System.Windows.Forms.Panel();
            this.btnFlightsPrices = new System.Windows.Forms.Button();
            this.btnFlights = new System.Windows.Forms.Button();
            this.btnFlight = new System.Windows.Forms.Button();
            this.panelSubairplaneMenu = new System.Windows.Forms.Panel();
            this.btnSeats = new System.Windows.Forms.Button();
            this.btnAirplanes = new System.Windows.Forms.Button();
            this.btnAirplane = new System.Windows.Forms.Button();
            this.btnAirlineCompany = new System.Windows.Forms.Button();
            this.panelSubTransportationMenu = new System.Windows.Forms.Panel();
            this.btnGHAPT = new System.Windows.Forms.Button();
            this.btninternalTransportations = new System.Windows.Forms.Button();
            this.btnBuses = new System.Windows.Forms.Button();
            this.btnTransportations = new System.Windows.Forms.Button();
            this.panelSubLandingMenu = new System.Windows.Forms.Panel();
            this.btnRunways = new System.Windows.Forms.Button();
            this.btnHelipads = new System.Windows.Forms.Button();
            this.btnLandingAreas = new System.Windows.Forms.Button();
            this.btnLanding = new System.Windows.Forms.Button();
            this.panelSubAirportMenu = new System.Windows.Forms.Panel();
            this.btnCities = new System.Windows.Forms.Button();
            this.btnParkings = new System.Windows.Forms.Button();
            this.btnGateHouses = new System.Windows.Forms.Button();
            this.btnGates = new System.Windows.Forms.Button();
            this.btnControlTower = new System.Windows.Forms.Button();
            this.btnDepartments = new System.Windows.Forms.Button();
            this.btnAirportss = new System.Windows.Forms.Button();
            this.btnAirport = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.btnUsettings = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnCloseChildForm = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.panelUsettings = new System.Windows.Forms.Panel();
            this.btnlogout = new System.Windows.Forms.Button();
            this.Usettings = new System.Windows.Forms.Button();
            this.MenuPanel.SuspendLayout();
            this.panelSubSettingsMenu.SuspendLayout();
            this.panelSubPassengerMenu.SuspendLayout();
            this.panelSubTicketMenu.SuspendLayout();
            this.panelSubFlightMenu.SuspendLayout();
            this.panelSubairplaneMenu.SuspendLayout();
            this.panelSubTransportationMenu.SuspendLayout();
            this.panelSubLandingMenu.SuspendLayout();
            this.panelSubAirportMenu.SuspendLayout();
            this.panelTitleBar.SuspendLayout();
            this.panelUsettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuPanel
            // 
            this.MenuPanel.AutoScroll = true;
            this.MenuPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.MenuPanel.Controls.Add(this.btnlgout);
            this.MenuPanel.Controls.Add(this.panelSubSettingsMenu);
            this.MenuPanel.Controls.Add(this.btnSettings);
            this.MenuPanel.Controls.Add(this.btnSupplier);
            this.MenuPanel.Controls.Add(this.panelSubPassengerMenu);
            this.MenuPanel.Controls.Add(this.btnPassenger);
            this.MenuPanel.Controls.Add(this.panelSubTicketMenu);
            this.MenuPanel.Controls.Add(this.btnTicket);
            this.MenuPanel.Controls.Add(this.panelSubFlightMenu);
            this.MenuPanel.Controls.Add(this.btnFlight);
            this.MenuPanel.Controls.Add(this.panelSubairplaneMenu);
            this.MenuPanel.Controls.Add(this.btnAirplane);
            this.MenuPanel.Controls.Add(this.btnAirlineCompany);
            this.MenuPanel.Controls.Add(this.panelSubTransportationMenu);
            this.MenuPanel.Controls.Add(this.btnTransportations);
            this.MenuPanel.Controls.Add(this.panelSubLandingMenu);
            this.MenuPanel.Controls.Add(this.btnLanding);
            this.MenuPanel.Controls.Add(this.panelSubAirportMenu);
            this.MenuPanel.Controls.Add(this.btnAirport);
            this.MenuPanel.Controls.Add(this.panelLogo);
            this.MenuPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuPanel.Location = new System.Drawing.Point(0, 0);
            this.MenuPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MenuPanel.Name = "MenuPanel";
            this.MenuPanel.Size = new System.Drawing.Size(250, 906);
            this.MenuPanel.TabIndex = 0;
            // 
            // btnlgout
            // 
            this.btnlgout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(74)))));
            this.btnlgout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnlgout.FlatAppearance.BorderSize = 0;
            this.btnlgout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlgout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlgout.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnlgout.Location = new System.Drawing.Point(0, 2343);
            this.btnlgout.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnlgout.Name = "btnlgout";
            this.btnlgout.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnlgout.Size = new System.Drawing.Size(220, 63);
            this.btnlgout.TabIndex = 44;
            this.btnlgout.Text = "Logout";
            this.btnlgout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlgout.UseVisualStyleBackColor = false;
            this.btnlgout.Click += new System.EventHandler(this.btnlgout_Click);
            // 
            // panelSubSettingsMenu
            // 
            this.panelSubSettingsMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubSettingsMenu.Controls.Add(this.btnWorkType);
            this.panelSubSettingsMenu.Controls.Add(this.btnUserTypes);
            this.panelSubSettingsMenu.Controls.Add(this.button26);
            this.panelSubSettingsMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubSettingsMenu.Location = new System.Drawing.Point(0, 2156);
            this.panelSubSettingsMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubSettingsMenu.Name = "panelSubSettingsMenu";
            this.panelSubSettingsMenu.Size = new System.Drawing.Size(220, 187);
            this.panelSubSettingsMenu.TabIndex = 43;
            // 
            // btnWorkType
            // 
            this.btnWorkType.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnWorkType.FlatAppearance.BorderSize = 0;
            this.btnWorkType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWorkType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWorkType.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnWorkType.Location = new System.Drawing.Point(0, 126);
            this.btnWorkType.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnWorkType.Name = "btnWorkType";
            this.btnWorkType.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnWorkType.Size = new System.Drawing.Size(220, 63);
            this.btnWorkType.TabIndex = 2;
            this.btnWorkType.Text = "Work Types && Salaries";
            this.btnWorkType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWorkType.UseVisualStyleBackColor = true;
            this.btnWorkType.Click += new System.EventHandler(this.btnWorkType_Click);
            // 
            // btnUserTypes
            // 
            this.btnUserTypes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnUserTypes.FlatAppearance.BorderSize = 0;
            this.btnUserTypes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUserTypes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserTypes.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnUserTypes.Location = new System.Drawing.Point(0, 63);
            this.btnUserTypes.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUserTypes.Name = "btnUserTypes";
            this.btnUserTypes.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnUserTypes.Size = new System.Drawing.Size(220, 63);
            this.btnUserTypes.TabIndex = 1;
            this.btnUserTypes.Text = "User Types && Permissions";
            this.btnUserTypes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUserTypes.UseVisualStyleBackColor = true;
            this.btnUserTypes.Click += new System.EventHandler(this.btnUserTypes_Click);
            // 
            // button26
            // 
            this.button26.Dock = System.Windows.Forms.DockStyle.Top;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.Gainsboro;
            this.button26.Location = new System.Drawing.Point(0, 0);
            this.button26.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button26.Name = "button26";
            this.button26.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.button26.Size = new System.Drawing.Size(220, 63);
            this.button26.TabIndex = 0;
            this.button26.Text = "Users Settings";
            this.button26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(74)))));
            this.btnSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnSettings.Location = new System.Drawing.Point(0, 2093);
            this.btnSettings.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnSettings.Size = new System.Drawing.Size(220, 63);
            this.btnSettings.TabIndex = 42;
            this.btnSettings.Text = "Settings";
            this.btnSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(74)))));
            this.btnSupplier.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSupplier.FlatAppearance.BorderSize = 0;
            this.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupplier.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnSupplier.Location = new System.Drawing.Point(0, 2030);
            this.btnSupplier.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnSupplier.Size = new System.Drawing.Size(220, 63);
            this.btnSupplier.TabIndex = 41;
            this.btnSupplier.Text = "Suppliers";
            this.btnSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSupplier.UseVisualStyleBackColor = false;
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // panelSubPassengerMenu
            // 
            this.panelSubPassengerMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubPassengerMenu.Controls.Add(this.btnLugage);
            this.panelSubPassengerMenu.Controls.Add(this.btnpassengers);
            this.panelSubPassengerMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubPassengerMenu.Location = new System.Drawing.Point(0, 1907);
            this.panelSubPassengerMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubPassengerMenu.Name = "panelSubPassengerMenu";
            this.panelSubPassengerMenu.Size = new System.Drawing.Size(220, 123);
            this.panelSubPassengerMenu.TabIndex = 40;
            // 
            // btnLugage
            // 
            this.btnLugage.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLugage.FlatAppearance.BorderSize = 0;
            this.btnLugage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLugage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLugage.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLugage.Location = new System.Drawing.Point(0, 63);
            this.btnLugage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLugage.Name = "btnLugage";
            this.btnLugage.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnLugage.Size = new System.Drawing.Size(220, 63);
            this.btnLugage.TabIndex = 1;
            this.btnLugage.Text = "Luggage";
            this.btnLugage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLugage.UseVisualStyleBackColor = true;
            this.btnLugage.Click += new System.EventHandler(this.btnLugage_Click);
            // 
            // btnpassengers
            // 
            this.btnpassengers.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpassengers.FlatAppearance.BorderSize = 0;
            this.btnpassengers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpassengers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpassengers.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnpassengers.Location = new System.Drawing.Point(0, 0);
            this.btnpassengers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnpassengers.Name = "btnpassengers";
            this.btnpassengers.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnpassengers.Size = new System.Drawing.Size(220, 63);
            this.btnpassengers.TabIndex = 0;
            this.btnpassengers.Text = "Passengers Info";
            this.btnpassengers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnpassengers.UseVisualStyleBackColor = true;
            this.btnpassengers.Click += new System.EventHandler(this.btnpassengers_Click);
            // 
            // btnPassenger
            // 
            this.btnPassenger.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(74)))));
            this.btnPassenger.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPassenger.FlatAppearance.BorderSize = 0;
            this.btnPassenger.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPassenger.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPassenger.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnPassenger.Location = new System.Drawing.Point(0, 1844);
            this.btnPassenger.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnPassenger.Name = "btnPassenger";
            this.btnPassenger.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnPassenger.Size = new System.Drawing.Size(220, 63);
            this.btnPassenger.TabIndex = 39;
            this.btnPassenger.Text = "Passenger";
            this.btnPassenger.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPassenger.UseVisualStyleBackColor = false;
            this.btnPassenger.Click += new System.EventHandler(this.btnPassenger_Click);
            // 
            // panelSubTicketMenu
            // 
            this.panelSubTicketMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubTicketMenu.Controls.Add(this.btnCheckin);
            this.panelSubTicketMenu.Controls.Add(this.btnTicketTypes);
            this.panelSubTicketMenu.Controls.Add(this.btnTickets);
            this.panelSubTicketMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubTicketMenu.Location = new System.Drawing.Point(0, 1652);
            this.panelSubTicketMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubTicketMenu.Name = "panelSubTicketMenu";
            this.panelSubTicketMenu.Size = new System.Drawing.Size(220, 192);
            this.panelSubTicketMenu.TabIndex = 38;
            // 
            // btnCheckin
            // 
            this.btnCheckin.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCheckin.FlatAppearance.BorderSize = 0;
            this.btnCheckin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheckin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckin.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCheckin.Location = new System.Drawing.Point(0, 126);
            this.btnCheckin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCheckin.Name = "btnCheckin";
            this.btnCheckin.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnCheckin.Size = new System.Drawing.Size(220, 63);
            this.btnCheckin.TabIndex = 2;
            this.btnCheckin.Text = "Check in";
            this.btnCheckin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCheckin.UseVisualStyleBackColor = true;
            this.btnCheckin.Click += new System.EventHandler(this.btnCheckin_Click);
            // 
            // btnTicketTypes
            // 
            this.btnTicketTypes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTicketTypes.FlatAppearance.BorderSize = 0;
            this.btnTicketTypes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTicketTypes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTicketTypes.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTicketTypes.Location = new System.Drawing.Point(0, 63);
            this.btnTicketTypes.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTicketTypes.Name = "btnTicketTypes";
            this.btnTicketTypes.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnTicketTypes.Size = new System.Drawing.Size(220, 63);
            this.btnTicketTypes.TabIndex = 1;
            this.btnTicketTypes.Text = "Ticket Types";
            this.btnTicketTypes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTicketTypes.UseVisualStyleBackColor = true;
            this.btnTicketTypes.Click += new System.EventHandler(this.btnTicketTypes_Click);
            // 
            // btnTickets
            // 
            this.btnTickets.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTickets.FlatAppearance.BorderSize = 0;
            this.btnTickets.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTickets.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTickets.Location = new System.Drawing.Point(0, 0);
            this.btnTickets.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTickets.Name = "btnTickets";
            this.btnTickets.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnTickets.Size = new System.Drawing.Size(220, 63);
            this.btnTickets.TabIndex = 0;
            this.btnTickets.Text = "Tickets Info";
            this.btnTickets.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTickets.UseVisualStyleBackColor = true;
            this.btnTickets.Click += new System.EventHandler(this.btnTickets_Click);
            // 
            // btnTicket
            // 
            this.btnTicket.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(74)))));
            this.btnTicket.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTicket.FlatAppearance.BorderSize = 0;
            this.btnTicket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTicket.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTicket.Location = new System.Drawing.Point(0, 1589);
            this.btnTicket.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTicket.Name = "btnTicket";
            this.btnTicket.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnTicket.Size = new System.Drawing.Size(220, 63);
            this.btnTicket.TabIndex = 37;
            this.btnTicket.Text = "Ticket";
            this.btnTicket.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTicket.UseVisualStyleBackColor = false;
            this.btnTicket.Click += new System.EventHandler(this.btnTicket_Click);
            // 
            // panelSubFlightMenu
            // 
            this.panelSubFlightMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubFlightMenu.Controls.Add(this.btnFlightsPrices);
            this.panelSubFlightMenu.Controls.Add(this.btnFlights);
            this.panelSubFlightMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubFlightMenu.Location = new System.Drawing.Point(0, 1457);
            this.panelSubFlightMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubFlightMenu.Name = "panelSubFlightMenu";
            this.panelSubFlightMenu.Size = new System.Drawing.Size(220, 132);
            this.panelSubFlightMenu.TabIndex = 36;
            // 
            // btnFlightsPrices
            // 
            this.btnFlightsPrices.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnFlightsPrices.FlatAppearance.BorderSize = 0;
            this.btnFlightsPrices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFlightsPrices.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFlightsPrices.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnFlightsPrices.Location = new System.Drawing.Point(0, 63);
            this.btnFlightsPrices.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFlightsPrices.Name = "btnFlightsPrices";
            this.btnFlightsPrices.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnFlightsPrices.Size = new System.Drawing.Size(220, 63);
            this.btnFlightsPrices.TabIndex = 1;
            this.btnFlightsPrices.Text = "Flights Prices";
            this.btnFlightsPrices.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFlightsPrices.UseVisualStyleBackColor = true;
            this.btnFlightsPrices.Click += new System.EventHandler(this.btnFlightsPrices_Click);
            // 
            // btnFlights
            // 
            this.btnFlights.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnFlights.FlatAppearance.BorderSize = 0;
            this.btnFlights.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFlights.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFlights.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnFlights.Location = new System.Drawing.Point(0, 0);
            this.btnFlights.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFlights.Name = "btnFlights";
            this.btnFlights.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnFlights.Size = new System.Drawing.Size(220, 63);
            this.btnFlights.TabIndex = 0;
            this.btnFlights.Text = "Flights Info";
            this.btnFlights.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFlights.UseVisualStyleBackColor = true;
            this.btnFlights.Click += new System.EventHandler(this.btnFlights_Click);
            // 
            // btnFlight
            // 
            this.btnFlight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnFlight.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnFlight.FlatAppearance.BorderSize = 0;
            this.btnFlight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFlight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFlight.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnFlight.Location = new System.Drawing.Point(0, 1394);
            this.btnFlight.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFlight.Name = "btnFlight";
            this.btnFlight.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnFlight.Size = new System.Drawing.Size(220, 63);
            this.btnFlight.TabIndex = 35;
            this.btnFlight.Text = "Flight";
            this.btnFlight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFlight.UseVisualStyleBackColor = false;
            this.btnFlight.Click += new System.EventHandler(this.btnFlight_Click);
            // 
            // panelSubairplaneMenu
            // 
            this.panelSubairplaneMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubairplaneMenu.Controls.Add(this.btnSeats);
            this.panelSubairplaneMenu.Controls.Add(this.btnAirplanes);
            this.panelSubairplaneMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubairplaneMenu.Location = new System.Drawing.Point(0, 1271);
            this.panelSubairplaneMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubairplaneMenu.Name = "panelSubairplaneMenu";
            this.panelSubairplaneMenu.Size = new System.Drawing.Size(220, 123);
            this.panelSubairplaneMenu.TabIndex = 34;
            // 
            // btnSeats
            // 
            this.btnSeats.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSeats.FlatAppearance.BorderSize = 0;
            this.btnSeats.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeats.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeats.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnSeats.Location = new System.Drawing.Point(0, 63);
            this.btnSeats.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSeats.Name = "btnSeats";
            this.btnSeats.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnSeats.Size = new System.Drawing.Size(220, 63);
            this.btnSeats.TabIndex = 1;
            this.btnSeats.Text = "Seats";
            this.btnSeats.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSeats.UseVisualStyleBackColor = true;
            this.btnSeats.Click += new System.EventHandler(this.btnSeats_Click);
            // 
            // btnAirplanes
            // 
            this.btnAirplanes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAirplanes.FlatAppearance.BorderSize = 0;
            this.btnAirplanes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAirplanes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAirplanes.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAirplanes.Location = new System.Drawing.Point(0, 0);
            this.btnAirplanes.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAirplanes.Name = "btnAirplanes";
            this.btnAirplanes.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnAirplanes.Size = new System.Drawing.Size(220, 63);
            this.btnAirplanes.TabIndex = 0;
            this.btnAirplanes.Text = "Airplanes Info";
            this.btnAirplanes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAirplanes.UseVisualStyleBackColor = true;
            this.btnAirplanes.Click += new System.EventHandler(this.btnAirplanes_Click);
            // 
            // btnAirplane
            // 
            this.btnAirplane.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnAirplane.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAirplane.FlatAppearance.BorderSize = 0;
            this.btnAirplane.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAirplane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAirplane.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAirplane.Location = new System.Drawing.Point(0, 1208);
            this.btnAirplane.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAirplane.Name = "btnAirplane";
            this.btnAirplane.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnAirplane.Size = new System.Drawing.Size(220, 63);
            this.btnAirplane.TabIndex = 33;
            this.btnAirplane.Text = "Airplane";
            this.btnAirplane.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAirplane.UseVisualStyleBackColor = false;
            this.btnAirplane.Click += new System.EventHandler(this.btnAirplane_Click);
            // 
            // btnAirlineCompany
            // 
            this.btnAirlineCompany.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnAirlineCompany.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAirlineCompany.FlatAppearance.BorderSize = 0;
            this.btnAirlineCompany.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAirlineCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAirlineCompany.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAirlineCompany.Location = new System.Drawing.Point(0, 1145);
            this.btnAirlineCompany.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAirlineCompany.Name = "btnAirlineCompany";
            this.btnAirlineCompany.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnAirlineCompany.Size = new System.Drawing.Size(220, 63);
            this.btnAirlineCompany.TabIndex = 32;
            this.btnAirlineCompany.Text = "Airline Companies";
            this.btnAirlineCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAirlineCompany.UseVisualStyleBackColor = false;
            this.btnAirlineCompany.Click += new System.EventHandler(this.btnAirlineCompany_Click);
            // 
            // panelSubTransportationMenu
            // 
            this.panelSubTransportationMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubTransportationMenu.Controls.Add(this.btnGHAPT);
            this.panelSubTransportationMenu.Controls.Add(this.btninternalTransportations);
            this.panelSubTransportationMenu.Controls.Add(this.btnBuses);
            this.panelSubTransportationMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubTransportationMenu.Location = new System.Drawing.Point(0, 949);
            this.panelSubTransportationMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubTransportationMenu.Name = "panelSubTransportationMenu";
            this.panelSubTransportationMenu.Size = new System.Drawing.Size(220, 196);
            this.panelSubTransportationMenu.TabIndex = 25;
            // 
            // btnGHAPT
            // 
            this.btnGHAPT.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGHAPT.FlatAppearance.BorderSize = 0;
            this.btnGHAPT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGHAPT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGHAPT.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnGHAPT.Location = new System.Drawing.Point(0, 126);
            this.btnGHAPT.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGHAPT.Name = "btnGHAPT";
            this.btnGHAPT.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnGHAPT.Size = new System.Drawing.Size(220, 63);
            this.btnGHAPT.TabIndex = 2;
            this.btnGHAPT.Text = "Gate Houses && Airplanes && Transportations";
            this.btnGHAPT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGHAPT.UseVisualStyleBackColor = true;
            this.btnGHAPT.Click += new System.EventHandler(this.btnGHAPT_Click);
            // 
            // btninternalTransportations
            // 
            this.btninternalTransportations.Dock = System.Windows.Forms.DockStyle.Top;
            this.btninternalTransportations.FlatAppearance.BorderSize = 0;
            this.btninternalTransportations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninternalTransportations.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninternalTransportations.ForeColor = System.Drawing.Color.Gainsboro;
            this.btninternalTransportations.Location = new System.Drawing.Point(0, 63);
            this.btninternalTransportations.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btninternalTransportations.Name = "btninternalTransportations";
            this.btninternalTransportations.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btninternalTransportations.Size = new System.Drawing.Size(220, 63);
            this.btninternalTransportations.TabIndex = 1;
            this.btninternalTransportations.Text = "Internal Transportations";
            this.btninternalTransportations.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninternalTransportations.UseVisualStyleBackColor = true;
            this.btninternalTransportations.Click += new System.EventHandler(this.btninternalTransportations_Click);
            // 
            // btnBuses
            // 
            this.btnBuses.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBuses.FlatAppearance.BorderSize = 0;
            this.btnBuses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuses.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBuses.Location = new System.Drawing.Point(0, 0);
            this.btnBuses.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBuses.Name = "btnBuses";
            this.btnBuses.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnBuses.Size = new System.Drawing.Size(220, 63);
            this.btnBuses.TabIndex = 0;
            this.btnBuses.Text = "Buses";
            this.btnBuses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuses.UseVisualStyleBackColor = true;
            this.btnBuses.Click += new System.EventHandler(this.btnBuses_Click);
            // 
            // btnTransportations
            // 
            this.btnTransportations.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnTransportations.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTransportations.FlatAppearance.BorderSize = 0;
            this.btnTransportations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransportations.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransportations.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTransportations.Location = new System.Drawing.Point(0, 886);
            this.btnTransportations.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTransportations.Name = "btnTransportations";
            this.btnTransportations.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnTransportations.Size = new System.Drawing.Size(220, 63);
            this.btnTransportations.TabIndex = 24;
            this.btnTransportations.Text = "Transportations";
            this.btnTransportations.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTransportations.UseVisualStyleBackColor = false;
            this.btnTransportations.Click += new System.EventHandler(this.btnTransportations_Click);
            // 
            // panelSubLandingMenu
            // 
            this.panelSubLandingMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubLandingMenu.Controls.Add(this.btnRunways);
            this.panelSubLandingMenu.Controls.Add(this.btnHelipads);
            this.panelSubLandingMenu.Controls.Add(this.btnLandingAreas);
            this.panelSubLandingMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubLandingMenu.Location = new System.Drawing.Point(0, 693);
            this.panelSubLandingMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubLandingMenu.Name = "panelSubLandingMenu";
            this.panelSubLandingMenu.Size = new System.Drawing.Size(220, 193);
            this.panelSubLandingMenu.TabIndex = 23;
            // 
            // btnRunways
            // 
            this.btnRunways.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRunways.FlatAppearance.BorderSize = 0;
            this.btnRunways.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunways.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRunways.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnRunways.Location = new System.Drawing.Point(0, 126);
            this.btnRunways.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnRunways.Name = "btnRunways";
            this.btnRunways.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnRunways.Size = new System.Drawing.Size(220, 63);
            this.btnRunways.TabIndex = 2;
            this.btnRunways.Text = "Runways";
            this.btnRunways.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRunways.UseVisualStyleBackColor = true;
            this.btnRunways.Click += new System.EventHandler(this.btnRunways_Click);
            // 
            // btnHelipads
            // 
            this.btnHelipads.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHelipads.FlatAppearance.BorderSize = 0;
            this.btnHelipads.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelipads.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelipads.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnHelipads.Location = new System.Drawing.Point(0, 63);
            this.btnHelipads.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnHelipads.Name = "btnHelipads";
            this.btnHelipads.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnHelipads.Size = new System.Drawing.Size(220, 63);
            this.btnHelipads.TabIndex = 1;
            this.btnHelipads.Text = "Helipads";
            this.btnHelipads.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHelipads.UseVisualStyleBackColor = true;
            this.btnHelipads.Click += new System.EventHandler(this.btnHelipads_Click);
            // 
            // btnLandingAreas
            // 
            this.btnLandingAreas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLandingAreas.FlatAppearance.BorderSize = 0;
            this.btnLandingAreas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLandingAreas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLandingAreas.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLandingAreas.Location = new System.Drawing.Point(0, 0);
            this.btnLandingAreas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLandingAreas.Name = "btnLandingAreas";
            this.btnLandingAreas.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnLandingAreas.Size = new System.Drawing.Size(220, 63);
            this.btnLandingAreas.TabIndex = 0;
            this.btnLandingAreas.Text = "Landing Areas Info";
            this.btnLandingAreas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLandingAreas.UseVisualStyleBackColor = true;
            this.btnLandingAreas.Click += new System.EventHandler(this.btnLandingAreas_Click);
            // 
            // btnLanding
            // 
            this.btnLanding.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnLanding.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLanding.FlatAppearance.BorderSize = 0;
            this.btnLanding.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLanding.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLanding.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnLanding.Location = new System.Drawing.Point(0, 630);
            this.btnLanding.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLanding.Name = "btnLanding";
            this.btnLanding.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnLanding.Size = new System.Drawing.Size(220, 63);
            this.btnLanding.TabIndex = 3;
            this.btnLanding.Text = "Landing";
            this.btnLanding.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLanding.UseVisualStyleBackColor = false;
            this.btnLanding.Click += new System.EventHandler(this.btnLanding_Click);
            // 
            // panelSubAirportMenu
            // 
            this.panelSubAirportMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSubAirportMenu.Controls.Add(this.btnCities);
            this.panelSubAirportMenu.Controls.Add(this.btnParkings);
            this.panelSubAirportMenu.Controls.Add(this.btnGateHouses);
            this.panelSubAirportMenu.Controls.Add(this.btnGates);
            this.panelSubAirportMenu.Controls.Add(this.btnControlTower);
            this.panelSubAirportMenu.Controls.Add(this.btnDepartments);
            this.panelSubAirportMenu.Controls.Add(this.btnAirportss);
            this.panelSubAirportMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubAirportMenu.Location = new System.Drawing.Point(0, 188);
            this.panelSubAirportMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelSubAirportMenu.Name = "panelSubAirportMenu";
            this.panelSubAirportMenu.Size = new System.Drawing.Size(220, 442);
            this.panelSubAirportMenu.TabIndex = 2;
            // 
            // btnCities
            // 
            this.btnCities.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCities.FlatAppearance.BorderSize = 0;
            this.btnCities.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCities.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCities.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCities.Location = new System.Drawing.Point(0, 378);
            this.btnCities.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCities.Name = "btnCities";
            this.btnCities.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnCities.Size = new System.Drawing.Size(220, 63);
            this.btnCities.TabIndex = 6;
            this.btnCities.Text = "Cities";
            this.btnCities.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCities.UseVisualStyleBackColor = true;
            this.btnCities.Click += new System.EventHandler(this.btnCities_Click);
            // 
            // btnParkings
            // 
            this.btnParkings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnParkings.FlatAppearance.BorderSize = 0;
            this.btnParkings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParkings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParkings.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnParkings.Location = new System.Drawing.Point(0, 315);
            this.btnParkings.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnParkings.Name = "btnParkings";
            this.btnParkings.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnParkings.Size = new System.Drawing.Size(220, 63);
            this.btnParkings.TabIndex = 5;
            this.btnParkings.Text = "Parkings";
            this.btnParkings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnParkings.UseVisualStyleBackColor = true;
            this.btnParkings.Click += new System.EventHandler(this.btnParkings_Click);
            // 
            // btnGateHouses
            // 
            this.btnGateHouses.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGateHouses.FlatAppearance.BorderSize = 0;
            this.btnGateHouses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGateHouses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGateHouses.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnGateHouses.Location = new System.Drawing.Point(0, 252);
            this.btnGateHouses.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGateHouses.Name = "btnGateHouses";
            this.btnGateHouses.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnGateHouses.Size = new System.Drawing.Size(220, 63);
            this.btnGateHouses.TabIndex = 4;
            this.btnGateHouses.Text = "Gate Houses";
            this.btnGateHouses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGateHouses.UseVisualStyleBackColor = true;
            this.btnGateHouses.Click += new System.EventHandler(this.btnGateHouses_Click);
            // 
            // btnGates
            // 
            this.btnGates.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGates.FlatAppearance.BorderSize = 0;
            this.btnGates.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGates.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnGates.Location = new System.Drawing.Point(0, 189);
            this.btnGates.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGates.Name = "btnGates";
            this.btnGates.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnGates.Size = new System.Drawing.Size(220, 63);
            this.btnGates.TabIndex = 3;
            this.btnGates.Text = "Gates";
            this.btnGates.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGates.UseVisualStyleBackColor = true;
            this.btnGates.Click += new System.EventHandler(this.btnGates_Click);
            // 
            // btnControlTower
            // 
            this.btnControlTower.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnControlTower.FlatAppearance.BorderSize = 0;
            this.btnControlTower.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnControlTower.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnControlTower.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnControlTower.Location = new System.Drawing.Point(0, 126);
            this.btnControlTower.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnControlTower.Name = "btnControlTower";
            this.btnControlTower.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnControlTower.Size = new System.Drawing.Size(220, 63);
            this.btnControlTower.TabIndex = 2;
            this.btnControlTower.Text = "Control Towers";
            this.btnControlTower.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnControlTower.UseVisualStyleBackColor = true;
            this.btnControlTower.Click += new System.EventHandler(this.btnControlTower_Click);
            // 
            // btnDepartments
            // 
            this.btnDepartments.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDepartments.FlatAppearance.BorderSize = 0;
            this.btnDepartments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDepartments.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDepartments.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnDepartments.Location = new System.Drawing.Point(0, 63);
            this.btnDepartments.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnDepartments.Name = "btnDepartments";
            this.btnDepartments.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnDepartments.Size = new System.Drawing.Size(220, 63);
            this.btnDepartments.TabIndex = 1;
            this.btnDepartments.Text = "Departments";
            this.btnDepartments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDepartments.UseVisualStyleBackColor = true;
            this.btnDepartments.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnAirportss
            // 
            this.btnAirportss.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAirportss.FlatAppearance.BorderSize = 0;
            this.btnAirportss.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAirportss.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAirportss.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAirportss.Location = new System.Drawing.Point(0, 0);
            this.btnAirportss.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAirportss.Name = "btnAirportss";
            this.btnAirportss.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnAirportss.Size = new System.Drawing.Size(220, 63);
            this.btnAirportss.TabIndex = 0;
            this.btnAirportss.Text = "Airports Info";
            this.btnAirportss.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAirportss.UseVisualStyleBackColor = true;
            this.btnAirportss.Click += new System.EventHandler(this.btnAirportss_Click);
            // 
            // btnAirport
            // 
            this.btnAirport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnAirport.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAirport.FlatAppearance.BorderSize = 0;
            this.btnAirport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAirport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAirport.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAirport.Location = new System.Drawing.Point(0, 125);
            this.btnAirport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAirport.Name = "btnAirport";
            this.btnAirport.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnAirport.Size = new System.Drawing.Size(220, 63);
            this.btnAirport.TabIndex = 1;
            this.btnAirport.Text = "Airport ";
            this.btnAirport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAirport.UseVisualStyleBackColor = false;
            this.btnAirport.Click += new System.EventHandler(this.btnAirport_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(220, 125);
            this.panelLogo.TabIndex = 0;
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.panelTitleBar.Controls.Add(this.btnUsettings);
            this.panelTitleBar.Controls.Add(this.btnClose);
            this.panelTitleBar.Controls.Add(this.btnMaximize);
            this.panelTitleBar.Controls.Add(this.btnMinimize);
            this.panelTitleBar.Controls.Add(this.btnCloseChildForm);
            this.panelTitleBar.Controls.Add(this.lblTitle);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(250, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(1206, 125);
            this.panelTitleBar.TabIndex = 1;
            this.panelTitleBar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseClick);
            this.panelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseDown);
            // 
            // btnUsettings
            // 
            this.btnUsettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUsettings.FlatAppearance.BorderSize = 0;
            this.btnUsettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsettings.ForeColor = System.Drawing.Color.White;
            this.btnUsettings.Image = ((System.Drawing.Image)(resources.GetObject("btnUsettings.Image")));
            this.btnUsettings.Location = new System.Drawing.Point(966, 75);
            this.btnUsettings.Name = "btnUsettings";
            this.btnUsettings.Size = new System.Drawing.Size(240, 50);
            this.btnUsettings.TabIndex = 38;
            this.btnUsettings.Text = " Mohamed Khatib";
            this.btnUsettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnUsettings.UseVisualStyleBackColor = true;
            this.btnUsettings.Click += new System.EventHandler(this.btnUsettings_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClose.Image = global::_Airport_Management_System.Properties.Resources.cancel1;
            this.btnClose.Location = new System.Drawing.Point(1156, 0);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 35);
            this.btnClose.TabIndex = 37;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseHover += new System.EventHandler(this.btnClose_MouseHover);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaximize.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMaximize.Image = global::_Airport_Management_System.Properties.Resources.copy1;
            this.btnMaximize.Location = new System.Drawing.Point(1107, 0);
            this.btnMaximize.Margin = new System.Windows.Forms.Padding(4);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(50, 35);
            this.btnMaximize.TabIndex = 36;
            this.btnMaximize.UseVisualStyleBackColor = false;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            this.btnMaximize.MouseHover += new System.EventHandler(this.btnMaximize_MouseHover);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimize.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMinimize.Image = global::_Airport_Management_System.Properties.Resources.minus;
            this.btnMinimize.Location = new System.Drawing.Point(1059, 0);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(4);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(50, 35);
            this.btnMinimize.TabIndex = 35;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            this.btnMinimize.MouseHover += new System.EventHandler(this.btnMinimize_MouseHover);
            // 
            // btnCloseChildForm
            // 
            this.btnCloseChildForm.FlatAppearance.BorderSize = 0;
            this.btnCloseChildForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseChildForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnCloseChildForm.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCloseChildForm.Location = new System.Drawing.Point(0, 0);
            this.btnCloseChildForm.Margin = new System.Windows.Forms.Padding(4);
            this.btnCloseChildForm.Name = "btnCloseChildForm";
            this.btnCloseChildForm.Size = new System.Drawing.Size(107, 125);
            this.btnCloseChildForm.TabIndex = 34;
            this.btnCloseChildForm.Text = "X";
            this.btnCloseChildForm.UseVisualStyleBackColor = false;
            this.btnCloseChildForm.Click += new System.EventHandler(this.btnCloseChildForm_Click_1);
            this.btnCloseChildForm.MouseHover += new System.EventHandler(this.btnCloseChildForm_MouseHover);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTitle.Location = new System.Drawing.Point(523, 48);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(121, 39);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HOME";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.BackColor = System.Drawing.SystemColors.Control;
            this.panelDesktopPane.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDesktopPane.Location = new System.Drawing.Point(250, 126);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(1206, 780);
            this.panelDesktopPane.TabIndex = 2;
            this.panelDesktopPane.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelDesktopPane_MouseClick);
            // 
            // panelUsettings
            // 
            this.panelUsettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelUsettings.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelUsettings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelUsettings.Controls.Add(this.btnlogout);
            this.panelUsettings.Controls.Add(this.Usettings);
            this.panelUsettings.Location = new System.Drawing.Point(1216, 125);
            this.panelUsettings.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelUsettings.Name = "panelUsettings";
            this.panelUsettings.Size = new System.Drawing.Size(240, 101);
            this.panelUsettings.TabIndex = 35;
            // 
            // btnlogout
            // 
            this.btnlogout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnlogout.FlatAppearance.BorderSize = 0;
            this.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.Black;
            this.btnlogout.Image = ((System.Drawing.Image)(resources.GetObject("btnlogout.Image")));
            this.btnlogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Location = new System.Drawing.Point(0, 50);
            this.btnlogout.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnlogout.Size = new System.Drawing.Size(238, 50);
            this.btnlogout.TabIndex = 1;
            this.btnlogout.Text = " Logout";
            this.btnlogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // Usettings
            // 
            this.Usettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.Usettings.FlatAppearance.BorderSize = 0;
            this.Usettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Usettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Usettings.ForeColor = System.Drawing.Color.Black;
            this.Usettings.Image = ((System.Drawing.Image)(resources.GetObject("Usettings.Image")));
            this.Usettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Usettings.Location = new System.Drawing.Point(0, 0);
            this.Usettings.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Usettings.Name = "Usettings";
            this.Usettings.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.Usettings.Size = new System.Drawing.Size(238, 50);
            this.Usettings.TabIndex = 0;
            this.Usettings.Text = " Update Profile";
            this.Usettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Usettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Usettings.UseVisualStyleBackColor = true;
            this.Usettings.Click += new System.EventHandler(this.Usettings_Click);
            // 
            // Main_Frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1456, 906);
            this.Controls.Add(this.panelUsettings);
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.MenuPanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Main_Frm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main_Frm";
            this.Load += new System.EventHandler(this.Main_Frm_Load);
            this.MenuPanel.ResumeLayout(false);
            this.panelSubSettingsMenu.ResumeLayout(false);
            this.panelSubPassengerMenu.ResumeLayout(false);
            this.panelSubTicketMenu.ResumeLayout(false);
            this.panelSubFlightMenu.ResumeLayout(false);
            this.panelSubairplaneMenu.ResumeLayout(false);
            this.panelSubTransportationMenu.ResumeLayout(false);
            this.panelSubLandingMenu.ResumeLayout(false);
            this.panelSubAirportMenu.ResumeLayout(false);
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            this.panelUsettings.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MenuPanel;
        private System.Windows.Forms.Panel panelSubAirportMenu;
        private System.Windows.Forms.Button btnAirport;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnAirportss;
        private System.Windows.Forms.Button btnGateHouses;
        private System.Windows.Forms.Button btnGates;
        private System.Windows.Forms.Button btnControlTower;
        private System.Windows.Forms.Button btnDepartments;
        private System.Windows.Forms.Button btnParkings;
        private System.Windows.Forms.Button btnCities;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Panel panelSubSettingsMenu;
        private System.Windows.Forms.Button btnUserTypes;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Panel panelSubPassengerMenu;
        private System.Windows.Forms.Button btnLugage;
        private System.Windows.Forms.Button btnpassengers;
        private System.Windows.Forms.Button btnPassenger;
        private System.Windows.Forms.Panel panelSubTicketMenu;
        private System.Windows.Forms.Button btnCheckin;
        private System.Windows.Forms.Button btnTicketTypes;
        private System.Windows.Forms.Button btnTickets;
        private System.Windows.Forms.Button btnTicket;
        private System.Windows.Forms.Panel panelSubFlightMenu;
        private System.Windows.Forms.Button btnFlightsPrices;
        private System.Windows.Forms.Button btnFlights;
        private System.Windows.Forms.Button btnFlight;
        private System.Windows.Forms.Panel panelSubairplaneMenu;
        private System.Windows.Forms.Button btnSeats;
        private System.Windows.Forms.Button btnAirplanes;
        private System.Windows.Forms.Button btnAirplane;
        private System.Windows.Forms.Button btnAirlineCompany;
        private System.Windows.Forms.Panel panelSubTransportationMenu;
        private System.Windows.Forms.Button btninternalTransportations;
        private System.Windows.Forms.Button btnBuses;
        private System.Windows.Forms.Button btnTransportations;
        private System.Windows.Forms.Panel panelSubLandingMenu;
        private System.Windows.Forms.Button btnHelipads;
        private System.Windows.Forms.Button btnLandingAreas;
        private System.Windows.Forms.Button btnLanding;
        private System.Windows.Forms.Button btnRunways;
        private System.Windows.Forms.Button btnGHAPT;
        private System.Windows.Forms.Panel panelDesktopPane;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnCloseChildForm;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnWorkType;
        private System.Windows.Forms.Button btnUsettings;
        private System.Windows.Forms.Panel panelUsettings;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Button Usettings;
        private System.Windows.Forms.Button btnlgout;
    }
}