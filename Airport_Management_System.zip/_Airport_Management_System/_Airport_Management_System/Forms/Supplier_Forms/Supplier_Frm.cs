﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Supplier_Forms
{
    public partial class Supplier_Frm : Form
    {
        public Supplier_Frm()
        {
            InitializeComponent();
        }

        private void Supplier_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;




        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvSuppliersList.DataSource = (from a in db.Supplier
                                                      select new
                                                      {
                                                          ID = a.SupplierId,
                                                          Supplier_Name = a.SupplierName,
                                                          Address = a.Location,
                                                          Username = a.Username,
                                                          Password = a.Password
                                                      }).ToList();
                        dgvSuppliersList.Columns[0].Width = 110;
                        dgvSuppliersList.Columns[1].Width = 200;
                        dgvSuppliersList.Columns[2].Width = 300;
                        dgvSuppliersList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        dgvSuppliersList.Columns[4].Visible = false;

                    }
                    else
                    {
                        dgvSuppliersList.DataSource = (from a in db.Supplier
                                                       where a.SupplierName.Contains(searchvalue) || a.Location.Contains(searchvalue) || a.Username.Contains(searchvalue)
                                                       select new
                                                       {
                                                           ID = a.SupplierId,
                                                           Supplier_Name = a.SupplierName,
                                                           Address = a.Location,
                                                           Username = a.Username,
                                                           Password = a.Password
                                                       }).ToList();
                        dgvSuppliersList.Columns[0].Width = 110;
                        dgvSuppliersList.Columns[1].Width = 200;
                        dgvSuppliersList.Columns[2].Width = 300;
                        dgvSuppliersList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        dgvSuppliersList.Columns[4].Visible = false;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if(tbsuppliername.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Supplier Name.";
                    tbsuppliername.Focus();
                    return;
                }
                if (tbsuppliername.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Supplier Name Can Be Maximum 20 Characters.";
                    tbsuppliername.Focus();
                    return;

                }
                if (tbAdress.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Supplier Address.";
                    tbAdress.Focus();
                    return;

                }
                if (tbAdress.Text.Trim().Length > 50)
                {
                    lblMessage.Text = "Supplier Address Can Be Maximum 50 Characters.";
                    tbAdress.Focus();
                    return;

                }
                if (tbusername.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Username.";
                    tbusername.Focus();
                    return;

                }
                if (tbusername.Text.Trim().Length < 6)
                {
                    lblMessage1.Text = "Username Must Be At Least 6 Characters.";
                    tbusername.Focus();
                    return;

                }
                if (tbusername.Text.Trim().Length > 20)
                {
                    lblMessage1.Text = "Username Can Be Maximum 20 Characters.";
                    tbusername.Focus();
                    return;

                }
                if (tbpassword.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Password.";
                    tbpassword.Focus();
                    return;

                }
                if (tbpassword.Text.Trim().Length < 8 )
                {
                    lblMessage1.Text = "Password Must Be At Least 8 Characters.";
                    tbpassword.Focus();
                    return;

                }
                if (tbpassword.Text.Trim().Length > 20)
                {
                    lblMessage1.Text = "Password Can Be Maximum 20 Character.";
                    tbpassword.Focus();
                    return;

                }
                if (tbconfirmpassword.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Confirm Password.";
                    tbconfirmpassword.Focus();
                    return;

                }
                if (tbconfirmpassword.Text.Trim().Length < 8)
                {
                    lblMessage1.Text = "Password Must Be At Least 8 Characters.";
                    tbconfirmpassword.Focus();
                    return;

                }
                if (tbconfirmpassword.Text.Trim().Length > 20)
                {
                    lblMessage1.Text = "Password Can Be Maximum 20 Characters.";
                    tbconfirmpassword.Focus();
                    return;

                }
                if (tbpassword.Text.Trim() != tbconfirmpassword.Text.Trim())
                {
                    lblMessage1.Text = "Passwords Not Match.";
                    tbpassword.Focus();
                    return;

                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Supplier.Where(x => x.Username == tbusername.Text.Trim()).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage1.Text = "Username Already Registered.";
                        tbusername.Focus();
                        return;
                    }

                    Supplier s = new Supplier();
                    s.SupplierName = tbsuppliername.Text.Trim();
                    s.Location = tbAdress.Text.Trim();
                    s.Username = tbusername.Text.Trim();
                    s.Password = tbpassword.Text.Trim();
                    db.Supplier.Add(s);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");

                }



            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       

        private void Clear()
        {
            tbsuppliername.Clear();
            tbAdress.Clear();
            tbusername.Clear();
            tbpassword.Clear();
            tbconfirmpassword.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvSuppliersList.Enabled = false;
            tbSearch.Enabled = false;
            tbpassword.UseSystemPasswordChar = true;
            tbconfirmpassword.UseSystemPasswordChar = true;


        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvSuppliersList.Enabled = true;
            tbSearch.Enabled = true;
            tbpassword.UseSystemPasswordChar = false;
            tbconfirmpassword.UseSystemPasswordChar = false;

            FillGrid("");
            Clear();

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }


        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbsuppliername.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Supplier Name.";
                    tbsuppliername.Focus();
                    return;
                }
                if (tbsuppliername.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Supplier Name Can Be Maximum 20 Characters.";
                    tbsuppliername.Focus();
                    return;

                }
                if (tbAdress.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Supplier Address.";
                    tbAdress.Focus();
                    return;

                }
                if (tbAdress.Text.Trim().Length > 50)
                {
                    lblMessage.Text = "Supplier Address Can Be Maximum 50 Characters.";
                    tbAdress.Focus();
                    return;

                }
                if (tbusername.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Username.";
                    tbusername.Focus();
                    return;

                }
                if (tbusername.Text.Trim().Length < 6)
                {
                    lblMessage1.Text = "Username Must Be At Least 6 Characters.";
                    tbusername.Focus();
                    return;

                }
                if (tbusername.Text.Trim().Length > 20)
                {
                    lblMessage1.Text = "Username Can Be Maximum 20 Characters.";
                    tbusername.Focus();
                    return;

                }
                if (tbpassword.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Password.";
                    tbpassword.Focus();
                    return;

                }
                if (tbpassword.Text.Trim().Length < 8)
                {
                    lblMessage1.Text = "Password Must Be At Least 8 Characters.";
                    tbpassword.Focus();
                    return;

                }
                if (tbpassword.Text.Trim().Length > 20)
                {
                    lblMessage1.Text = "Password Can Be Maximum 20 Character.";
                    tbpassword.Focus();
                    return;

                }
                if (tbconfirmpassword.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Confirm Password.";
                    tbconfirmpassword.Focus();
                    return;

                }
                if (tbconfirmpassword.Text.Trim().Length < 8)
                {
                    lblMessage1.Text = "Password Must Be At Least 8 Characters.";
                    tbconfirmpassword.Focus();
                    return;

                }
                if (tbconfirmpassword.Text.Trim().Length > 20)
                {
                    lblMessage1.Text = "Password Can Be Maximum 20 Characters.";
                    tbconfirmpassword.Focus();
                    return;

                }
                if (tbpassword.Text.Trim() != tbconfirmpassword.Text.Trim())
                {
                    lblMessage1.Text = "Passwords Not Match.";
                    tbpassword.Focus();
                    return;

                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[0].Value);
                    var result = db.Supplier.Where(x => x.Username == tbusername.Text.Trim() && x.SupplierId != int.Parse(ID)).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage1.Text = "Username Already Registered.";
                        tbusername.Focus();
                        return;
                    }

                    Supplier s = db.Supplier.Where(x => x.SupplierId == int.Parse(ID)).FirstOrDefault();
                    s.SupplierName = tbsuppliername.Text.Trim();
                    s.Location = tbAdress.Text.Trim();
                    s.Username = tbusername.Text.Trim();
                    s.Password = tbpassword.Text.Trim();
                    db.Supplier.Update(s);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                    DisableControls();
                }



            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSuppliersList != null && dgvSuppliersList.Rows.Count > 0)
                {
                    if (dgvSuppliersList.SelectedRows.Count == 1)
                    {
                        tbsuppliername.Text = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[1].Value);
                        tbAdress.Text = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[2].Value);
                        tbusername.Text = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[3].Value);
                        tbpassword.Text = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[4].Value);
                        tbconfirmpassword.Text = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[4].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSuppliersList != null && dgvSuppliersList.Rows.Count > 0)
                {
                    if (dgvSuppliersList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvSuppliersList.CurrentRow.Cells[0].Value);
                                Supplier d = new Supplier();
                                var entry = db.Entry(d);
                                d.SupplierId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Supplier.Attach(d);
                                    db.Supplier.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

 
    }
}
