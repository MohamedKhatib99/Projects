﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Passenger_Forms
{
    public partial class Passengers_Frm : Form
    {
        public Passengers_Frm()
        {
            InitializeComponent();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void Clear()
        {
            mtbTCnum.Clear();
            tbEmail.Clear();
            tbfullname.Clear();
            mtbphonenum.Clear();
            dtpFDate.Value = DateTime.Today;
            tbAddress.Clear();
            rbMale.Checked = false;
            rbFemale.Checked = false;
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvPassengersList.Enabled = false;
            tbSearch.Enabled = false;
        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvPassengersList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (mtbTCnum.Text.Length == 0)
                {
                    lblMessage.Text = "Please Enter TC Number.";
                    mtbTCnum.Focus();
                    return;
                }
                if (mtbTCnum.Text.Length < 11)
                {
                    lblMessage.Text = "Please Enter Valid TC Number.";
                    mtbTCnum.Focus();
                    return;
                }
                if (tbfullname.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Passenger FullName.";
                    tbfullname.Focus();
                    return;
                }
                if (tbfullname.Text.Trim().Length > 40)
                {
                    lblMessage.Text = "Passenger FullName Can Be Maximum 40 Characters.";
                    tbfullname.Focus();
                    return;

                }
                if(!rbMale.Checked  && !rbFemale.Checked)
                {
                    lblMessage.Text = "Please Select Gender.";
                    return;
                }
                if(tbEmail.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Email.";
                    tbEmail.Focus();
                    return;
                }
                if (!tbEmail.Text.Trim().Contains('@') && tbEmail.Text.Trim().Length < 6)
                {
                    lblMessage1.Text = "Please Enter Valid Email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Trim().Length > 30)
                {
                    lblMessage1.Text = "Email Can be Maximum 30 characters.";
                    tbEmail.Focus();
                    return;
                }
                if (mtbphonenum.Text.Length == 10)
                {
                    lblMessage1.Text = "Please Enter Phone Number.";
                    mtbphonenum.Focus();
                    return;
                }
                if (mtbphonenum.Text.Length < 14)
                {
                    lblMessage1.Text = "Please Enter Valid Phone Number.";
                    mtbphonenum.Focus();
                    return;
                }
               
                if (tbAddress.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Address.";
                    tbAddress.Focus();
                    return;

                }
                if (tbAddress.Text.Trim().Length > 50)
                {
                    lblMessage1.Text = "Address Can Be Maximum 50 Characters.";
                    tbAddress.Focus();
                    return;

                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Passenger.Where(x => x.PassengerTc == mtbTCnum.Text).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage.Text = "Passenger Already Registered.";
                        mtbTCnum.Focus();
                        return;
                    }

                    int gender;
                    if (rbMale.Checked) { gender = 0; }
                    else { gender = 1; }

                    Passenger s = new Passenger();
                    s.PassengerTc = mtbTCnum.Text.Trim();
                    s.Name = tbfullname.Text.Trim();
                    s.Gender = gender;
                    s.BirthDate = dtpFDate.Value.Date;
                    s.Email = tbEmail.Text.Trim();
                    s.PhoneNum = mtbphonenum.Text.Trim();
                    s.Address = tbAddress.Text.Trim();
                    db.Passenger.Add(s);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                

                }
                

            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvPassengersList.DataSource = (from a in db.Passenger
                                                       select new
                                                       {
                                                           TC = a.PassengerTc,
                                                           Full_Name = a.Name,
                                                           Gender = a.Gender == 0 ? "Male" : "Female",
                                                           Birth_Date = a.BirthDate.ToString("dd/MMMM/yyyy"),
                                                           Email = a.Email,
                                                           Phone_Number = a.PhoneNum,
                                                           Address = a.Address
                                                       }).ToList();
                        dgvPassengersList.Columns[0].Width = 100;
                        dgvPassengersList.Columns[1].Width = 130;
                        dgvPassengersList.Columns[2].Width = 100;
                        dgvPassengersList.Columns[3].Width = 130;
                        dgvPassengersList.Columns[4].Width = 130;
                        dgvPassengersList.Columns[5].Width = 130;
                        dgvPassengersList.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    }
                    else
                    {
                        dgvPassengersList.DataSource = (from a in db.Passenger
                                                       where a.Name.Contains(searchvalue) || a.PhoneNum.Contains(searchvalue) || a.Address.Contains(searchvalue) || a.Email.Contains(searchvalue)||a.PassengerTc.Contains(searchvalue)||a.BirthDate.ToString().Contains(searchvalue) 
                                                       select new
                                                       {
                                                           TC = a.PassengerTc,
                                                           Full_Name = a.Name,
                                                           Gender = a.Gender == 0 ? "Male" : "Female",
                                                           Birth_Date = a.BirthDate.ToString("dd/MMMM/yyyy"),
                                                           Email = a.Email,
                                                           Phone_Number = a.PhoneNum,
                                                           Address = a.Address
                                                       }).ToList();
                        dgvPassengersList.Columns[0].Width = 100;
                        dgvPassengersList.Columns[1].Width = 130;
                        dgvPassengersList.Columns[2].Width = 100;
                        dgvPassengersList.Columns[3].Width = 130;
                        dgvPassengersList.Columns[4].Width = 130;
                        dgvPassengersList.Columns[5].Width = 130;
                        dgvPassengersList.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Passengers_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;
            label10.ForeColor = ThemeColor.SecondaryColor;
            rbMale.ForeColor = ThemeColor.SecondaryColor;
            rbFemale.ForeColor = ThemeColor.SecondaryColor;




        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPassengersList != null && dgvPassengersList.Rows.Count > 0)
                {
                    if (dgvPassengersList.SelectedRows.Count == 1)
                    {
                        mtbTCnum.Text = Convert.ToString(dgvPassengersList.CurrentRow.Cells[0].Value);
                        tbfullname.Text = Convert.ToString(dgvPassengersList.CurrentRow.Cells[1].Value);
                        String gender = Convert.ToString(dgvPassengersList.CurrentRow.Cells[2].Value);
                        dtpFDate.Text = Convert.ToString(dgvPassengersList.CurrentRow.Cells[3].Value);
                        tbEmail.Text = Convert.ToString(dgvPassengersList.CurrentRow.Cells[4].Value);
                        mtbphonenum.Text = Convert.ToString(dgvPassengersList.CurrentRow.Cells[5].Value);
                        tbAddress.Text = Convert.ToString(dgvPassengersList.CurrentRow.Cells[6].Value);
                        if(gender == "Male")
                        {
                            rbMale.Checked = true;
                        }
                        else
                        {
                            rbFemale.Checked = true;
                        }
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPassengersList != null && dgvPassengersList.Rows.Count > 0)
                {
                    if (dgvPassengersList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string TC = Convert.ToString(dgvPassengersList.CurrentRow.Cells[0].Value);
                                Passenger d = db.Passenger.Where(x => x.PassengerTc == TC).FirstOrDefault();
                                db.Passenger.Attach(d);
                                db.Passenger.Remove(d);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (mtbTCnum.Text.Length == 0)
                {
                    lblMessage.Text = "Please Enter TC Number.";
                    mtbTCnum.Focus();
                    return;
                }
                if (mtbTCnum.Text.Length < 11)
                {
                    lblMessage.Text = "Please Enter Valid TC Number.";
                    mtbTCnum.Focus();
                    return;
                }
                if (tbfullname.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Passenger FullName.";
                    tbfullname.Focus();
                    return;
                }
                if (tbfullname.Text.Trim().Length > 40)
                {
                    lblMessage.Text = "Passenger FullName Can Be Maximum 40 Characters.";
                    tbfullname.Focus();
                    return;

                }
                if (!rbMale.Checked && !rbFemale.Checked)
                {
                    lblMessage.Text = "Please Select Gender.";
                    return;
                }
                if (tbEmail.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Email.";
                    tbEmail.Focus();
                    return;
                }
                if (!tbEmail.Text.Trim().Contains('@') && tbEmail.Text.Trim().Length < 6)
                {
                    lblMessage1.Text = "Please Enter Valid Email.";
                    tbEmail.Focus();
                    return;
                }
                if (tbEmail.Text.Trim().Length > 30)
                {
                    lblMessage1.Text = "Email Can be Maximum 30 characters.";
                    tbEmail.Focus();
                    return;
                }
                if (mtbphonenum.Text.Length == 10)
                {
                    lblMessage1.Text = "Please Enter Phone Number.";
                    mtbphonenum.Focus();
                    return;
                }
                if (mtbphonenum.Text.Length < 14)
                {
                    lblMessage1.Text = "Please Enter Valid Phone Number.";
                    mtbphonenum.Focus();
                    return;
                }

                if (tbAddress.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Address.";
                    tbAddress.Focus();
                    return;

                }
                if (tbAddress.Text.Trim().Length > 50)
                {
                    lblMessage1.Text = "Address Can Be Maximum 50 Characters.";
                    tbAddress.Focus();
                    return;

                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvPassengersList.CurrentRow.Cells[0].Value);
                    var result = db.Passenger.Where(x => x.PassengerTc == mtbTCnum.Text && x.PassengerTc != ID).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage.Text = "Passenger Already Registered.";
                        mtbTCnum.Focus();
                        return;
                    }

                    int gender;
                    if (rbMale.Checked) { gender = 0; }
                    else { gender = 1; }

                    Passenger s = db.Passenger.Where(x => x.PassengerTc == ID ).FirstOrDefault();
                    s.PassengerTc = mtbTCnum.Text.Trim();
                    s.Name = tbfullname.Text.Trim();
                    s.Gender = gender;
                    s.BirthDate = dtpFDate.Value.Date;
                    s.Email = tbEmail.Text.Trim();
                    s.PhoneNum = mtbphonenum.Text.Trim();
                    s.Address = tbAddress.Text.Trim();
                    db.Passenger.Update(s);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                    DisableControls();
                }


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPassengersList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

     
    }
}
