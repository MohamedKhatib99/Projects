﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Passenger_Forms
{
    public partial class Lugage_Frm : Form
    {
        public Lugage_Frm()
        {
            InitializeComponent();
        }

   
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvLuggageList.DataSource = (from a in db.Passenger
                                                      from b in db.Luggage
                                                      where a.PassengerId == b.PassengerId
                                                      select new
                                                      {
                                                          ID = b.LuggageId,
                                                          Passenger_Name = a.Name,
                                                          Bages = b.Bags,
                                                          Weight = b.Weight,
                                                      }).ToList();
                        dgvLuggageList.Columns[0].Width = 130;
                        dgvLuggageList.Columns[1].Width = 130;
                        dgvLuggageList.Columns[2].Width = 130;
                        dgvLuggageList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvLuggageList.DataSource = (from a in db.Passenger
                                                     from b in db.Luggage
                                                     where a.PassengerId == b.PassengerId && (a.Name.Contains(searchvalue)||b.Bags.ToString().Contains(searchvalue)||b.Weight.ToString().Contains(searchvalue))
                                                     select new
                                                     {
                                                         ID = b.LuggageId,
                                                         Passenger_Name = a.Name,
                                                         Bages = b.Bags,
                                                         Weight = b.Weight,
                                                     }).ToList();
                        dgvLuggageList.Columns[0].Width = 130;
                        dgvLuggageList.Columns[1].Width = 130;
                        dgvLuggageList.Columns[2].Width = 130;
                        dgvLuggageList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void refreshPassengers()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var passengers = db.Passenger.ToList();
                passengers.Add(new Passenger
                {
                    Name = "--Select--"

                });
                passengers.Reverse();
                cbPassengerName.DisplayMember = "Name";
                cbPassengerName.ValueMember = "PassengerId";
                cbPassengerName.DataSource = passengers;
                cbPassengerName.Refresh();
            }
        }
        void Clear()
        {
            cbPassengerName.SelectedIndex = 0;
            tbBagesNum.Clear();
            tbbagesweight.Clear();

        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvLuggageList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvLuggageList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void Lugage_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshPassengers();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbPassengerName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Passenger.";
                    cbPassengerName.Focus();
                    return;
                }

                if (tbBagesNum.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Bages Number.";
                    tbBagesNum.Focus();
                    return;
                }
                if (!int.TryParse(tbBagesNum.Text.Trim(),out int value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbBagesNum.Focus();
                    return;
                }
                if (tbbagesweight.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Bages Weight.";
                    tbbagesweight.Focus();
                    return;
                }
                if (!double.TryParse(tbbagesweight.Text, out double value1))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbbagesweight.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Luggage.Where(x => x.PassengerId == int.Parse(cbPassengerName.SelectedValue.ToString()) && x.Bags == int.Parse(tbBagesNum.Text.Trim()) && x.Weight == double.Parse(tbbagesweight.Text.Trim()))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbPassengerName.Focus();
                        return;
                    }
                    Luggage ap = new Luggage();
                    ap.PassengerId = int.Parse(cbPassengerName.SelectedValue.ToString());
                    ap.Bags = int.Parse(tbBagesNum.Text.Trim());
                    ap.Weight = double.Parse(tbbagesweight.Text.Trim());
                    db.Luggage.Add(ap);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbPassengerName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Passenger.";
                    cbPassengerName.Focus();
                    return;
                }

                if (tbBagesNum.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Bages Number.";
                    tbBagesNum.Focus();
                    return;
                }
                if (!int.TryParse(tbBagesNum.Text.Trim(), out int value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbBagesNum.Focus();
                    return;
                }
                if (tbbagesweight.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Bages Weight.";
                    tbbagesweight.Focus();
                    return;
                }
                if (!double.TryParse(tbbagesweight.Text, out double value1))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbbagesweight.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvLuggageList.CurrentRow.Cells[0].Value);
                    var result = db.Luggage.Where(x => x.PassengerId == int.Parse(cbPassengerName.SelectedValue.ToString()) && x.Bags == int.Parse(tbBagesNum.Text.Trim()) && x.Weight == double.Parse(tbbagesweight.Text.Trim()) && x.LuggageId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbPassengerName.Focus();
                        return;
                    }
                    Luggage ap = db.Luggage.Where(x => x.LuggageId == int.Parse(ID)).FirstOrDefault();
                    ap.PassengerId = int.Parse(cbPassengerName.SelectedValue.ToString());
                    ap.Bags = int.Parse(tbBagesNum.Text.Trim());
                    ap.Weight = double.Parse(tbbagesweight.Text.Trim());
                    db.Luggage.Update(ap);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvLuggageList != null && dgvLuggageList.Rows.Count > 0)
                {
                    if (dgvLuggageList.SelectedRows.Count == 1)
                    {
                        cbPassengerName.Text = Convert.ToString(dgvLuggageList.CurrentRow.Cells[1].Value);
                        tbBagesNum.Text = Convert.ToString(dgvLuggageList.CurrentRow.Cells[2].Value);
                        tbbagesweight.Text = Convert.ToString(dgvLuggageList.CurrentRow.Cells[3].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (dgvLuggageList != null && dgvLuggageList.Rows.Count > 0)
                {
                    if (dgvLuggageList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvLuggageList.CurrentRow.Cells[0].Value);
                                Luggage ac = new Luggage();
                                var entry = db.Entry(ac);
                                ac.LuggageId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Luggage.Attach(ac);
                                    db.Luggage.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }


    }
}
