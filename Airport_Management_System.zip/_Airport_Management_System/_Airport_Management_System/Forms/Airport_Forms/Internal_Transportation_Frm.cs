﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Internal_Transportation_Frm : Form
    {
        public Internal_Transportation_Frm()
        {
            InitializeComponent();
        }


        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvtransportationList.DataSource = (from a in db.Flights
                                                      from b in db.Buses
                                                      from c in db.InternalTransport
                                                      where c.BusId == b.BusId && c.FlightNo == a.FlightNo
                                                      select new
                                                      {
                                                          ID = c.TransportNo,
                                                          Flight_No = a.FlightNo,
                                                          Bus_Name = b.BusName,
                                                      }).ToList();
                        dgvtransportationList.Columns[0].Width = 100;
                        dgvtransportationList.Columns[1].Width = 130;
                        dgvtransportationList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {

                        dgvtransportationList.DataSource = (from a in db.Flights
                                                            from b in db.Buses
                                                            from c in db.InternalTransport
                                                            where c.BusId == b.BusId && c.FlightNo == a.FlightNo
                                                            &&(a.FlightNo.Contains(searchvalue)||b.BusName.Contains(searchvalue))
                                                            select new
                                                            {
                                                                ID = c.TransportNo,
                                                                Flight_No = a.FlightNo,
                                                                Bus_Name = b.BusName,
                                                            }).ToList();
                        dgvtransportationList.Columns[0].Width = 100;
                        dgvtransportationList.Columns[1].Width = 130;
                        dgvtransportationList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void Clear()
        {
            cbBuscode.SelectedIndex = 0;
            cbFlight.SelectedIndex = 0;
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvtransportationList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvtransportationList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void refreshFlights()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Flights = db.Flights.ToList();
                Flights.Add(new Flights
                {
                    FlightNo = "--Select--"

                });
                Flights.Reverse();
                cbFlight.DisplayMember = "FlightNo";
                cbFlight.ValueMember = "FlightNo";
                cbFlight.DataSource = Flights;
                cbFlight.Refresh();
            }
        }

        void refreshBuses()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Buses = db.Buses.ToList();
                Buses.Add(new Buses
                {
                    BusName = "--Select--"

                });
                Buses.Reverse();
                cbBuscode.DisplayMember = "BusName";
                cbBuscode.ValueMember = "BusId";
                cbBuscode.DataSource = Buses;
                cbBuscode.Refresh();
            }
        }

        private void Internal_Transportation_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshBuses();
            refreshFlights();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;



        }


        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbFlight.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Flight Code.";
                    cbFlight.Focus();
                    return;
                }

                if (cbBuscode.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Bus Number/Name.";
                    cbBuscode.Focus();
                    return;
                }

              

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.InternalTransport.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString() && x.BusId == int.Parse(cbBuscode.SelectedValue.ToString()))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbBuscode.Focus();
                        return;
                    }
                    InternalTransport h = new InternalTransport();
                    h.FlightNo = cbFlight.SelectedValue.ToString();
                    h.BusId = int.Parse(cbBuscode.SelectedValue.ToString());
                    db.InternalTransport.Add(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbFlight.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Flight Code.";
                    cbFlight.Focus();
                    return;
                }

                if (cbBuscode.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Bus Number/Name.";
                    cbBuscode.Focus();
                    return;
                }



                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvtransportationList.CurrentRow.Cells[0].Value);
                    var result = db.InternalTransport.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString() && x.BusId == int.Parse(cbBuscode.SelectedValue.ToString()) &&x.TransportNo != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbBuscode.Focus();
                        return;
                    }
                    InternalTransport h = db.InternalTransport.Where(x => x.TransportNo == int.Parse(ID) ).FirstOrDefault();
                    h.FlightNo = cbFlight.SelectedValue.ToString();
                    h.BusId = int.Parse(cbBuscode.SelectedValue.ToString());
                    db.InternalTransport.Update(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvtransportationList != null && dgvtransportationList.Rows.Count > 0)
                {
                    if (dgvtransportationList.SelectedRows.Count == 1)
                    {

                        cbFlight.Text = Convert.ToString(dgvtransportationList.CurrentRow.Cells[1].Value);
                        cbBuscode.Text = Convert.ToString(dgvtransportationList.CurrentRow.Cells[2].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvtransportationList != null && dgvtransportationList.Rows.Count > 0)
                {
                    if (dgvtransportationList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvtransportationList.CurrentRow.Cells[0].Value);
                                InternalTransport ac = new InternalTransport();
                                var entry = db.Entry(ac);
                                ac.TransportNo = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.InternalTransport.Attach(ac);
                                    db.InternalTransport.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
