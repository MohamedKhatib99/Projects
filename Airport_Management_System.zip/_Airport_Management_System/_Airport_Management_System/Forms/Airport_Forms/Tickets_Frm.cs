﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Tickets_Frm : Form
    {
        
        bool status = true ;
        public Tickets_Frm()
        {
            InitializeComponent();
            cbFlight.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Tickets_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports(cbAirportName);
            refreshAirports(cbAriportname);
            refreshFlights();
            refreshTicketTypes();
            refreshPassengers();
            FillGrid("");
        
         }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;
            label11.ForeColor = ThemeColor.SecondaryColor;
            label12.ForeColor = ThemeColor.SecondaryColor;



        }

        void refreshAirports(ComboBox cb)
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cb.DisplayMember = "AirportName";
                cb.ValueMember = "AirportCode";
                cb.DataSource = Airports;
                cb.Refresh();
            }
        }
        void refreshFlights()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Flights = db.Flights.Where(x => x.StartPoint == cbAirportName.Text && x.EndPoint == cbAriportname.Text && x.FlightDate == dtpFDate.Value.Date).ToList();
                Flights.Add(new Flights
                {
                    DepartureTime = "--Select--"

                });
                Flights.Reverse();
                cbFlight.DisplayMember = "DepartureTime";
                cbFlight.ValueMember = "FlightNo";
                cbFlight.DataSource = Flights;
                cbFlight.Refresh();
            }
        }
        void refreshTicketTypes()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var TicketTypes = db.TicketType.ToList();
                TicketTypes.Add(new TicketType
                {
                    TicketTypeName = "--Select--"

                });
                TicketTypes.Reverse();
                cbticketType.DisplayMember = "TicketTypeName";
                cbticketType.ValueMember = "TicketTypeId";
                cbticketType.DataSource = TicketTypes;
                cbticketType.Refresh();
            }
        }

        private void cbAirportName_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshFlights();
            setPrice();
        }

        private void cbAriportname_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshFlights();
            setPrice();
        }

        private void dtpFDate_ValueChanged(object sender, EventArgs e)
        {
            refreshFlights();
            setPrice();
        }

        private void cbticketType_SelectedIndexChanged(object sender, EventArgs e)
        {
            setPrice();

        }
        void setPrice()
        {
            if (cbAirportName.SelectedIndex > 0 && cbAriportname.SelectedIndex > 0 && cbFlight.SelectedIndex > 0 && cbticketType.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var flightprice = db.FlightsPrices.Where(a => a.FlightNo == cbFlight.SelectedValue.ToString() && a.TicketTypeId == int.Parse(cbticketType.SelectedValue.ToString())).FirstOrDefault();
                    if (flightprice != null)
                    {
                        tbPrice.Text = flightprice.Price.ToString();
                    }
                    else
                    {
                        tbPrice.Text = "0.0";
                    }

                }
            }
            else
            {
                tbPrice.Text = "0.0";

            }
        }

        private void cbFlight_SelectedIndexChanged(object sender, EventArgs e)
        {
            setPrice();

        }
        void refreshPassengers()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var passengers = db.Passenger.ToList();
                passengers.Add(new Passenger
                {
                    Name = "--Select--"

                });
                passengers.Reverse();
                cbPassengerName.DisplayMember = "Name";
                cbPassengerName.ValueMember = "PassengerId";
                cbPassengerName.DataSource = passengers;
                cbPassengerName.Refresh();
            }
        }

        private void cbAirportName_TextUpdate(object sender, EventArgs e)
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                int index = cbAirportName.FindString(cbAirportName.Text);
                cbAirportName.SelectedIndex = index;
            }
        }
        void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            cbAriportname.SelectedIndex = 0;
            cbFlight.SelectedIndex = 0;
            cbticketType.SelectedIndex = 0;
            cbPassengerName.SelectedIndex = 0;
            tbSearch.Clear();
            tbPrice.Text = "0.0";
            dtpFDate.Value = DateTime.Now;
            if (!status)
            {
                tbTicketCode.Clear();
            }

        }

        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvticketsList.Enabled = false;
            tbSearch.Enabled = false;
            tbTicketCode.ReadOnly = true;
            status = true;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvticketsList.Enabled = true;
            tbSearch.Enabled = true;
            tbTicketCode.ReadOnly = false;
            status = false;
            FillGrid("");
            Clear();

        }

        void FillGrid(string searchvalue)
        {

            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvticketsList.DataSource = (from c in db.Flights
                                                     from d in db.AirlineCompany
                                                     from e in db.Airplane
                                                     from f in db.Ticket
                                                     from p in db.Passenger
                                                     from s in db.Supplier
                                                     from t in db.TicketType
                                                     from fp in db.FlightsPrices
                                                     where f.TicketTypeId == t.TicketTypeId && t.TicketTypeId == fp.TicketTypeId && fp.FlightNo == c.FlightNo && f.FlightNo == c.FlightNo  && c.AirplaneCode == e.AirplaneCode && d.AcId == e.AcId && f.PassengerId == p.PassengerId && s.SupplierId == f.SupplierId 
                                                     select new
                                                     {
                                                         Flight_No = f.FlightNo,
                                                         Ticket_No = f.TicketNo,
                                                         Airline_Company = d.AcName,
                                                         Airplane_Code = e.AirplaneCode,
                                                         From = c.StartPoint,
                                                         To = c.EndPoint,
                                                         Flight_Date = c.FlightDate.ToString("dd/MMMM/yyyy"),
                                                         Departure_Time = c.DepartureTime,
                                                         Arrival_Time = c.ArrivalTime,
                                                         Ticket_Type = t.TicketTypeName,
                                                         Passenger_Name = p.Name,
                                                         Sold_By = s.SupplierName,
                                                         Price = fp.Price

                                                     }).ToList();
                        dgvticketsList.Columns[0].Width = 90;
                        dgvticketsList.Columns[1].Width = 130;
                        dgvticketsList.Columns[2].Width = 130;
                        dgvticketsList.Columns[3].Width = 130;
                        dgvticketsList.Columns[4].Width = 130;
                        dgvticketsList.Columns[5].Width = 130;
                        dgvticketsList.Columns[6].Width = 130;
                        dgvticketsList.Columns[7].Width = 130;
                        dgvticketsList.Columns[8].Width = 130;
                        dgvticketsList.Columns[9].Width = 130;
                        dgvticketsList.Columns[10].Width = 130;
                        dgvticketsList.Columns[11].Width = 130;

                    }
                    else
                    {
                        dgvticketsList.DataSource = (from c in db.Flights
                                                     from d in db.AirlineCompany
                                                     from e in db.Airplane
                                                     from f in db.Ticket
                                                     from p in db.Passenger
                                                     from s in db.Supplier
                                                     from t in db.TicketType
                                                     from fp in db.FlightsPrices
                                                     where f.TicketTypeId == t.TicketTypeId && t.TicketTypeId == fp.TicketTypeId && fp.FlightNo == c.FlightNo && f.FlightNo == c.FlightNo && c.AirplaneCode == e.AirplaneCode && d.AcId == e.AcId && f.PassengerId == p.PassengerId && s.SupplierId == f.SupplierId
                                                     && (f.FlightNo.Contains(searchvalue) || f.TicketNo.Contains(searchvalue)|| e.AirplaneCode.Contains(searchvalue)|| c.StartPoint.Contains(searchvalue)|| c.EndPoint.Contains(searchvalue)|| c.FlightDate.ToString().Contains(searchvalue)|| c.DepartureTime.Contains(searchvalue)||c.ArrivalTime.Contains(searchvalue)|| t.TicketTypeName.Contains(searchvalue)||p.Name.Contains(searchvalue)|| s.SupplierName.Contains(searchvalue)|| fp.Price.ToString().Contains(searchvalue))
                                                     select new
                                                     {
                                                         Flight_No = f.FlightNo,
                                                         Ticket_No = f.TicketNo,
                                                         Airline_Company = d.AcName,
                                                         Airplane_Code = e.AirplaneCode,
                                                         From = c.StartPoint,
                                                         To = c.EndPoint,
                                                         Flight_Date = c.FlightDate.ToString("dd/MMMM/yyyy"),
                                                         Departure_Time = c.DepartureTime,
                                                         Arrival_Time = c.ArrivalTime,
                                                         Ticket_Type = t.TicketTypeName,
                                                         Passenger_Name = p.Name,
                                                         Sold_By = s.SupplierName,
                                                         Price = fp.Price

                                                     }).ToList();
                        dgvticketsList.Columns[0].Width = 90;
                        dgvticketsList.Columns[1].Width = 130;
                        dgvticketsList.Columns[2].Width = 130;
                        dgvticketsList.Columns[3].Width = 130;
                        dgvticketsList.Columns[4].Width = 130;
                        dgvticketsList.Columns[5].Width = 130;
                        dgvticketsList.Columns[6].Width = 130;
                        dgvticketsList.Columns[7].Width = 130;
                        dgvticketsList.Columns[8].Width = 130;
                        dgvticketsList.Columns[9].Width = 130;
                        dgvticketsList.Columns[10].Width = 130;
                        dgvticketsList.Columns[11].Width = 130;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Departure Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbAriportname.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Arrival Airport.";
                    cbAriportname.Focus();
                    return;
                }
                if (cbAirportName.SelectedIndex == cbAriportname.SelectedIndex)
                {
                    lblMessage.Text = "Departure And Arrival Airport Can't Be same!.";
                    cbAriportname.Focus();
                    return;

                }
                if (cbFlight.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Flight.";
                    cbFlight.Focus();
                    return;
                }
                
                if (tbTicketCode.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Ticket Code.";
                    tbTicketCode.Focus();
                    return;

                }
                if (tbTicketCode.Text.Length > 10)
                {
                    lblMessage1.Text = "Ticket Code Can Be Maximum 10 Characters.";
                    tbTicketCode.Focus();
                    return;
                }
                if (cbticketType.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Ticket Type.";
                    cbticketType.Focus();
                    return;
                }
                if (cbPassengerName.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Passenger.";
                    cbPassengerName.Focus();
                    return;
                }
                
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Ticket.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString() && x.PassengerId == int.Parse(cbPassengerName.SelectedValue.ToString()))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage1.Text = "Ticket Already Registered !";
                        cbPassengerName.Focus();
                        return;
                    }

                    if (tbPrice.Text == "0.0")
                    {
                        MessageBox.Show("Tickets Of Type " + cbticketType.Text.ToUpper() + " For This Flight Is Unavailable Please Inform Airline Company.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    if (cbFlight.SelectedValue.ToString() != null)
                    {
                        Flights f = db.Flights.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString()).FirstOrDefault();
                        if (f.SoldTickets < f.AvailableTickets)
                        {
                            f.SoldTickets = f.SoldTickets + 1;
                            db.Flights.Update(f);

                            Ticket t = new Ticket();
                            t.TicketNo = tbTicketCode.Text.Trim();
                            t.FlightNo = cbFlight.SelectedValue.ToString();
                            t.SupplierId = 1;
                            t.PassengerId = int.Parse(cbPassengerName.SelectedValue.ToString());
                            t.TicketTypeId = int.Parse(cbticketType.SelectedValue.ToString());
                            db.Ticket.Add(t);
                            db.SaveChanges();
                            MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Clear();
                            FillGrid("");
                        }
                        else
                        {
                            MessageBox.Show("Sorry Tickets Sold Out !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }

                    }
                                        
                }
               

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvticketsList != null && dgvticketsList.Rows.Count > 0)
                {
                    if (dgvticketsList.SelectedRows.Count == 1)
                    {
                        tbTicketCode.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[1].Value);
                        cbAirportName.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[4].Value);
                        cbAriportname.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[5].Value);
                        dtpFDate.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[6].Value);
                        cbFlight.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[7].Value);
                        cbticketType.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[9].Value);
                        cbPassengerName.Text = Convert.ToString(dgvticketsList.CurrentRow.Cells[10].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Departure Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbAriportname.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Arrival Airport.";
                    cbAriportname.Focus();
                    return;
                }
                if(cbAirportName.SelectedIndex == cbAriportname.SelectedIndex)
                {
                    lblMessage.Text = "Departure And Arrival Airport Can't Be same!.";
                    cbAriportname.Focus();
                    return;

                }

                if (cbFlight.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Flight.";
                    cbFlight.Focus();
                    return;
                }

                if (tbTicketCode.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Ticket Code.";
                    tbTicketCode.Focus();
                    return;

                }
                if (tbTicketCode.Text.Length > 10)
                {
                    lblMessage1.Text = "Ticket Code Can Be Maximum 10 Characters.";
                    tbTicketCode.Focus();
                    return;
                }
                if (cbticketType.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Ticket Type.";
                    cbticketType.Focus();
                    return;
                }
                if (cbPassengerName.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Passenger.";
                    cbPassengerName.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string TNO = Convert.ToString(dgvticketsList.CurrentRow.Cells[1].Value);
                    var result = db.Ticket.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString() && x.PassengerId == int.Parse(cbPassengerName.SelectedValue.ToString()) && x.TicketNo != TNO)
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage1.Text = "Ticket Already Registered !";
                        cbPassengerName.Focus();
                        return;
                    }
                    if (tbPrice.Text == "0.0")
                    {
                        MessageBox.Show("Tickets Of Type "+cbticketType.Text.ToUpper() +" For This Flight Is Unavailable Please Inform Airline Company.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    Ticket t =db.Ticket.Where(x => x.TicketNo == TNO ).FirstOrDefault();
                    t.TicketNo = tbTicketCode.Text.Trim();
                    t.FlightNo = cbFlight.SelectedValue.ToString();
                    t.SupplierId = 1;
                    t.PassengerId = int.Parse(cbPassengerName.SelectedValue.ToString());
                    t.TicketTypeId = int.Parse(cbticketType.SelectedValue.ToString());
                    db.Ticket.Update(t);
                    db.SaveChanges();

                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvticketsList != null && dgvticketsList.Rows.Count > 0)
                {
                    if (dgvticketsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string Tno = Convert.ToString(dgvticketsList.CurrentRow.Cells[1].Value);
                                Ticket t = db.Ticket.Where(x =>x.TicketNo == Tno).FirstOrDefault();

                                Flights f = db.Flights.Where(x => x.FlightNo == t.FlightNo).FirstOrDefault();

                                f.SoldTickets = f.SoldTickets - 1;
                                db.Flights.Update(f);
                                db.Ticket.Attach(t);
                                db.Ticket.Remove(t);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");



                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        

    }
}
