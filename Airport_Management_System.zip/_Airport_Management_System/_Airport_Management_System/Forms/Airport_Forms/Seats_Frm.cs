﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Seats_Frm : Form
    {
        public Seats_Frm()
        {
            InitializeComponent();
            cbAirplane.SelectedIndex = 0;
            cbreservation.SelectedIndex = 0;

        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvSeatsList.DataSource = (from a in db.Airplane
                                                   from z in db.AirlineCompany
                                                   from b in db.TicketType
                                                   from c in db.Seats
                                                   where a.AirplaneCode == c.AirplaneCode && b.TicketTypeId == c.TicketTypeId && a.AcId == z.AcId
                                                   select new
                                                   {
                                                       ID = c.SeatId,
                                                       Airline_Company = z.AcName,
                                                       Airplane_Code = a.AirplaneCode,
                                                       Ticket_Type_Name = b.TicketTypeName,
                                                       Seat_Cabin_No = c.SeatNo,
                                                       Status = c.ReservationStatus == 0 ? "Empty" : "Reserved"

                                                   }).ToList();
                        dgvSeatsList.Columns[0].Width = 70;
                        dgvSeatsList.Columns[1].Width = 130;
                        dgvSeatsList.Columns[2].Width = 130;
                        dgvSeatsList.Columns[3].Width = 130;
                        dgvSeatsList.Columns[4].Width = 130;
                        dgvSeatsList.Columns[5].Width = 130;

                    }
                    else
                    {

                        dgvSeatsList.DataSource = (from a in db.Airplane
                                                   from z in db.AirlineCompany
                                                   from b in db.TicketType
                                                   from c in db.Seats
                                                   where a.AirplaneCode == c.AirplaneCode && b.TicketTypeId == c.TicketTypeId && a.AcId == z.AcId
                                                   && (a.AirplaneCode.Contains(searchvalue)||b.TicketTypeName.Contains(searchvalue)||c.SeatNo.Contains(searchvalue))
                                                   select new
                                                   {
                                                       ID = c.SeatId,
                                                       Airline_Company = z.AcName,
                                                       Airplane_Code = a.AirplaneCode,
                                                       Ticket_Type_Name = b.TicketTypeName,
                                                       Seat_Cabin_No = c.SeatNo,
                                                       Status = c.ReservationStatus == 0 ? "Empty" : "Reserved"

                                                   }).ToList();
                        dgvSeatsList.Columns[0].Width = 70;
                        dgvSeatsList.Columns[1].Width = 130;
                        dgvSeatsList.Columns[2].Width = 130;
                        dgvSeatsList.Columns[3].Width = 130;
                        dgvSeatsList.Columns[4].Width = 130;
                        dgvSeatsList.Columns[5].Width = 130;

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void refreshAirlineCompanies()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Companies = db.AirlineCompany.ToList();
                Companies.Add(new AirlineCompany
                {
                    AcName = "--Select--"

                });
                Companies.Reverse();
                cbCompany.DisplayMember = "AcName";
                cbCompany.ValueMember = "AcId";
                cbCompany.DataSource = Companies;
                cbCompany.Refresh();
            }
        }

        void refreshAirplanes()
        {
            if (cbCompany.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var Airplanes = db.Airplane.Where(x => x.AcId == int.Parse(cbCompany.SelectedValue.ToString())).ToList();
                    Airplanes.Add(new Airplane
                    {
                        AirplaneCode = "--Select--"

                    });
                    Airplanes.Reverse();
                    cbAirplane.DisplayMember = "AirplaneCode";
                    cbAirplane.ValueMember = "AirplaneCode";
                    cbAirplane.DataSource = Airplanes;
                    cbAirplane.Refresh();
                }
            }
        }
        void refreshTicketTypes()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var TicketTypes = db.TicketType.ToList();
                TicketTypes.Add(new TicketType
                {
                    TicketTypeName = "--Select--"

                });
                TicketTypes.Reverse();
                cbticketType.DisplayMember = "TicketTypeName";
                cbticketType.ValueMember = "TicketTypeId";
                cbticketType.DataSource = TicketTypes;
                cbticketType.Refresh();
            }
        }

        private void Seats_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirplanes();
            refreshAirlineCompanies();
            refreshTicketTypes();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label1.ForeColor = ThemeColor.SecondaryColor;



        }
        private void Clear()
        {
            cbAirplane.SelectedIndex = 0;
            cbticketType.SelectedIndex = 0;
            cbCompany.SelectedIndex = 0;
            tbSearch.Text = "";
            tbSeatNO.Text = "";
            cbreservation.SelectedIndex = 0;
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvSeatsList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvSeatsList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirplane.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airplane.";
                    cbAirplane.Focus();
                    return;
                }

                if (cbticketType.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Ticket Type.";
                    cbticketType.Focus();
                    return;
                }

                if (tbSeatNO.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Seat/Cabin No.";
                    tbSeatNO.Focus();
                    return;
                }
                if (tbSeatNO.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Seat/Cabin No Can Be Maximum 10 Characters.";
                    tbSeatNO.Focus();
                    return;
                }
                if (cbreservation.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Seat Status.";
                    cbreservation.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Seats.Where(x => x.AirplaneCode == cbAirplane.SelectedValue.ToString() && x.TicketTypeId == int.Parse(cbticketType.SelectedValue.ToString()) && x.SeatNo.Trim().ToUpper() == tbSeatNO.Text.Trim().ToUpper())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbSeatNO.Focus();
                        return;
                    }
                    Seats s = new Seats();
                    s.AirplaneCode = cbAirplane.SelectedValue.ToString();
                    s.TicketTypeId = int.Parse(cbticketType.SelectedValue.ToString());
                    s.SeatNo = tbSeatNO.Text.Trim();
                    s.ReservationStatus = cbreservation.Text == "Empty" ? 0 : 1;
                    db.Seats.Add(s);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirplane.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airplane.";
                    cbAirplane.Focus();
                    return;
                }

                if (cbticketType.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Ticket Type.";
                    cbticketType.Focus();
                    return;
                }

                if (tbSeatNO.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Seat/Cabin No.";
                    tbSeatNO.Focus();
                    return;
                }
                if (tbSeatNO.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Seat/Cabin No Can Be Maximum 10 Characters.";
                    tbSeatNO.Focus();
                    return;
                }
                if (cbreservation.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Seat Status.";
                    cbreservation.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvSeatsList.CurrentRow.Cells[0].Value);
                    var result = db.Seats.Where(x => x.AirplaneCode == cbAirplane.SelectedValue.ToString() && x.TicketTypeId == int.Parse(cbticketType.SelectedValue.ToString()) && x.SeatNo.Trim().ToUpper() == tbSeatNO.Text.Trim().ToUpper() && x.SeatId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbSeatNO.Focus();
                        return;
                    }
                    Seats s = db.Seats.Where(x => x.SeatId == int.Parse(ID)).FirstOrDefault();
                    s.AirplaneCode = cbAirplane.SelectedValue.ToString();
                    s.TicketTypeId = int.Parse(cbticketType.SelectedValue.ToString());
                    s.SeatNo = tbSeatNO.Text.Trim();
                    s.ReservationStatus = cbreservation.Text == "Empty" ? 0 : 1;
                    db.Seats.Update(s);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSeatsList != null && dgvSeatsList.Rows.Count > 0)
                {
                    if (dgvSeatsList.SelectedRows.Count == 1)
                    {
                        cbCompany.Text = Convert.ToString(dgvSeatsList.CurrentRow.Cells[1].Value);
                        cbAirplane.Text = Convert.ToString(dgvSeatsList.CurrentRow.Cells[2].Value);
                        cbticketType.Text = Convert.ToString(dgvSeatsList.CurrentRow.Cells[3].Value);
                        tbSeatNO.Text = Convert.ToString(dgvSeatsList.CurrentRow.Cells[4].Value);
                        cbreservation.Text = Convert.ToString(dgvSeatsList.CurrentRow.Cells[5].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSeatsList != null && dgvSeatsList.Rows.Count > 0)
                {
                    if (dgvSeatsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvSeatsList.CurrentRow.Cells[0].Value);
                                Seats ac = new Seats();
                                var entry = db.Entry(ac);
                                ac.SeatId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Seats.Attach(ac);
                                    db.Seats.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

 
        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void cbCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshAirplanes();
        }


    }
}
