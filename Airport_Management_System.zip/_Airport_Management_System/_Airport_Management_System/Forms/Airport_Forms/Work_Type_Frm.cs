﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Work_Type_Frm : Form
    {
        public Work_Type_Frm()
        {
            InitializeComponent();
        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvWorkTypeList.DataSource = (from a in db.WorkType
                                                      select new
                                                      {
                                                          ID = a.WorkTypeId,
                                                          Work_Type = a.WorkName,
                                                          No_Of_Hours = a.NumOfHours,
                                                          Fee_Per_Hours = a.FeePerHour,
                                                          Salary = a.NumOfHours* a.FeePerHour
                                                      }).ToList();
                        dgvWorkTypeList.Columns[0].Width = 130;
                        dgvWorkTypeList.Columns[1].Width = 130;
                        dgvWorkTypeList.Columns[2].Width = 130;
                        dgvWorkTypeList.Columns[3].Width = 130;
                        dgvWorkTypeList.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvWorkTypeList.DataSource = (from a in db.WorkType
                                                      where (a.WorkName.Contains(searchvalue) || a.NumOfHours.ToString().Contains(searchvalue) || a.FeePerHour.ToString().Contains(searchvalue))
                                                      select new
                                                      {
                                                          ID = a.WorkTypeId,
                                                          Work_Type = a.WorkName,
                                                          No_Of_Hours = a.NumOfHours,
                                                          Fee_Per_Hours = a.FeePerHour,
                                                          Salary = a.NumOfHours * a.FeePerHour
                                                      }).ToList();
                        dgvWorkTypeList.Columns[0].Width = 130;
                        dgvWorkTypeList.Columns[1].Width = 130;
                        dgvWorkTypeList.Columns[2].Width = 130;
                        dgvWorkTypeList.Columns[3].Width = 130;
                        dgvWorkTypeList.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            try
            {
                if (tbTypeName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Work Type Name.";
                    tbTypeName.Focus();
                    return;
                }
                if (tbTypeName.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Company Name Can Be Maximum 20 Characters.";
                    tbTypeName.Focus();
                    return;
                }
                if (tbNoofHours.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Number of Hours.";
                    tbNoofHours.Focus();
                    return;
                }
                if (!Int32.TryParse(tbNoofHours.Text, out int value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbNoofHours.Focus();
                    return;
                }
                if (tbFee.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Fee Per Hour.";
                    tbFee.Focus();
                    return;
                }
                if (!decimal.TryParse(tbFee.Text, out decimal value1))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbFee.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.WorkType.Where(x => x.WorkName.ToLower() == tbTypeName.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbTypeName.Focus();
                        return;
                    }
                    WorkType wt = new WorkType();
                    wt.WorkName = tbTypeName.Text.Trim();
                    wt.NumOfHours = int.Parse(tbNoofHours.Text.Trim());
                    wt.FeePerHour = decimal.Parse(tbFee.Text.Trim());
                    db.WorkType.Add(wt);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        void Clear()
        {
            tbTypeName.Clear();
            tbSearch.Clear();
            tbNoofHours.Clear();
            tbFee.Clear();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvWorkTypeList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvWorkTypeList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void Work_Type_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;


        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvWorkTypeList != null && dgvWorkTypeList.Rows.Count > 0)
                {
                    if (dgvWorkTypeList.SelectedRows.Count == 1)
                    {
                        tbTypeName.Text = Convert.ToString(dgvWorkTypeList.CurrentRow.Cells[1].Value);
                        tbNoofHours.Text = Convert.ToString(dgvWorkTypeList.CurrentRow.Cells[2].Value);
                        tbFee.Text = Convert.ToString(dgvWorkTypeList.CurrentRow.Cells[3].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvWorkTypeList != null && dgvWorkTypeList.Rows.Count > 0)
                {
                    if (dgvWorkTypeList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvWorkTypeList.CurrentRow.Cells[0].Value);
                                WorkType d = new WorkType();
                                var entry = db.Entry(d);
                                d.WorkTypeId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.WorkType.Attach(d);
                                    db.WorkType.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbTypeName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Work Type Name.";
                    tbTypeName.Focus();
                    return;
                }
                if (tbTypeName.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Company Name Can Be Maximum 20 Characters.";
                    tbTypeName.Focus();
                    return;
                }
                if (tbNoofHours.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Number of Hours.";
                    tbNoofHours.Focus();
                    return;
                }
                if (!Int32.TryParse(tbNoofHours.Text, out int value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbNoofHours.Focus();
                    return;
                }
                if (tbFee.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Fee Per Hour.";
                    tbFee.Focus();
                    return;
                }
                if (!decimal.TryParse(tbFee.Text, out decimal value1))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbFee.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvWorkTypeList.CurrentRow.Cells[0].Value);
                    var result = db.WorkType.Where(x => x.WorkName.ToLower() == tbTypeName.Text.ToLower() && x.WorkTypeId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbTypeName.Focus();
                        return;
                    }
                    WorkType wt = db.WorkType.Where(x => x.WorkTypeId == int.Parse(ID)).FirstOrDefault();
                    wt.WorkName = tbTypeName.Text.Trim();
                    wt.NumOfHours = int.Parse(tbNoofHours.Text.Trim());
                    wt.FeePerHour = decimal.Parse(tbFee.Text.Trim());
                    db.WorkType.Update(wt);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

   

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

  
    }

}
