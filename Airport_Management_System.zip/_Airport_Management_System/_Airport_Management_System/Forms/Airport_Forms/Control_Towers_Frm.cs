﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Control_Towers_Frm : Form
    {
        public Control_Towers_Frm()
        {
            InitializeComponent();
        }

     
        void Clear()
        {
            tbCapacity.Clear();
            tbCTName.Clear();
            tbNoOfTow.Clear();
            cbAirportName.SelectedIndex = 0;
            tbRange.Clear();
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvControlTowersList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvControlTowersList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }

        void FillGrid(string searchvalue)
        {

            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvControlTowersList.DataSource = (from a in db.Airport
                                                        from b in db.ControlTower
                                                        where a.AirportCode == b.AirportCode
                                                        select new
                                                        {
                                                            ID = b.CtId,
                                                            Airport_Name = a.AirportName,
                                                            Control_Tower_Name = b.CtName,
                                                            Number_Of_Towers = b.NoOfTower,
                                                            Range = b.Range,
                                                            Controlling_Capacity = b.ControllingCapacity

                                                        }).ToList();
                        dgvControlTowersList.Columns[0].Width = 130;
                        dgvControlTowersList.Columns[1].Width = 130;
                        dgvControlTowersList.Columns[2].Width = 130;
                        dgvControlTowersList.Columns[3].Width = 130;
                        dgvControlTowersList.Columns[4].Width = 130;
                        dgvControlTowersList.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvControlTowersList.DataSource = (from a in db.Airport
                                                           from b in db.ControlTower
                                                           where a.AirportCode == b.AirportCode &&(a.AirportName.Contains(searchvalue)||b.CtName.Contains(searchvalue)||b.ControllingCapacity.Contains(searchvalue)||b.NoOfTower.ToString().Contains(searchvalue)||b.Range.ToString().Contains(searchvalue) )
                                                           select new
                                                           {
                                                               ID = b.CtId,
                                                               Airport_Name = a.AirportName,
                                                               Control_Tower_Name = b.CtName,
                                                               Number_Of_Towers = b.NoOfTower,
                                                               Range = b.Range,
                                                               Controlling_Capacity = b.ControllingCapacity

                                                           }).ToList();
                        dgvControlTowersList.Columns[0].Width = 130;
                        dgvControlTowersList.Columns[1].Width = 130;
                        dgvControlTowersList.Columns[2].Width = 130;
                        dgvControlTowersList.Columns[3].Width = 130;
                        dgvControlTowersList.Columns[4].Width = 130;
                        dgvControlTowersList.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport Name.";
                    cbAirportName.Focus();
                    return;
                }
                if (tbCTName.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Control Tower Name.";
                    tbCTName.Focus();
                    return;

                }
                if (tbCTName.Text.Length > 20)
                {
                    lblMessage.Text = "Gate House Name Can Be Maximum 20 Characters.";
                    tbCTName.Focus();
                    return;
                }
                if (tbRange.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Range.";
                    tbRange.Focus();
                    return;
                }
                if (!float.TryParse(tbRange.Text.Trim(), out float val))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbRange.Focus();
                    return;
                }

                if (tbNoOfTow.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Number Of Towers.";
                    tbNoOfTow.Focus();
                    return;
                }
                if (!int.TryParse(tbNoOfTow.Text.Trim(), out int val1))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbNoOfTow.Focus();
                    return;
                }
                if (tbCapacity.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Controlling Capacity.";
                    tbCapacity.Focus();
                    return;
                }

                if (tbCapacity.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Controlling Capacity Can Be Maximum 10 Characters.";
                    tbCapacity.Focus();
                    return;

                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.ControlTower.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString() && x.CtName == tbCTName.Text).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage.Text = "Control Tower Already Registered.";
                        tbCTName.Focus();
                        return;
                    }

                    ControlTower s = new ControlTower();
                    s.AirportCode = cbAirportName.SelectedValue.ToString();
                    s.CtName = tbCTName.Text.Trim();
                    s.Range = double.Parse(tbRange.Text.Trim());
                    s.NoOfTower = int.Parse(tbNoOfTow.Text.Trim());
                    s.ControllingCapacity = tbCapacity.Text.Trim();
                    db.ControlTower.Add(s);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                }


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport Name.";
                    cbAirportName.Focus();
                    return;
                }
                if (tbCTName.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Control Tower Name.";
                    tbCTName.Focus();
                    return;

                }
                if (tbCTName.Text.Length > 20)
                {
                    lblMessage.Text = "Gate House Name Can Be Maximum 20 Characters.";
                    tbCTName.Focus();
                    return;
                }
                if (tbRange.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Range.";
                    tbRange.Focus();
                    return;
                }
                if (!float.TryParse(tbRange.Text.Trim(), out float val))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbRange.Focus();
                    return;
                }

                if (tbNoOfTow.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Number Of Towers.";
                    tbNoOfTow.Focus();
                    return;
                }
                if (!int.TryParse(tbNoOfTow.Text.Trim(), out int val1))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbNoOfTow.Focus();
                    return;
                }
                if (tbCapacity.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Controlling Capacity.";
                    tbCapacity.Focus();
                    return;
                }

                if (tbCapacity.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Controlling Capacity Can Be Maximum 10 Characters.";
                    tbCapacity.Focus();
                    return;

                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[0].Value);
                    var result = db.ControlTower.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString() && x.CtName == tbCTName.Text && x.CtId != int.Parse(ID)).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage.Text = "Control Tower Already Registered.";
                        tbCTName.Focus();
                        return;
                    }

                    ControlTower s = db.ControlTower.Where(x => x.CtId == int.Parse(ID)).FirstOrDefault();
                    s.AirportCode = cbAirportName.SelectedValue.ToString();
                    s.CtName = tbCTName.Text.Trim();
                    s.Range = double.Parse(tbRange.Text.Trim());
                    s.NoOfTower = int.Parse(tbNoOfTow.Text.Trim());
                    s.ControllingCapacity = tbCapacity.Text.Trim();
                    db.ControlTower.Update(s);
                    db.SaveChanges();
                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                    DisableControls();
                }


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvControlTowersList != null && dgvControlTowersList.Rows.Count > 0)
                {
                    if (dgvControlTowersList.SelectedRows.Count == 1)
                    {
                        cbAirportName.Text = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[1].Value);
                        tbCTName.Text = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[2].Value);
                        tbNoOfTow.Text = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[3].Value);
                        tbRange.Text = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[4].Value);
                        tbCapacity.Text = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[5].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvControlTowersList != null && dgvControlTowersList.Rows.Count > 0)
                {
                    if (dgvControlTowersList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvControlTowersList.CurrentRow.Cells[0].Value);
                                ControlTower d = new ControlTower();
                                var entry = db.Entry(d);
                                d.CtId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.ControlTower.Attach(d);
                                    db.ControlTower.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Control_Towers_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports();
            FillGrid("");
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;
            label10.ForeColor = ThemeColor.SecondaryColor;

        }


    }
}
