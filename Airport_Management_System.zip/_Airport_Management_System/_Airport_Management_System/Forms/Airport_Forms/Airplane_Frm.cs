﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Airplane_Frm : Form
    {
        public Airplane_Frm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvAirplaneList.DataSource = (from a in db.AirlineCompany
                                                      from b in db.Airplane
                                                      where a.AcId == b.AcId
                                                      select new
                                                      {
                                                          Airline_Company = a.AcName,
                                                          Airplane_Code = b.AirplaneCode,
                                                          Airpane_Capacity = b.Capacity
                                                      }).ToList();
                        dgvAirplaneList.Columns[0].Width = 100;
                        dgvAirplaneList.Columns[1].Width = 150;
                        dgvAirplaneList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvAirplaneList.DataSource = (from a in db.AirlineCompany
                                                      from b in db.Airplane
                                                      where a.AcId == b.AcId && (a.AcName.Contains(searchvalue)||b.AirplaneCode.Contains(searchvalue) || b.Capacity.ToString().Contains(searchvalue))
                                                      select new
                                                      {
                                                          Airline_Company = a.AcName,
                                                          Airplane_Code = b.AirplaneCode,
                                                          Airpane_Capacity = b.Capacity
                                                      }).ToList();
                        dgvAirplaneList.Columns[0].Width = 100;
                        dgvAirplaneList.Columns[1].Width = 150;
                        dgvAirplaneList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void refreshAirlineCompanies()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Companies = db.AirlineCompany.ToList();
                Companies.Add(new AirlineCompany
                {
                    AcName = "--Select--"

                });
                Companies.Reverse();
                cbCompany.DisplayMember = "AcName";
                cbCompany.ValueMember = "AcId";
                cbCompany.DataSource = Companies;
                cbCompany.Refresh();
            }
        }

        private void Airplane_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirlineCompanies();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;

        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbCompany.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Company.";
                    cbCompany.Focus();
                    return;
                }
                
                if (tbAirplaneCode.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Airplane Code.";
                    tbAirplaneCode.Focus();
                    return;
                }
                if (tbAirplaneCode.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Airplane Code Can Be Maximum 10 Characters.";
                    tbAirplaneCode.Focus();
                    return;
                }
                if (tbCapacity.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Airplane Capacity.";
                    tbAirplaneCode.Focus();
                    return;
                }
                if (!Int32.TryParse(tbCapacity.Text, out int value) )
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbCapacity.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Airplane.Where(x => x.AirplaneCode.ToLower() == tbAirplaneCode.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbAirplaneCode.Focus();
                        return;
                    }
                    Airplane ap = new Airplane();
                    ap.AcId = int.Parse(cbCompany.SelectedValue.ToString());
                    ap.AirplaneCode = tbAirplaneCode.Text.Trim();
                    ap.Capacity = int.Parse(tbCapacity.Text.Trim());
                    db.Airplane.Add(ap);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        void Clear()
        {
            cbCompany.SelectedIndex = 0;
            tbAirplaneCode.Clear();
            tbCapacity.Clear();

        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvAirplaneList.Enabled = false;
            tbSearch.Enabled = false;
            tbAirplaneCode.ReadOnly = true;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvAirplaneList.Enabled = true;
            tbSearch.Enabled = true;
            tbAirplaneCode.ReadOnly = false;
            FillGrid("");
            Clear();

        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAirplaneList != null && dgvAirplaneList.Rows.Count > 0)
                {
                    if (dgvAirplaneList.SelectedRows.Count == 1)
                    {
                        cbCompany.Text = Convert.ToString(dgvAirplaneList.CurrentRow.Cells[0].Value);
                        tbAirplaneCode.Text = Convert.ToString(dgvAirplaneList.CurrentRow.Cells[1].Value);
                        tbCapacity.Text = Convert.ToString(dgvAirplaneList.CurrentRow.Cells[2].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (dgvAirplaneList != null && dgvAirplaneList.Rows.Count > 0)
                {
                    if (dgvAirplaneList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string AirplaneCode = Convert.ToString(dgvAirplaneList.CurrentRow.Cells[1].Value);
                                Airplane ac = new Airplane();
                                var entry = db.Entry(ac);
                                ac.AirplaneCode = AirplaneCode;
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Airplane.Attach(ac);
                                    db.Airplane.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbCompany.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Company.";
                    cbCompany.Focus();
                    return;
                }

                if (tbAirplaneCode.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Airplane Code.";
                    tbAirplaneCode.Focus();
                    return;
                }
                if (tbAirplaneCode.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Airplane Code Can Be Maximum 10 Characters.";
                    tbAirplaneCode.Focus();
                    return;
                }
                if (tbCapacity.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Airplane Capacity.";
                    tbAirplaneCode.Focus();
                    return;
                }
                if (!Int32.TryParse(tbCapacity.Text, out int value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbCapacity.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string AirplaneCode = Convert.ToString(dgvAirplaneList.CurrentRow.Cells[1].Value);
                    var result = db.Airplane.Where(x => x.AirplaneCode.ToLower() == tbAirplaneCode.Text.ToLower() && x.AirplaneCode != AirplaneCode)
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbAirplaneCode.Focus();
                        return;
                    }

                    Airplane ap = db.Airplane.Where(x => x.AirplaneCode == AirplaneCode).FirstOrDefault();
                    ap.AcId = int.Parse(cbCompany.SelectedValue.ToString());
                    ap.AirplaneCode = tbAirplaneCode.Text.Trim();
                    ap.Capacity = int.Parse(tbCapacity.Text.Trim());
                    db.Airplane.Update(ap);
                    db.SaveChanges();
                }

                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableControls();
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }


    }
}
