﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Gate_House_Frm : Form
    {
        public Gate_House_Frm()
        {
            InitializeComponent();
        }


        void Clear()
        {
            tbGHName.Clear();
            tbGhseats.Clear();
            tbCounters.Clear();
            cbAirportName.SelectedIndex = 0;
            tbJetBridge.Clear();
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvGateHousesList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvGateHousesList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }
        
        void FillGrid(string searchvalue)
        {
            
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvGateHousesList.DataSource = (from a in db.Airport
                                                   from b in db.Gatehouse
                                                   where a.AirportCode == b.AirportCode
                                                   select new
                                                   {
                                                       ID = b.GhId,
                                                       Airport_Name = a.AirportName,
                                                       GH_Name = b.GhName,
                                                       Seats = b.Seating,
                                                       Counters = b.Counters,
                                                       JetBridge = b.JetBridge

                                                   }).ToList();
                        dgvGateHousesList.Columns[0].Width = 130;
                        dgvGateHousesList.Columns[1].Width = 130;
                        dgvGateHousesList.Columns[2].Width = 130;
                        dgvGateHousesList.Columns[3].Width = 130;
                        dgvGateHousesList.Columns[4].Width = 130;
                        dgvGateHousesList.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvGateHousesList.DataSource = (from a in db.Airport
                                                        from b in db.Gatehouse
                                                        where a.AirportCode == b.AirportCode &&(a.AirportName.Contains(searchvalue) || b.GhName.Contains(searchvalue)|| b.Seating.Contains(searchvalue)|| b.JetBridge.Contains(searchvalue) || b.Counters.Contains(searchvalue))
                                                        select new
                                                        {
                                                            ID = b.GhId,
                                                            Airport_Name = a.AirportName,
                                                            GH_Name = b.GhName,
                                                            Seats = b.Seating,
                                                            Counters = b.Counters,
                                                            JetBridge = b.JetBridge

                                                        }).ToList();
                        dgvGateHousesList.Columns[0].Width = 130;
                        dgvGateHousesList.Columns[1].Width = 130;
                        dgvGateHousesList.Columns[2].Width = 130;
                        dgvGateHousesList.Columns[3].Width = 130;
                        dgvGateHousesList.Columns[4].Width = 130;
                        dgvGateHousesList.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
            
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0 )
                {
                    lblMessage.Text = "Please Select Airport Name.";
                    cbAirportName.Focus();
                    return;
                }
                if (tbGHName.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Gate House Name.";
                    tbGHName.Focus();
                    return;

                }
                if (tbGHName.Text.Length > 20)
                {
                    lblMessage.Text = "Gate House Name Can Be Maximum 20 Characters.";
                    tbGHName.Focus();
                    return;
                }
                if (tbGhseats.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Seats Number.";
                    tbGhseats.Focus();
                    return;
                }
                if (!int.TryParse(tbGhseats.Text.Trim(), out int val))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbGhseats.Focus();
                    return;
                }
                if (tbGhseats.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Seats Number Can Be Maximum 10 Characters.";
                    tbGhseats.Focus();
                    return;

                }
                if (tbCounters.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Counters.";
                    tbCounters.Focus();
                    return;
                }
                if (!int.TryParse(tbCounters.Text.Trim(), out int val1))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbCounters.Focus();
                    return;
                }
                if (tbCounters.Text.Trim().Length > 10)
                {
                    lblMessage1.Text = "Counters Can Be Maximum 10 Characters.";
                    tbCounters.Focus();
                    return;

                }
                if (tbJetBridge.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Jet Bridge.";
                    tbJetBridge.Focus();
                    return;
                }
                
                if (tbJetBridge.Text.Trim().Length > 10)
                {
                    lblMessage1.Text = "Jet Bridge Can Be Maximum 10 Characters.";
                    tbJetBridge.Focus();
                    return;

                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Gatehouse.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString() && x.GhName == tbGHName.Text).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage.Text = "Gate house Already Registered.";
                        tbGHName.Focus();
                        return;
                    }

                    Gatehouse s = new Gatehouse();
                    s.AirportCode = cbAirportName.SelectedValue.ToString();
                    s.GhName = tbGHName.Text.Trim();
                    s.Seating = tbGhseats.Text.Trim();
                    s.Counters = tbCounters.Text.Trim();
                    s.JetBridge = tbJetBridge.Text.Trim();
                    db.Gatehouse.Add(s);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");


                }


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport Name.";
                    cbAirportName.Focus();
                    return;
                }
                if (tbGHName.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Gate House Name.";
                    tbGHName.Focus();
                    return;

                }
                if (tbGHName.Text.Length > 20)
                {
                    lblMessage.Text = "Gate House Name Can Be Maximum 20 Characters.";
                    tbGHName.Focus();
                    return;
                }
                if (tbGhseats.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Seats Number.";
                    tbGhseats.Focus();
                    return;
                }
                if (!int.TryParse(tbGhseats.Text.Trim(), out int val))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbGhseats.Focus();
                    return;
                }
                if (tbGhseats.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Seats Number Can Be Maximum 10 Characters.";
                    tbGhseats.Focus();
                    return;

                }
                if (tbCounters.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Counters.";
                    tbCounters.Focus();
                    return;
                }
                if (!int.TryParse(tbCounters.Text.Trim(), out int val1))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbCounters.Focus();
                    return;
                }
                if (tbCounters.Text.Trim().Length > 10)
                {
                    lblMessage1.Text = "Counters Can Be Maximum 10 Characters.";
                    tbCounters.Focus();
                    return;

                }
                if (tbJetBridge.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Jet Bridge.";
                    tbJetBridge.Focus();
                    return;
                }

                if (tbJetBridge.Text.Trim().Length > 10)
                {
                    lblMessage1.Text = "Jet Bridge Can Be Maximum 10 Characters.";
                    tbJetBridge.Focus();
                    return;

                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[0].Value);
                    var result = db.Gatehouse.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString() && x.GhName == tbGHName.Text && x.GhId != int.Parse(ID)).FirstOrDefault();
                    if (result != null)
                    {
                        lblMessage.Text = "Gate house Already Registered.";
                        tbGHName.Focus();
                        return;
                    }

                    Gatehouse s =db.Gatehouse.Where(x => x.GhId == int.Parse(ID)).FirstOrDefault();
                    s.AirportCode = cbAirportName.SelectedValue.ToString();
                    s.GhName = tbGHName.Text.Trim();
                    s.Seating = tbGhseats.Text.Trim();
                    s.Counters = tbCounters.Text.Trim();
                    s.JetBridge = tbJetBridge.Text.Trim();
                    db.Gatehouse.Update(s);
                    db.SaveChanges();
                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                    DisableControls();


                }


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGateHousesList != null && dgvGateHousesList.Rows.Count > 0)
                {
                    if (dgvGateHousesList.SelectedRows.Count == 1)
                    {
                        cbAirportName.Text = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[1].Value);
                        tbGHName.Text = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[2].Value);
                        tbGhseats.Text = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[3].Value);
                        tbCounters.Text = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[4].Value);
                        tbJetBridge.Text = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[5].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGateHousesList != null && dgvGateHousesList.Rows.Count > 0)
                {
                    if (dgvGateHousesList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvGateHousesList.CurrentRow.Cells[0].Value);
                                Gatehouse d = new Gatehouse();
                                var entry = db.Entry(d);
                                d.GhId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Gatehouse.Attach(d);
                                    db.Gatehouse.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Gate_House_Frm_Load(object sender, EventArgs e)
        {
            refreshAirports();
            FillGrid("");
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;
            label10.ForeColor = ThemeColor.SecondaryColor;
            


        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }


    }
}
