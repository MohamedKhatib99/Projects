﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Flights_Frm : Form
    {
        bool status;
        public Flights_Frm()
        {
            InitializeComponent();
            cbControlTwr.SelectedIndex = 0;
            cbGates.SelectedIndex = 0;
            cbAirplane.SelectedIndex = 0;
            status = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        void FillGrid(string searchvalue)
        {

            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvFlightsList.DataSource = (from a in db.Airport
                                                     from b in db.ControlTower
                                                     from c in db.Flights
                                                     from d in db.AirlineCompany
                                                     from e in db.Airplane
                                                     from g in db.Gate
                                                     where c.GateNo == g.GateNo &&a.AirportCode == b.AirportCode && b.CtId == c.CtId && d.AcId == e.AcId && e.AirplaneCode == c.AirplaneCode
                                                     select new
                                                     {
                                                         ID = c.FlightNo,
                                                         Airport_Name = a.AirportName,
                                                         Control_Tower = b.CtName,
                                                         Flight_Name = c.FlightName,
                                                         Airline_Company = d.AcName,
                                                         Airplane_Code = e.AirplaneCode,
                                                         Flight_Date = c.FlightDate.ToString("dd/MMMM/yyyy"),
                                                         From = c.StartPoint,
                                                         To = c.EndPoint,
                                                         Departure_Time = c.DepartureTime,
                                                         Arrival_Time = c.ArrivalTime,
                                                         Gate_No = g.GateNo,
                                                         Available_Tickets = c.AvailableTickets,
                                                         Sold_Tickets = c.SoldTickets,

                                                     }).ToList();
                        dgvFlightsList.Columns[0].Width = 90;
                        dgvFlightsList.Columns[1].Width = 130;
                        dgvFlightsList.Columns[2].Width = 130;
                        dgvFlightsList.Columns[3].Width = 130;
                        dgvFlightsList.Columns[4].Width = 130;
                        dgvFlightsList.Columns[5].Width = 130;
                        dgvFlightsList.Columns[6].Width = 130;
                        dgvFlightsList.Columns[7].Width = 130;
                        dgvFlightsList.Columns[8].Width = 130;
                        dgvFlightsList.Columns[9].Width = 120;
                        dgvFlightsList.Columns[10].Width = 120;
                        dgvFlightsList.Columns[11].Width = 90;
                        dgvFlightsList.Columns[12].Width = 100;
                        dgvFlightsList.Columns[13].Width = 100;

                    }
                    else
                    {
                        dgvFlightsList.DataSource = (from a in db.Airport
                                                     from b in db.ControlTower
                                                     from c in db.Flights
                                                     from d in db.AirlineCompany
                                                     from e in db.Airplane
                                                     from g in db.Gate
                                                     where c.GateNo == g.GateNo && a.AirportCode == b.AirportCode && b.CtId == c.CtId && d.AcId == e.AcId && e.AirplaneCode == c.AirplaneCode && (a.AirportName.Contains(searchvalue) || b.CtName.Contains(searchvalue) || c.FlightDate.ToString().Contains(searchvalue) || c.StartPoint.Contains(searchvalue) || c.EndPoint.Contains(searchvalue) || c.DepartureTime.Contains(searchvalue) || c.ArrivalTime.Contains(searchvalue) || c.AvailableTickets.ToString().Contains(searchvalue) || c.FlightNo.Contains(searchvalue)||d.AcName.Contains(searchvalue)||e.AirplaneCode.Contains(searchvalue)||g.GateNo.Contains(searchvalue)|| c.FlightName.Contains(searchvalue))
                                                     select new
                                                     {
                                                         ID = c.FlightNo,
                                                         Airport_Name = a.AirportName,
                                                         Control_Tower = b.CtName,
                                                         Flight_Name = c.FlightName,
                                                         Airline_Company = d.AcName,
                                                         Airplane_Code = e.AirplaneCode,
                                                         Flight_Date = c.FlightDate.ToString("dd/MMMM/yyyy"),
                                                         From = c.StartPoint,
                                                         To = c.EndPoint,
                                                         Departure_Time = c.DepartureTime,
                                                         Arrival_Time = c.ArrivalTime,
                                                         Gate_No = g.GateNo,
                                                         Available_Tickets = c.AvailableTickets,
                                                         Sold_Tickets = c.SoldTickets,

                                                     }).ToList();
                        dgvFlightsList.Columns[0].Width = 90;
                        dgvFlightsList.Columns[1].Width = 130;
                        dgvFlightsList.Columns[2].Width = 130;
                        dgvFlightsList.Columns[3].Width = 130;
                        dgvFlightsList.Columns[4].Width = 130;
                        dgvFlightsList.Columns[5].Width = 130;
                        dgvFlightsList.Columns[6].Width = 130;
                        dgvFlightsList.Columns[7].Width = 130;
                        dgvFlightsList.Columns[8].Width = 130;
                        dgvFlightsList.Columns[9].Width = 120;
                        dgvFlightsList.Columns[10].Width = 120;
                        dgvFlightsList.Columns[11].Width = 90;
                        dgvFlightsList.Columns[12].Width = 100;
                        dgvFlightsList.Columns[13].Width = 100;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            cbControlTwr.SelectedIndex = 0;
            tbAvailableTickets.Clear();
            cbDepartureAir.SelectedIndex = 0;
            cbArrivalAir.SelectedIndex = 0;
            cbCompany.SelectedIndex = 0;
            cbAirplane.SelectedIndex = 0;
            cbGates.SelectedIndex = 0;
            tbSearch.Clear();
            dtpFDate.Value = DateTime.Now;
            dtpDeparture.Value = DateTime.Now;
            dtpArrival.Value = DateTime.Now;
            if (!status)
            {
                tbFlightCode.Clear();
            }

        }

        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvFlightsList.Enabled = false;
            tbSearch.Enabled = false;
            tbFlightCode.ReadOnly = true;
            status = true;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvFlightsList.Enabled = true;
            tbSearch.Enabled = true;
            tbFlightCode.ReadOnly = false;
            status = false;


            FillGrid("");
            Clear();

        }

        void refreshControlTowers()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                if (cbAirportName.SelectedIndex > 0)
                {
                    var Ctowers = db.ControlTower.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString()).ToList();
                    Ctowers.Add(new ControlTower
                    {
                        CtName = "--Select--"

                    });
                    Ctowers.Reverse();
                    cbControlTwr.DisplayMember = "CtName";
                    cbControlTwr.ValueMember = "CtId";
                    cbControlTwr.DataSource = Ctowers;
                    cbControlTwr.Refresh();
                }
                else
                {
                }
            }
        }
        void refreshAirports(ComboBox cb)
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cb.DisplayMember = "AirportName";
                cb.ValueMember = "AirportCode";
                cb.DataSource = Airports;
                cb.Refresh();
            }
        }
        void refreshAirlineCompanies()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Companies = db.AirlineCompany.ToList();
                Companies.Add(new AirlineCompany
                {
                    AcName = "--Select--"

                });
                Companies.Reverse();
                cbCompany.DisplayMember = "AcName";
                cbCompany.ValueMember = "AcId";
                cbCompany.DataSource = Companies;
                cbCompany.Refresh();
            }
        }

        void refreshAirplanes()
        {
            if (cbCompany.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var Airplanes = db.Airplane.Where(x => x.AcId == int.Parse(cbCompany.SelectedValue.ToString())).ToList();
                    Airplanes.Add(new Airplane
                    {
                        AirplaneCode = "--Select--"

                    });
                    Airplanes.Reverse();
                    cbAirplane.DisplayMember = "AirplaneCode";
                    cbAirplane.ValueMember = "AirplaneCode";
                    cbAirplane.DataSource = Airplanes;
                    cbAirplane.Refresh();
                }
            }
        }

        void refreshGates()
        {
            if (cbAirportName.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var Gates = db.Gate.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString()).ToList();
                    Gates.Add(new Gate
                    {
                        Purpose = "--Select--"

                    });
                    Gates.Reverse();
                    cbGates.DisplayMember = "Purpose";
                    cbGates.ValueMember = "GateNo";
                    cbGates.DataSource = Gates;
                    cbGates.Refresh();
                }
            }
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Flights_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports(cbAirportName);
            refreshGates();
            refreshAirports(cbDepartureAir);
            refreshAirports(cbArrivalAir);
            refreshAirlineCompanies();
            FillGrid("");

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;
            label10.ForeColor = ThemeColor.SecondaryColor;
            label11.ForeColor = ThemeColor.SecondaryColor;
            label12.ForeColor = ThemeColor.SecondaryColor;
            label13.ForeColor = ThemeColor.SecondaryColor;
            label14.ForeColor = ThemeColor.SecondaryColor;
            label15.ForeColor = ThemeColor.SecondaryColor;
            label16.ForeColor = ThemeColor.SecondaryColor;


        }

        private void cbAirportName_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshControlTowers();
            refreshGates();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport Name.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbControlTwr.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Control Tower.";
                    cbControlTwr.Focus();
                    return;
                }
                if (cbCompany.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airline Company.";
                    cbCompany.Focus();
                    return;

                }
                if (cbAirplane.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airplane Code.";
                    cbAirplane.Focus();
                    return;

                }
                if (tbFlightCode.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Flight Code.";
                    tbFlightCode.Focus();
                    return;

                }
                if (tbFlightCode.Text.Length > 10)
                {
                    lblMessage.Text = "Flight Code Can Be Maximum 10 Characters.";
                    tbFlightCode.Focus();
                    return;
                }
                if (tbFlightName.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Flight Name.";
                    tbFlightName.Focus();
                    return;

                }
                if (tbFlightName.Text.Length > 20)
                {
                    lblMessage.Text = "Flight Name Can Be Maximum 20 Characters.";
                    tbFlightName.Focus();
                    return;
                }
                if (cbGates.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Gate.";
                    cbGates.Focus();
                    return;
                }
                if (cbDepartureAir.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Departure Airport.";
                    cbDepartureAir.Focus();
                    return;
                }
                if (cbArrivalAir.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Arrival Airport.";
                    cbArrivalAir.Focus();
                    return;
                }
                if (cbDepartureAir.SelectedIndex == cbArrivalAir.SelectedIndex  )
                {
                    lblMessage1.Text = "Departure And Arrival Airports Can't Be Same!.";
                    cbArrivalAir.Focus();
                    return;
                }
                if (tbAvailableTickets.Text == "")
                {
                    lblMessage1.Text = "Please Select Available Tickets.";
                    tbAvailableTickets.Focus();
                    return;
                }
                if (!int.TryParse(tbAvailableTickets.Text , out int val))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbAvailableTickets.Focus();
                    return;
                }
                if (int.Parse(tbAvailableTickets.Text) < 0)
                {
                    lblMessage1.Text = "Tickets Number Can't Be Negative.";
                    tbAvailableTickets.Focus();
                    return;
                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    Flights f = new Flights();
                    f.FlightNo = tbFlightCode.Text.Trim();
                    f.AirplaneCode = cbAirplane.Text.Trim();
                    f.FlightName = tbFlightName.Text.Trim();
                    f.CtId = int.Parse(cbControlTwr.SelectedValue.ToString());
                    f.GateNo = cbGates.SelectedValue.ToString();
                    f.StartPoint = cbDepartureAir.Text;
                    f.EndPoint = cbArrivalAir.Text;
                    f.SoldTickets = 0;
                    f.FlightDate = dtpFDate.Value.Date;
                    f.DepartureTime = (dtpDeparture.Value.ToString("t")).ToString();
                    f.ArrivalTime = (dtpArrival.Value.ToString("t")).ToString();
                    f.AvailableTickets = int.Parse(tbAvailableTickets.Text.Trim());
                    db.Flights.Add(f);
                    db.SaveChanges();

                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshAirplanes();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport Name.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbControlTwr.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Control Tower.";
                    cbControlTwr.Focus();
                    return;
                }
                if (cbCompany.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airline Company.";
                    cbCompany.Focus();
                    return;

                }
                if (cbAirplane.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airplane Code.";
                    cbAirplane.Focus();
                    return;

                }
                if (tbFlightCode.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Flight Code.";
                    tbFlightCode.Focus();
                    return;

                }
                if (tbFlightCode.Text.Length > 10)
                {
                    lblMessage.Text = "Flight Code Can Be Maximum 10 Characters.";
                    tbFlightCode.Focus();
                    return;
                }
                if (tbFlightName.Text.Trim() == "")
                {
                    lblMessage.Text = "Please Enter Flight Name.";
                    tbFlightName.Focus();
                    return;

                }
                if (tbFlightName.Text.Length > 20)
                {
                    lblMessage.Text = "Flight Name Can Be Maximum 20 Characters.";
                    tbFlightName.Focus();
                    return;
                }
                if (cbGates.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Gate.";
                    cbGates.Focus();
                    return;
                }
                if (cbDepartureAir.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Departure Airport.";
                    cbDepartureAir.Focus();
                    return;
                }
                if (cbArrivalAir.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Arrival Airport.";
                    cbArrivalAir.Focus();
                    return;
                }
                if (cbDepartureAir.SelectedIndex == cbArrivalAir.SelectedIndex)
                {
                    lblMessage1.Text = "Departure And Arrival Airports Can't Be Same!.";
                    cbArrivalAir.Focus();
                    return;
                }
                if (tbAvailableTickets.Text == "")
                {
                    lblMessage1.Text = "Please Select Available Tickets.";
                    tbAvailableTickets.Focus();
                    return;
                }
                if (!int.TryParse(tbAvailableTickets.Text, out int val))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbAvailableTickets.Focus();
                    return;
                }
                if (int.Parse(tbAvailableTickets.Text) < 0)
                {
                    lblMessage1.Text = "Tickets Number Can't Be Negative.";
                    tbAvailableTickets.Focus();
                    return;
                }



                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvFlightsList.CurrentRow.Cells[0].Value);
                    Flights f = db.Flights.Where(x => x.FlightNo == ID).FirstOrDefault();
                    f.FlightNo = tbFlightCode.Text.Trim();
                    f.AirplaneCode = cbAirplane.Text.Trim();
                    f.FlightName = tbFlightName.Text.Trim();
                    f.CtId = int.Parse(cbControlTwr.SelectedValue.ToString());
                    f.GateNo = cbGates.SelectedValue.ToString();
                    f.StartPoint = cbDepartureAir.Text;
                    f.EndPoint = cbArrivalAir.Text;
                    f.FlightDate = dtpFDate.Value.Date;
                    f.DepartureTime = (dtpDeparture.Value.ToString("t")).ToString();
                    f.ArrivalTime = (dtpArrival.Value.ToString("t")).ToString();
                    f.AvailableTickets = int.Parse(tbAvailableTickets.Text.Trim());
                    db.Flights.Update(f);
                    db.SaveChanges();

                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFlightsList != null && dgvFlightsList.Rows.Count > 0)
                {
                    if (dgvFlightsList.SelectedRows.Count == 1)
                    {
                        tbFlightCode.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[0].Value);
                        cbAirportName.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[1].Value);
                        cbControlTwr.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[2].Value);
                        tbFlightName.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[3].Value);
                        cbCompany.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[4].Value);
                        cbAirplane.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[5].Value);
                        dtpFDate.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[6].Value);
                        cbDepartureAir.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[7].Value);
                        cbArrivalAir.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[8].Value);
                        dtpDeparture.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[9].Value);
                        dtpArrival.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[10].Value);
                        cbGates.SelectedValue = Convert.ToString(dgvFlightsList.CurrentRow.Cells[11].Value);
                        tbAvailableTickets.Text = Convert.ToString(dgvFlightsList.CurrentRow.Cells[12].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFlightsList != null && dgvFlightsList.Rows.Count > 0)
                {
                    if (dgvFlightsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvFlightsList.CurrentRow.Cells[0].Value);
                                Flights d = new Flights();
                                var entry = db.Entry(d);
                                d.FlightNo = ID;
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Flights.Attach(d);
                                    db.Flights.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void setPricesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFlightsList != null && dgvFlightsList.Rows.Count > 0)
                {
                    if (dgvFlightsList.SelectedRows.Count == 1)
                    {
                        string FNO = Convert.ToString(dgvFlightsList.CurrentRow.Cells[0].Value);
                        Flights_prices f = new Flights_prices(FNO);
                        f.Show();

                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
