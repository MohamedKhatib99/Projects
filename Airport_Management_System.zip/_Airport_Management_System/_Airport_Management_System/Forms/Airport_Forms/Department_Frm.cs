﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Department_Frm : Form
    {
        public Department_Frm()
        {
            InitializeComponent();
        }


        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvDepartmentsList.DataSource = (from b in db.Department
                                                         select new
                                                         {
                                                             ID = b.DeptId,
                                                             Department = b.DeptName,
                                                         }).ToList();
                        dgvDepartmentsList.Columns[0].Width = 150;
                        dgvDepartmentsList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvDepartmentsList.DataSource = db.Department.Where(x => x.DeptName.Contains(searchvalue))
                                                        .Select(b => new
                                                        {
                                                            ID = b.DeptId,
                                                            Department = b.DeptName,
                                                        })
                                                        .ToList();
                        dgvDepartmentsList.Columns[0].Width = 150;
                        dgvDepartmentsList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void Clear()
        {
            tbDept.Clear();
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvDepartmentsList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvDepartmentsList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbDept.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Department Name.";
                    tbDept.Focus();
                    return;
                }
                if (tbDept.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Department Name Can Be Maximum 20 Characters.";
                    tbDept.Focus();
                    return;
                }
               
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Department.Where(x => x.DeptName.ToLower() == tbDept.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbDept.Focus();
                        return;
                    }
                    Department d = new Department();
                    d.DeptName = tbDept.Text.Trim();
                    db.Department.Add(d);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDepartmentsList != null && dgvDepartmentsList.Rows.Count > 0)
                {
                    if (dgvDepartmentsList.SelectedRows.Count == 1)
                    {
                        tbDept.Text = Convert.ToString(dgvDepartmentsList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbDept.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Department Name.";
                    tbDept.Focus();
                    return;
                }
                if (tbDept.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Department Name Can Be Maximum 20 Characters.";
                    tbDept.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvDepartmentsList.CurrentRow.Cells[0].Value);

                    var result = db.Department.Where(x => x.DeptName.ToLower() == tbDept.Text.ToLower() && x.DeptId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbDept.Focus();
                        return;
                    }
                    Department d = db.Department.Where(x => x.DeptId == int.Parse(ID)).FirstOrDefault();
                    d.DeptName = tbDept.Text.Trim();
                    db.Department.Update(d);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDepartmentsList != null && dgvDepartmentsList.Rows.Count > 0)
                {
                    if (dgvDepartmentsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvDepartmentsList.CurrentRow.Cells[0].Value);
                                Department d = new Department();
                                var entry = db.Entry(d);
                                d.DeptId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Department.Attach(d);
                                    db.Department.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Department_Frm_Load(object sender, EventArgs e)
        {
            FillGrid("");
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }


    }
}
