﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Landing_Area_Frm : Form
    {
        public Landing_Area_Frm()
        {
            InitializeComponent();
        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvAreasList.DataSource = (from a in db.Airport
                                                   from b in db.LandingArea
                                                   where a.AirportCode == b.AirportCode
                                                   select new
                                                   {
                                                       ID = b.LaId,
                                                       Airport_Name = a.AirportName,
                                                       AreaName = b.AreaName,
                                                       AreaCovered = b.AreaCovered

                                                   }).ToList();
                        dgvAreasList.Columns[0].Visible = false;
                        dgvAreasList.Columns[1].Width = 130;
                        dgvAreasList.Columns[2].Width = 130;
                        dgvAreasList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvAreasList.DataSource = (from a in db.Airport
                                                   from b in db.LandingArea
                                                   where a.AirportCode == b.AirportCode &&(a.AirportName.Contains(searchvalue) || b.AreaName.Contains(searchvalue) || b.AreaCovered.ToString().Contains(searchvalue))
                                                   select new 
                                                   {
                                                       ID = b.LaId,
                                                       Airport_Name = a.AirportName,
                                                       AreaName = b.AreaName,
                                                       AreaCovered = b.AreaCovered

                                                   }).ToList();
                        dgvAreasList.Columns[0].Visible = false;
                        dgvAreasList.Columns[1].Width = 130;
                        dgvAreasList.Columns[2].Width = 130;
                        dgvAreasList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void Clear()
        {
            tbAreaName.Clear();
            tbAreaCovered.Clear();
            cbAirportName.SelectedIndex = 0;
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvAreasList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvAreasList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void Landing_Area_Frm_Load(object sender, EventArgs e)
        {
            refreshAirports();
            FillGrid("");
            LoadTheme();

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;

        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            try
            {
                if (tbAreaName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Area Name.";
                    tbAreaName.Focus();
                    return;
                }
                if (tbAreaName.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Area Name Can Be Maximum 10 Characters.";
                    tbAreaName.Focus();
                    return;
                }

                if (tbAreaCovered.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Area Covered.";
                    tbAreaCovered.Focus();
                    return;
                }
                if (!double.TryParse(tbAreaCovered.Text,out double value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbAreaCovered.Focus();
                    return;
                }

                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.LandingArea.Where(x => x.AirportCode.ToLower() == cbAirportName.SelectedValue.ToString().ToLower() && x.AreaName.ToLower() == tbAreaName.Text.Trim().ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbAreaName.Focus();
                        return;
                    }
                    LandingArea L = new LandingArea();
                    L.AreaName = tbAreaName.Text.Trim();
                    L.AreaCovered = double.Parse(tbAreaCovered.Text.Trim());
                    L.AirportCode = cbAirportName.SelectedValue.ToString();
                    db.LandingArea.Add(L);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {

            try
            {
                if (tbAreaName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Area Name.";
                    tbAreaName.Focus();
                    return;
                }
                if (tbAreaName.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Area Name Can Be Maximum 10 Characters.";
                    tbAreaName.Focus();
                    return;
                }

                if (tbAreaCovered.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Area Covered.";
                    tbAreaCovered.Focus();
                    return;
                }
                if (!double.TryParse(tbAreaCovered.Text, out double value))
                {
                    lblMessage.Text = "Please Enter Valid Number.";
                    tbAreaCovered.Focus();
                    return;
                }

                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvAreasList.CurrentRow.Cells[0].Value);
                    var result = db.LandingArea.Where(x => x.AirportCode.ToLower() == cbAirportName.SelectedValue.ToString().ToLower() && x.AreaName.ToLower() == tbAreaName.Text.Trim().ToLower() && x.LaId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbAreaName.Focus();
                        return;
                    }
                    LandingArea L = db.LandingArea.Where(x => x.LaId == int.Parse(ID)).FirstOrDefault();
                    L.AreaName = tbAreaName.Text.Trim();
                    L.AreaCovered = double.Parse(tbAreaCovered.Text.Trim());
                    L.AirportCode = cbAirportName.SelectedValue.ToString();
                    db.LandingArea.Update(L);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAreasList != null && dgvAreasList.Rows.Count > 0)
                {
                    if (dgvAreasList.SelectedRows.Count == 1)
                    {
                        tbAreaCovered.Text = Convert.ToString(dgvAreasList.CurrentRow.Cells[3].Value);
                        tbAreaName.Text = Convert.ToString(dgvAreasList.CurrentRow.Cells[2].Value);
                        cbAirportName.Text = Convert.ToString(dgvAreasList.CurrentRow.Cells[1].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAreasList != null && dgvAreasList.Rows.Count > 0)
                {
                    if (dgvAreasList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvAreasList.CurrentRow.Cells[0].Value);
                                LandingArea ac = new LandingArea();
                                var entry = db.Entry(ac);
                                ac.LaId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.LandingArea.Attach(ac);
                                    db.LandingArea.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

   
    }
}
