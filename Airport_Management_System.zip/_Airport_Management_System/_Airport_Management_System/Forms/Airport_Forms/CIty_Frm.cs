﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class CIty_Frm : Form
    {
        public CIty_Frm()
        {
            InitializeComponent();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvCitiesList.DataSource = (from b in db.City
                                                         select new
                                                         {
                                                             ID = b.CityId,
                                                             City_Name = b.CityName,
                                                             Country = b.Country
                                                         }).ToList();
                        dgvCitiesList.Columns[0].Width = 100;
                        dgvCitiesList.Columns[1].Width = 150;
                        dgvCitiesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvCitiesList.DataSource = db.City.Where(x => x.CityName.Contains(searchvalue) || x.Country.Contains(searchvalue))
                                                        .Select(b => new
                                                        {
                                                            ID = b.CityId,
                                                            City_Name = b.CityName,
                                                            Country = b.Country
                                                        })
                                                        .ToList();
                        dgvCitiesList.Columns[0].Width = 100;
                        dgvCitiesList.Columns[1].Width = 150;
                        dgvCitiesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        void Clear()
        {
            tbCity.Clear();
            tbCountry.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvCitiesList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvCitiesList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        private void btnsave_Click(object sender, EventArgs e)
        {

            try
            {
                if (tbCity.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter City Name.";
                    tbCity.Focus();
                    return;
                }
                if (tbCity.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Company Name Can Be Maximum 20 Characters.";
                    tbCity.Focus();
                    return;
                }
                if (tbCountry.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Country.";
                    tbCountry.Focus();
                    return;
                }
                if (tbCountry.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Country Can Be Maximum 20 Characters.";
                    tbCountry.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.City.Where(x => x.CityName.ToLower() == tbCity.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbCity.Focus();
                        return;
                    }
                    City c = new City();
                    c.CityName = tbCity.Text.Trim();
                    c.Country = tbCountry.Text.Trim();
                    db.City.Add(c);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (dgvCitiesList != null && dgvCitiesList.Rows.Count > 0)
                {
                    if (dgvCitiesList.SelectedRows.Count == 1)
                    {
                        tbCity.Text = Convert.ToString(dgvCitiesList.CurrentRow.Cells[1].Value);
                        tbCountry.Text = Convert.ToString(dgvCitiesList.CurrentRow.Cells[2].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCitiesList != null && dgvCitiesList.Rows.Count > 0)
                {
                    if (dgvCitiesList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvCitiesList.CurrentRow.Cells[0].Value);
                                City c = new City();
                                var entry = db.Entry(c);
                                c.CityId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.City.Attach(c);
                                    db.City.Remove(c);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbCity.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter City Name.";
                    tbCity.Focus();
                    return;
                }
                if (tbCity.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Company Name Can Be Maximum 20 Characters.";
                    tbCity.Focus();
                    return;
                }
                if (tbCountry.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Country.";
                    tbCountry.Focus();
                    return;
                }
                if (tbCountry.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Country Can Be Maximum 20 Characters.";
                    tbCountry.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvCitiesList.CurrentRow.Cells[0].Value);
                    var result = db.City.Where(x => x.CityName.ToLower() == tbCity.Text.ToLower() && x.CityId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbCity.Focus();
                        return;
                    }
                    City c = db.City.Where(x => x.CityId == int.Parse(ID)).FirstOrDefault();
                    c.CityName = tbCity.Text.Trim();
                    c.Country = tbCountry.Text.Trim();
                    db.City.Update(c);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableControls();
                Clear();
                FillGrid("");

            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

      

        private void CIty_Frm_Load(object sender, EventArgs e)
        {
            FillGrid("");
            LoadTheme();

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

    
    }
}
