﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Airline_Company_Frm : Form
    {
        public Airline_Company_Frm()
        {
            InitializeComponent();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvAirlinesComList.DataSource = (from b in db.AirlineCompany
                                                      select new
                                                      {
                                                          ID = b.AcId,
                                                          AirlineCompany = b.AcName,
                                                          Country = b.Country
                                                      }).ToList();
                        dgvAirlinesComList.Columns[0].Width = 100;
                        dgvAirlinesComList.Columns[1].Width = 150;
                        dgvAirlinesComList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvAirlinesComList.DataSource = db.AirlineCompany.Where(x => x.AcName.Contains(searchvalue))
                                                        .Select(b => new
                                                        {
                                                            ID = b.AcId,
                                                            AirlineCompany = b.AcName,
                                                            Country = b.Country
                                                        })
                                                        .ToList();
                        dgvAirlinesComList.Columns[0].Width = 100;
                        dgvAirlinesComList.Columns[1].Width = 150;
                        dgvAirlinesComList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            

            try
            {
                if (tbCompany.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Company Name.";
                    tbCompany.Focus();
                    return;
                }
                if (tbCompany.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Company Name Can Be Maximum 20 Characters.";
                    tbCompany.Focus();
                    return;
                }
                if (tbComCountry.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Country.";
                    tbComCountry.Focus();
                    return;
                }
                if (tbComCountry.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Country Can Be Maximum 20 Characters.";
                    tbComCountry.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.AirlineCompany.Where(x => x.AcName.ToLower() == tbCompany.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbCompany.Focus();
                        return;
                    }
                    AirlineCompany ac = new AirlineCompany();
                    ac.AcName = tbCompany.Text.Trim();
                    ac.Country = tbComCountry.Text.Trim();
                    db.AirlineCompany.Add(ac);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void Airline_Company_Frm_Load(object sender, EventArgs e)
        {
            FillGrid("");
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            tbCompany.Clear();
            tbComCountry.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (dgvAirlinesComList != null && dgvAirlinesComList.Rows.Count > 0)
                {
                    if (dgvAirlinesComList.SelectedRows.Count == 1)
                    {
                        tbCompany.Text = Convert.ToString(dgvAirlinesComList.CurrentRow.Cells[1].Value);
                        tbComCountry.Text = Convert.ToString(dgvAirlinesComList.CurrentRow.Cells[2].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvAirlinesComList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvAirlinesComList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void Clear()
        {
            tbCompany.Clear();
            tbComCountry.Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbCompany.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Company Name.";
                    tbCompany.Focus();
                    return;
                }
                if (tbCompany.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Company Name Can Be Maximum 20 Characters.";
                    tbCompany.Focus();
                    return;
                }
                if (tbComCountry.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Country.";
                    tbComCountry.Focus();
                    return;
                }
                if (tbComCountry.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Country Can Be Maximum 20 Characters.";
                    tbComCountry.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvAirlinesComList.CurrentRow.Cells[0].Value);

                    var result = db.AirlineCompany.Where(x => x.AcName.Trim().ToLower() == tbCompany.Text.Trim().ToLower() && x.AcId != int.Parse(ID))
                                                                                  .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbCompany.Focus();
                        return;
                    }
                    AirlineCompany ac = new AirlineCompany();
                    ac.AcName = tbCompany.Text.Trim();
                    ac.Country = tbComCountry.Text.Trim();
                    ac.AcId = int.Parse(ID);
                    db.AirlineCompany.Attach(ac);
                    db.Entry(ac).State = EntityState.Modified;
                    db.SaveChanges();
                }
                
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableControls();
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAirlinesComList != null && dgvAirlinesComList.Rows.Count > 0)
                {
                    if (dgvAirlinesComList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvAirlinesComList.CurrentRow.Cells[0].Value);
                                AirlineCompany ac = new AirlineCompany();
                                var entry = db.Entry(ac);
                                ac.AcId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.AirlineCompany.Attach(ac);
                                    db.AirlineCompany.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }
}
