﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class GHouse_Airplane_Transportation_Frm : Form
    {
        public GHouse_Airplane_Transportation_Frm()
        {
            InitializeComponent();
            cbGHname.SelectedIndex = 0;
            cbAirplane.SelectedIndex = 0;
            cbFlight.SelectedIndex = 0;
            cbBuscode.SelectedIndex = 0;

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        void refreshAirports(ComboBox cb)
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cb.DisplayMember = "AirportName";
                cb.ValueMember = "AirportCode";
                cb.DataSource = Airports;
                cb.Refresh();
            }
        }
        void refreshGateHouses()
        {
            if (cbAirportName.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var Ghouse = db.Gatehouse.Where(x =>x.AirportCode == cbAirportName.SelectedValue.ToString()).ToList();
                    Ghouse.Add(new Gatehouse
                    {
                        GhName = "--Select--"

                    });
                    Ghouse.Reverse();
                    cbGHname.DisplayMember = "GhName";
                    cbGHname.ValueMember = "GhId";
                    cbGHname.DataSource = Ghouse;
                    cbGHname.Refresh();
                }
            }
        }
        void refreshAirlineCompanies()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Companies = db.AirlineCompany.ToList();
                Companies.Add(new AirlineCompany
                {
                    AcName = "--Select--"

                });
                Companies.Reverse();
                cbAirlineCompany.DisplayMember = "AcName";
                cbAirlineCompany.ValueMember = "AcId";
                cbAirlineCompany.DataSource = Companies;
                cbAirlineCompany.Refresh();
            }
        }

        void refreshAirplanes()
        {
            if (cbAirlineCompany.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var Airplanes = db.Airplane.Where(x => x.AcId == int.Parse(cbAirlineCompany.SelectedValue.ToString())).ToList();
                    Airplanes.Add(new Airplane
                    {
                        AirplaneCode = "--Select--"

                    });
                    Airplanes.Reverse();
                    cbAirplane.DisplayMember = "AirplaneCode";
                    cbAirplane.ValueMember = "AirplaneCode";
                    cbAirplane.DataSource = Airplanes;
                    cbAirplane.Refresh();
                }
            }
        }

        void refreshFlights()
        {
            if (cbAirplane.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var Flights = db.Flights.Where(x => x.AirplaneCode == cbAirplane.SelectedValue.ToString()).ToList();
                    Flights.Add(new Flights
                    {
                        FlightName = "--Select--"

                    });
                    Flights.Reverse();
                    cbFlight.DisplayMember = "FlightName";
                    cbFlight.ValueMember = "FlightNo";
                    cbFlight.DataSource = Flights;
                    cbFlight.Refresh();
                }
            }
        }

        void refreshBuses()
        {
            if (cbFlight.SelectedIndex > 0)
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {

                    var Buses = (from b in db.Buses
                                 from t in db.InternalTransport
                                 from f in db.Flights
                                 where t.BusId == b.BusId && f.FlightNo == t.FlightNo && t.FlightNo == cbFlight.SelectedValue.ToString()
                                 select new
                                 {
                                     b.BusId,
                                     b.BusName,

                                 }).ToList();

                    cbBuscode.DisplayMember = "BusName";
                    cbBuscode.ValueMember = "BusId";
                    cbBuscode.DataSource = Buses;

                    cbBuscode.Text = "--Select--";
                }
            }
        }

        

        private void cbAirportName_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshGateHouses();

        }

        private void cbAirlineCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshAirplanes();

        }

        private void cbAirplane_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshFlights();
        }

        private void cbFlight_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshBuses();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            cbGHname.SelectedIndex = 0;
            cbAirlineCompany.SelectedIndex = 0;
            cbAirplane.SelectedIndex = 0;
            cbFlight.SelectedIndex = 0;
            cbBuscode.Text = "--Select";

        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvGHATsList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvGHATsList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvGHATsList.DataSource = (from gta in db.GhTransportAirplane
                                                   from a in db.Airplane
                                                   from b in db.Buses
                                                   from gh in db.Gatehouse
                                                   from i in db.InternalTransport
                                                   from f in db.Flights
                                                   from ar in db.Airport
                                                   from ac in db.AirlineCompany
                                                   where gta.AirplaneCode == a.AirplaneCode && gta.GhId == gh.GhId && gta.TransportNo == i.TransportNo &&b.BusId == i.BusId && f.FlightNo == i.FlightNo && gh.AirportCode == ar.AirportCode && a.AcId == ac.AcId
                                                   select new
                                                     {
                                                         ID = gta.GtaId,
                                                         Airport_Name = ar.AirportName,
                                                         Gate_House = gh.GhName,
                                                         Airline_Company = ac.AcName,
                                                         Airplane = a.AirplaneCode,
                                                         Flight_No = f.FlightNo,
                                                         Flight_Name = f.FlightName,
                                                         Bus_No = b.BusName,

                                                     }).ToList();
                        dgvGHATsList.Columns[0].Width = 100;
                        dgvGHATsList.Columns[1].Width = 120;
                        dgvGHATsList.Columns[2].Width = 120;
                        dgvGHATsList.Columns[3].Width = 120;
                        dgvGHATsList.Columns[4].Width = 110;
                        dgvGHATsList.Columns[5].Width = 110;
                        dgvGHATsList.Columns[6].Width = 120;
                        dgvGHATsList.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvGHATsList.DataSource = (from gta in db.GhTransportAirplane
                                                   from a in db.Airplane
                                                   from b in db.Buses
                                                   from gh in db.Gatehouse
                                                   from i in db.InternalTransport
                                                   from f in db.Flights
                                                   from ar in db.Airport
                                                   from ac in db.AirlineCompany
                                                   where gta.AirplaneCode == a.AirplaneCode && gta.GhId == gh.GhId && gta.TransportNo == i.TransportNo && b.BusId == i.BusId && f.FlightNo == i.FlightNo && gh.AirportCode == ar.AirportCode && a.AcId == ac.AcId
                                                   && (ar.AirportName.Contains(searchvalue)|| gh.GhName.Contains(searchvalue)||ac.AcName.Contains(searchvalue)||a.AirplaneCode.Contains(searchvalue)||f.FlightNo.Contains(searchvalue)||f.FlightName.Contains(searchvalue)||b.BusName.Contains(searchvalue))
                                                   select new
                                                   {
                                                       ID = gta.GtaId,
                                                       Airport_Name = ar.AirportName,
                                                       Gate_House = gh.GhName,
                                                       Airline_Company = ac.AcName,
                                                       Airplane = a.AirplaneCode,
                                                       Flight_No = f.FlightNo,
                                                       Flight_Name = f.FlightName,
                                                       Bus_No = b.BusName,

                                                   }).ToList();
                        dgvGHATsList.Columns[0].Width = 100;
                        dgvGHATsList.Columns[1].Width = 120;
                        dgvGHATsList.Columns[2].Width = 120;
                        dgvGHATsList.Columns[3].Width = 120;
                        dgvGHATsList.Columns[4].Width = 110;
                        dgvGHATsList.Columns[5].Width = 110;
                        dgvGHATsList.Columns[6].Width = 120;
                        dgvGHATsList.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbGHname.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Gate House.";
                    cbGHname.Focus();
                    return;
                }
                
                if (cbAirlineCompany.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airline Company.";
                    cbAirlineCompany.Focus();
                    return;

                }
                if (cbAirplane.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Airplane Code.";
                    cbAirplane.Focus();
                    return;
                }
                if (cbFlight.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Flight.";
                    cbFlight.Focus();
                    return;
                }

                
                if (cbBuscode.Text == "--Select--")
                {
                    lblMessage1.Text = "Please Select Bus No.";
                    cbBuscode.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    
                    InternalTransport i = db.InternalTransport.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString() && x.BusId == int.Parse(cbBuscode.SelectedValue.ToString())).FirstOrDefault();
                    var result = db.GhTransportAirplane.Where(x => x.GhId == int.Parse(cbGHname.SelectedValue.ToString()) && x.AirplaneCode == cbAirplane.SelectedValue.ToString() && x.TransportNo == i.TransportNo)
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage1.Text = "Already Registered !";
                        cbBuscode.Focus();
                        return;
                    }
                    GhTransportAirplane ght = new GhTransportAirplane();
                    ght.AirplaneCode = cbAirplane.SelectedValue.ToString();
                    ght.GhId = int.Parse(cbGHname.SelectedValue.ToString());
                    ght.TransportNo = i.TransportNo;
                    db.GhTransportAirplane.Add(ght);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");

                }


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbGHname.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Gate House.";
                    cbGHname.Focus();
                    return;
                }

                if (cbAirlineCompany.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airline Company.";
                    cbAirlineCompany.Focus();
                    return;

                }
                if (cbAirplane.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Airplane Code.";
                    cbAirplane.Focus();
                    return;
                }
                if (cbFlight.SelectedIndex == 0)
                {
                    lblMessage1.Text = "Please Select Flight.";
                    cbFlight.Focus();
                    return;
                }


                if (cbBuscode.Text == "--Select--")
                {
                    lblMessage1.Text = "Please Select Bus No.";
                    cbBuscode.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvGHATsList.CurrentRow.Cells[0].Value);

                    InternalTransport i = db.InternalTransport.Where(x => x.FlightNo == cbFlight.SelectedValue.ToString() && x.BusId == int.Parse(cbBuscode.SelectedValue.ToString())).FirstOrDefault();

                    var result = db.GhTransportAirplane.Where(x => x.GhId == int.Parse(cbGHname.SelectedValue.ToString()) && x.AirplaneCode == cbAirplane.SelectedValue.ToString() && x.TransportNo == i.TransportNo && x.GtaId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage1.Text = "Already Registered !";
                        cbBuscode.Focus();
                        return;
                    }
                    GhTransportAirplane ght = db.GhTransportAirplane.Where(x => x.GtaId == int.Parse(ID)).FirstOrDefault();
                    ght.AirplaneCode = cbAirplane.SelectedValue.ToString();
                    ght.GhId = int.Parse(cbGHname.SelectedValue.ToString());
                    ght.TransportNo = i.TransportNo;
                    db.GhTransportAirplane.Update(ght);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    FillGrid("");
                    DisableControls();

                }


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";


        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGHATsList != null && dgvGHATsList.Rows.Count > 0)
                {
                    if (dgvGHATsList.SelectedRows.Count == 1)
                    {
                        

                        cbAirportName.Text = Convert.ToString(dgvGHATsList.CurrentRow.Cells[1].Value);
                        cbGHname.Text = Convert.ToString(dgvGHATsList.CurrentRow.Cells[2].Value);
                        cbAirlineCompany.Text = Convert.ToString(dgvGHATsList.CurrentRow.Cells[3].Value);
                        cbAirplane.Text = Convert.ToString(dgvGHATsList.CurrentRow.Cells[4].Value);
                        cbFlight.Text = Convert.ToString(dgvGHATsList.CurrentRow.Cells[6].Value);
                        cbBuscode.Text = Convert.ToString(dgvGHATsList.CurrentRow.Cells[7].Value);
                        
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGHATsList != null && dgvGHATsList.Rows.Count > 0)
                {
                    if (dgvGHATsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvGHATsList.CurrentRow.Cells[0].Value);
                                GhTransportAirplane d = new GhTransportAirplane();
                                var entry = db.Entry(d);
                                d.GtaId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.GhTransportAirplane.Attach(d);
                                    db.GhTransportAirplane.Remove(d);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void GHouse_Airplane_Transportation_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshGateHouses();
            refreshAirlineCompanies();
            refreshAirports(cbAirportName);
            FillGrid("");
            Clear();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label9.ForeColor = ThemeColor.SecondaryColor;



        }


    }
}
