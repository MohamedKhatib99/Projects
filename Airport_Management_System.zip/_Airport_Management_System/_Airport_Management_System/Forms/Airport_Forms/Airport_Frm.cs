﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Airport_Frm : Form
    {
        public Airport_Frm()
        {
            InitializeComponent();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvAirportsList.DataSource = (from a in db.Airport
                                                      from b in db.City
                                                      where a.CityId == b.CityId
                                                      select new
                                                      {
                                                          Airport_Name = a.AirportName,
                                                          Airport_Code = a.AirportCode,
                                                          Country = b.Country,
                                                          City = b.CityName
                                                      }).ToList();
                        dgvAirportsList.Columns[0].Width = 130;
                        dgvAirportsList.Columns[1].Width = 130;
                        dgvAirportsList.Columns[2].Width = 130;
                        dgvAirportsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvAirportsList.DataSource = (from a in db.Airport
                                                      from b in db.City
                                                      where a.CityId == b.CityId && (a.AirportName.Contains(searchvalue)|| a.AirportCode.Contains(searchvalue)||b.CityName.Contains(searchvalue)||b.Country.Contains(searchvalue))
                                                      select new
                                                      {
                                                          Airport_Name = a.AirportName,
                                                          Airport_Code = a.AirportCode,
                                                          Country = b.Country,
                                                          City = b.CityName
                                                      }).ToList();
                        dgvAirportsList.Columns[0].Width = 130;
                        dgvAirportsList.Columns[1].Width = 130;
                        dgvAirportsList.Columns[2].Width = 130;
                        dgvAirportsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void refreshcities()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var cities = db.City.ToList();
                cities.Add(new City
                {
                    CityName = "--Select--"

                });
                cities.Reverse();
                cbAirportCity.DisplayMember = "CityName";
                cbAirportCity.ValueMember = "CityId";
                cbAirportCity.DataSource = cities;
                cbAirportCity.Refresh();
            }
        }
        void Clear()
        {
            cbAirportCity.SelectedIndex = 0;
            tbAirportCode.Clear();
            tbAirportName.Clear();

        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvAirportsList.Enabled = false;
            tbSearch.Enabled = false;
            tbAirportCode.ReadOnly = true;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvAirportsList.Enabled = true;
            tbSearch.Enabled = true;
            tbAirportCode.ReadOnly = false;
            FillGrid("");
            Clear();

        }
        private void Airport_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshcities();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
        }


        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            try
            {
                if (tbAirportName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Airport Name.";
                    tbAirportName.Focus();
                    return;
                }
                if (tbAirportName.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Airport Name Can Be Maximum 30 Characters.";
                    tbAirportName.Focus();
                    return;
                }

                if (tbAirportCode.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Select Airport Code.";
                    tbAirportCode.Focus();
                    return;
                }
                if (tbAirportCode.Text.Trim().Length >10)
                {
                    lblMessage.Text = "Airport Code Can Be Maximum 10 Characters.";
                    tbAirportCode.Focus();
                    return;
                }

                
                if (cbAirportCity.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select City.";
                    cbAirportCity.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Airport.Where(x => x.AirportCode.ToLower() == tbAirportCode.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbAirportCode.Focus();
                        return;
                    }
                    Airport ap = new Airport();
                    ap.AirportName = tbAirportName.Text.Trim();
                    ap.AirportCode = tbAirportCode.Text.Trim();
                    ap.CityId = int.Parse(cbAirportCity.SelectedValue.ToString());
                    db.Airport.Add(ap);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAirportsList != null && dgvAirportsList.Rows.Count > 0)
                {
                    if (dgvAirportsList.SelectedRows.Count == 1)
                    {
                        tbAirportName.Text = Convert.ToString(dgvAirportsList.CurrentRow.Cells[0].Value);
                        tbAirportCode.Text = Convert.ToString(dgvAirportsList.CurrentRow.Cells[1].Value);
                        cbAirportCity.Text = Convert.ToString(dgvAirportsList.CurrentRow.Cells[3].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (dgvAirportsList != null && dgvAirportsList.Rows.Count > 0)
                {
                    if (dgvAirportsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string AirportCode = Convert.ToString(dgvAirportsList.CurrentRow.Cells[1].Value);
                                Airport ac = new Airport();
                                var entry = db.Entry(ac);
                                ac.AirportCode = AirportCode;
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Airport.Attach(ac);
                                    db.Airport.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbAirportName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Airport Name.";
                    tbAirportName.Focus();
                    return;
                }
                if (tbAirportName.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Airport Name Can Be Maximum 30 Characters.";
                    tbAirportName.Focus();
                    return;
                }

                if (tbAirportCode.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Select Airport Code.";
                    tbAirportCode.Focus();
                    return;
                }
                if (tbAirportCode.Text.Trim().Length > 10)
                {
                    lblMessage.Text = "Airport Code Can Be Maximum 10 Characters.";
                    tbAirportCode.Focus();
                    return;
                }


                if (cbAirportCity.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select City.";
                    cbAirportCity.Focus();
                    return;
                }
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    String AirportCode = Convert.ToString(dgvAirportsList.CurrentRow.Cells[1].Value);
                    
                    Airport ap = db.Airport.Where(x => x.AirportCode == AirportCode).FirstOrDefault();
                    ap.AirportName = tbAirportName.Text.Trim();
                    ap.AirportCode = tbAirportCode.Text.Trim();
                    ap.CityId = int.Parse(cbAirportCity.SelectedValue.ToString());
                    db.Airport.Update(ap);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableControls();
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }


    }
}
