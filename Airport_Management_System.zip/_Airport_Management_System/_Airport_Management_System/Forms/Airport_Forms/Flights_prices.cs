﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Flights_prices : Form
    {
        string Fno = "";
        public Flights_prices(string fNO)
        {
            InitializeComponent();
            Fno = fNO;
        }
        public Flights_prices()
        {
            InitializeComponent();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvFlightsPrices.DataSource = (from a in db.Flights
                                                      from b in db.TicketType
                                                      from c in db.FlightsPrices
                                                      where a.FlightNo == c.FlightNo && b.TicketTypeId == c.TicketTypeId
                                                      select new
                                                      {
                                                          ID = c.PriceId,
                                                          Flight_No = a.FlightNo,
                                                          Flight_Name = a.FlightName,
                                                          Ticket_Type = b.TicketTypeName,
                                                          Price = c.Price

                                                      }).ToList();
                        dgvFlightsPrices.Columns[0].Width = 100;
                        dgvFlightsPrices.Columns[1].Width = 120;
                        dgvFlightsPrices.Columns[2].Width = 120;
                        dgvFlightsPrices.Columns[3].Width = 120;
                        dgvFlightsPrices.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {

                        dgvFlightsPrices.DataSource = (from a in db.Flights
                                                       from b in db.TicketType
                                                       from c in db.FlightsPrices
                                                       where a.FlightNo == c.FlightNo && b.TicketTypeId == c.TicketTypeId && (a.FlightName.Contains(searchvalue)||a.FlightNo.Contains(searchvalue)||b.TicketTypeName.Contains(searchvalue)||c.Price.ToString().Contains(searchvalue))
                                                       select new
                                                       {
                                                           ID = c.PriceId,
                                                           Flight_No = a.FlightNo,
                                                           Flight_Name = a.FlightName,
                                                           Ticket_Type = b.TicketTypeName,
                                                           Price = c.Price

                                                       }).ToList();
                        dgvFlightsPrices.Columns[0].Width = 100;
                        dgvFlightsPrices.Columns[1].Width = 120;
                        dgvFlightsPrices.Columns[2].Width = 120;
                        dgvFlightsPrices.Columns[3].Width = 120;
                        dgvFlightsPrices.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbFlightNo.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Flight No.";
                    cbFlightNo.Focus();
                    return;
                }

                if (cbTicketType.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Ticket Type.";
                    cbTicketType.Focus();
                    return;
                }

                if (tbPrice.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Price.";
                    tbPrice.Focus();
                    return;
                }
                if (!decimal.TryParse(tbPrice.Text,out decimal val))
                {
                    lblMessage.Text = "Please Enter Valid Price.";
                    tbPrice.Focus();
                    return;
                }
                if (decimal.Parse(tbPrice.Text.Trim())<0)
                {
                    lblMessage.Text = "Price Can't Be Negative.";
                    tbPrice.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.FlightsPrices.Where(x => x.FlightNo == cbFlightNo.SelectedValue.ToString() && x.TicketTypeId == int.Parse(cbTicketType.SelectedValue.ToString()))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbTicketType.Focus();
                        return;
                    }
                    FlightsPrices h = new FlightsPrices();
                    h.FlightNo = cbFlightNo.SelectedValue.ToString();
                    h.TicketTypeId = int.Parse(cbTicketType.SelectedValue.ToString());
                    h.Price = decimal.Parse(tbPrice.Text.Trim());
                    db.FlightsPrices.Add(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        void Clear()
        {
            cbFlightNo.SelectedIndex = 0;
            tbPrice.Clear();
            cbTicketType.SelectedIndex = 0;
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvFlightsPrices.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvFlightsPrices.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void refreshFlights()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Flights = db.Flights.ToList();
                Flights.Add(new Flights
                {
                    FlightName = "--Select--"

                });
                Flights.Reverse();
                cbFlightNo.DisplayMember = "FlightName";
                cbFlightNo.ValueMember = "FlightNo";
                cbFlightNo.DataSource = Flights;
                cbFlightNo.Refresh();
            }
        }
        void refreshTicketTypes()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {

                var TicketTypes = db.TicketType.ToList();
                TicketTypes.Add(new TicketType
                {
                   TicketTypeName = "--Select--"

                });
                TicketTypes.Reverse();
                cbTicketType.DisplayMember = "TicketTypeName";
                cbTicketType.ValueMember = "TicketTypeId";
                cbTicketType.DataSource = TicketTypes;
                cbTicketType.Refresh();
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbFlightNo.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Flight No.";
                    cbFlightNo.Focus();
                    return;
                }

                if (cbTicketType.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Ticket Type.";
                    cbTicketType.Focus();
                    return;
                }

                if (tbPrice.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Price.";
                    tbPrice.Focus();
                    return;
                }
                if (!decimal.TryParse(tbPrice.Text, out decimal val))
                {
                    lblMessage.Text = "Please Enter Valid Price.";
                    tbPrice.Focus();
                    return;
                }
                if (decimal.Parse(tbPrice.Text.Trim()) < 0)
                {
                    lblMessage.Text = "Price Can't Be Negative.";
                    tbPrice.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvFlightsPrices.CurrentRow.Cells[0].Value);
                    
                    var result = db.FlightsPrices.Where(x => x.FlightNo == cbFlightNo.SelectedValue.ToString() && x.TicketTypeId == int.Parse(cbTicketType.SelectedValue.ToString()) && x.PriceId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbTicketType.Focus();
                        return;
                    }

                    FlightsPrices h =db.FlightsPrices.Where(x => x.PriceId == int.Parse(ID)).FirstOrDefault();
                    h.FlightNo = cbFlightNo.SelectedValue.ToString();
                    h.TicketTypeId = int.Parse(cbTicketType.SelectedValue.ToString());
                    h.Price = decimal.Parse(tbPrice.Text.Trim());
                    db.FlightsPrices.Update(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFlightsPrices != null && dgvFlightsPrices.Rows.Count > 0)
                {
                    if (dgvFlightsPrices.SelectedRows.Count == 1)
                    {
                        

                        cbFlightNo.Text = Convert.ToString(dgvFlightsPrices.CurrentRow.Cells[2].Value);
                        cbTicketType.Text = Convert.ToString(dgvFlightsPrices.CurrentRow.Cells[3].Value);
                        tbPrice.Text = Convert.ToString(dgvFlightsPrices.CurrentRow.Cells[4].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFlightsPrices != null && dgvFlightsPrices.Rows.Count > 0)
                {
                    if (dgvFlightsPrices.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvFlightsPrices.CurrentRow.Cells[0].Value);
                                FlightsPrices h = db.FlightsPrices.Where(x => x.PriceId == int.Parse(ID)).FirstOrDefault();
                                db.FlightsPrices.Attach(h);
                                db.FlightsPrices.Remove(h);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Flights_prices_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshFlights();
            if(Fno.Length != 0) { 
                cbFlightNo.SelectedValue = Fno;
            }
            refreshTicketTypes();
            FillGrid("");

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;

        }
        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

    }
}
