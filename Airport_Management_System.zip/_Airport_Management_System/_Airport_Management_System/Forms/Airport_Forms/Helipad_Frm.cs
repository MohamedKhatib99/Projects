﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Helipad_Frm : Form
    {
        public Helipad_Frm()
        {
            InitializeComponent();
            cbLandingArea.SelectedIndex = 0;
        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvHelipadsList.DataSource = (from a in db.Airport
                                                   from b in db.LandingArea
                                                   from c in db.Helipad
                                                   where a.AirportCode == b.AirportCode && b.LaId == c.LaId
                                                   select new
                                                   {
                                                       ID = c.HpId,
                                                       Airport_Name = a.AirportName,
                                                       AreaName = b.AreaName,
                                                       Helipad = c.HelipadCode

                                                   }).ToList();
                        dgvHelipadsList.Columns[0].Visible = false;
                        dgvHelipadsList.Columns[1].Width = 130;
                        dgvHelipadsList.Columns[2].Width = 130;
                        dgvHelipadsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {

                        dgvHelipadsList.DataSource = (from a in db.Airport
                                                      from b in db.LandingArea
                                                      from c in db.Helipad
                                                      where a.AirportCode == b.AirportCode && b.LaId == c.LaId &&(a.AirportName.Contains(searchvalue)||b.AreaName.Contains(searchvalue) || c.HelipadCode.Contains(searchvalue))
                                                      select new
                                                      {
                                                          ID = c.HpId,
                                                          Airport_Name = a.AirportName,
                                                          AreaName = b.AreaName,
                                                          Helipad = c.HelipadCode

                                                      }).ToList();
                        dgvHelipadsList.Columns[0].Visible = false;
                        dgvHelipadsList.Columns[1].Width = 130;
                        dgvHelipadsList.Columns[2].Width = 130;
                        dgvHelipadsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            tbHelipadCode.Clear();
            cbLandingArea.SelectedIndex = 0;
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvHelipadsList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvHelipadsList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }
        void refreshLandingAreas()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                if (cbAirportName.SelectedIndex > 0)
                {
                    var LandingAreas = db.LandingArea.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString()).ToList();
                    LandingAreas.Add(new LandingArea
                    {
                        AreaName = "--Select--"

                    });
                    LandingAreas.Reverse();
                    cbLandingArea.DisplayMember = "AreaName";
                    cbLandingArea.ValueMember = "LaId";
                    cbLandingArea.DataSource = LandingAreas;
                    cbLandingArea.Refresh();
                }
            }
        }

        private void Helipad_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports();
            FillGrid("");

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;

        }

        private void cbAirportName_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshLandingAreas();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                if (cbLandingArea.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Landing Area.";
                    cbLandingArea.Focus();
                    return;
                }

                if (tbHelipadCode.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Helipad Name/Code.";
                    tbHelipadCode.Focus();
                    return;
                }
                if (tbHelipadCode.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Helipad Name/Code No Can Be Maximum 10 Characters.";
                    tbHelipadCode.Focus();
                    return;
                }                

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Helipad.Where(x => x.HelipadCode.ToLower() == tbHelipadCode.Text.ToLower() && x.LaId == int.Parse(cbLandingArea.SelectedValue.ToString()) )
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbHelipadCode.Focus();
                        return;
                    }
                    Helipad h = new Helipad();
                    h.LaId = int.Parse(cbLandingArea.SelectedValue.ToString());
                    h.HelipadCode = tbHelipadCode.Text.Trim();
                    db.Helipad.Add(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                if (cbLandingArea.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Landing Area.";
                    cbLandingArea.Focus();
                    return;
                }

                if (tbHelipadCode.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Helipad Name/Code.";
                    tbHelipadCode.Focus();
                    return;
                }
                if (tbHelipadCode.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Helipad Name/Code No Can Be Maximum 10 Characters.";
                    tbHelipadCode.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvHelipadsList.CurrentRow.Cells[0].Value);
                    var result = db.Helipad.Where(x => x.HelipadCode.ToLower() == tbHelipadCode.Text.ToLower() && x.LaId == int.Parse(cbLandingArea.SelectedValue.ToString()) && x.HpId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbHelipadCode.Focus();
                        return;
                    }
                    Helipad h = db.Helipad.Where(x => x.HpId == int.Parse(ID)).FirstOrDefault();
                    h.LaId = int.Parse(cbLandingArea.SelectedValue.ToString());
                    h.HelipadCode = tbHelipadCode.Text.Trim();
                    db.Helipad.Update(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHelipadsList != null && dgvHelipadsList.Rows.Count > 0)
                {
                    if (dgvHelipadsList.SelectedRows.Count == 1)
                    {

                        cbAirportName.Text = Convert.ToString(dgvHelipadsList.CurrentRow.Cells[1].Value);
                        cbLandingArea.Text = Convert.ToString(dgvHelipadsList.CurrentRow.Cells[2].Value);
                        tbHelipadCode.Text = Convert.ToString(dgvHelipadsList.CurrentRow.Cells[3].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHelipadsList != null && dgvHelipadsList.Rows.Count > 0)
                {
                    if (dgvHelipadsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvHelipadsList.CurrentRow.Cells[0].Value);
                                Helipad ac = new Helipad();
                                var entry = db.Entry(ac);
                                ac.HpId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Helipad.Attach(ac);
                                    db.Helipad.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
