﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Runway_Frm : Form
    {
        public Runway_Frm()
        {
            InitializeComponent();
            cbLandingArea.SelectedIndex = 0;
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvRwayList.DataSource = (   from a in db.Airport
                                                     from b in db.LandingArea
                                                     from c in db.Runway
                                                     where a.AirportCode == b.AirportCode && b.LaId == c.LaId
                                                     select new
                                                     {
                                                         ID = c.RwNo,
                                                         Airport_Name = a.AirportName,
                                                         LandingArea = b.AreaName,
                                                         RunWayName = c.RwName,
                                                         Length = c.Length,
                                                         Width = c.Width

                                                     }).ToList();
                        dgvRwayList.Columns[0].Width = 130;
                        dgvRwayList.Columns[1].Width = 130;
                        dgvRwayList.Columns[2].Width = 130;
                        dgvRwayList.Columns[3].Width = 130;
                        dgvRwayList.Columns[4].Width = 130;
                        dgvRwayList.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvRwayList.DataSource = (from a in db.Airport
                                                  from b in db.LandingArea
                                                  from c in db.Runway
                                                  where a.AirportCode == b.AirportCode && b.LaId == c.LaId &&(a.AirportName.Contains(searchvalue) || b.AreaName.Contains(searchvalue) || c.RwName.Contains(searchvalue)|| c.Width.ToString().Contains(searchvalue) || c.Length.ToString().Contains(searchvalue))
                                                  select new
                                                  {
                                                      ID = c.RwNo,
                                                      Airport_Name = a.AirportName,
                                                      LandingArea = b.AreaName,
                                                      RunWayName = c.RwName,
                                                      Length = c.Length,
                                                      Width = c.Width

                                                  }).ToList();
                        dgvRwayList.Columns[0].Width = 130;
                        dgvRwayList.Columns[1].Width = 130;
                        dgvRwayList.Columns[2].Width = 130;
                        dgvRwayList.Columns[3].Width = 130;
                        dgvRwayList.Columns[4].Width = 130;
                        dgvRwayList.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }
        void refreshLandingAreas()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                if (cbAirportName.SelectedIndex > 0)
                {
                    var LandingAreas = db.LandingArea.Where(x => x.AirportCode == cbAirportName.SelectedValue.ToString()).ToList();
                    LandingAreas.Add(new LandingArea
                    {
                        AreaName = "--Select--"

                    });
                    LandingAreas.Reverse();
                    cbLandingArea.DisplayMember = "AreaName";
                    cbLandingArea.ValueMember = "LaId";
                    cbLandingArea.DataSource = LandingAreas;
                    cbLandingArea.Refresh();
                }
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvRwayList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvRwayList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            cbLandingArea.SelectedIndex = 0;
            tbLength.Clear();
            tbRWname.Clear();
            tbWidth.Clear();
        }

        private void Runway_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports();
            FillGrid("");

        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;



        }


        private void cbAirportName_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshLandingAreas();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbLandingArea.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Landing Area.";
                    cbLandingArea.Focus();
                    return;
                }


                if (tbRWname.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Runway Name.";
                    tbRWname.Focus();
                    return;
                }

                if (tbRWname.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Runway Name Can Be Maximum 20 Characters.";
                    tbRWname.Focus();
                    return;
                }
                if (tbLength.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Length.";
                    tbLength.Focus();
                    return;
                }
                if (!float.TryParse(tbLength.Text, out float value))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbLength.Focus();
                    return;
                }
                if (tbWidth.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Width.";
                    tbWidth.Focus();
                    return;
                }
                if (!float.TryParse(tbWidth.Text, out float value1))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbWidth.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Runway.Where(x => x.LaId == int.Parse(cbLandingArea.SelectedValue.ToString()) && x.RwName.ToLower() == tbRWname.Text.Trim().ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbRWname.Focus();
                        return;
                    }
                    Runway r = new Runway();
                    r.LaId = int.Parse(cbLandingArea.SelectedValue.ToString());
                    r.RwName = tbRWname.Text.Trim();
                    r.Length = float.Parse(tbLength.Text.Trim());
                    r.Width = float.Parse(tbWidth.Text.Trim());
                    db.Runway.Add(r);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }
                if (cbLandingArea.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Landing Area.";
                    cbLandingArea.Focus();
                    return;
                }


                if (tbRWname.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Runway Name.";
                    tbRWname.Focus();
                    return;
                }

                if (tbRWname.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Runway Name Can Be Maximum 20 Characters.";
                    tbRWname.Focus();
                    return;
                }
                if (tbLength.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Length.";
                    tbLength.Focus();
                    return;
                }
                if (!float.TryParse(tbLength.Text, out float value))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbLength.Focus();
                    return;
                }
                if (tbWidth.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Width.";
                    tbWidth.Focus();
                    return;
                }
                if (!float.TryParse(tbWidth.Text, out float value1))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbWidth.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvRwayList.CurrentRow.Cells[0].Value);
                    var result = db.Runway.Where(x => x.LaId == int.Parse(cbLandingArea.SelectedValue.ToString()) && x.RwName.ToLower() == tbRWname.Text.Trim().ToLower() && x.RwNo != int.Parse(ID) )
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbRWname.Focus();
                        return;
                    }
                    Runway r = db.Runway.Where(x => x.RwNo == int.Parse(ID)).FirstOrDefault();
                    r.LaId = int.Parse(cbLandingArea.SelectedValue.ToString());
                    r.RwName = tbRWname.Text.Trim();
                    r.Length = float.Parse(tbLength.Text.Trim());
                    r.Width = float.Parse(tbWidth.Text.Trim());
                    db.Runway.Update(r);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvRwayList != null && dgvRwayList.Rows.Count > 0)
                {
                    if (dgvRwayList.SelectedRows.Count == 1)
                    {
                        EnableControls();
                        cbAirportName.Text = Convert.ToString(dgvRwayList.CurrentRow.Cells[1].Value);
                        cbLandingArea.Text = Convert.ToString(dgvRwayList.CurrentRow.Cells[2].Value);
                        tbRWname.Text = Convert.ToString(dgvRwayList.CurrentRow.Cells[3].Value);
                        tbLength.Text = Convert.ToString(dgvRwayList.CurrentRow.Cells[4].Value);
                        tbWidth.Text = Convert.ToString(dgvRwayList.CurrentRow.Cells[5].Value);

                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvRwayList != null && dgvRwayList.Rows.Count > 0)
                {
                    if (dgvRwayList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvRwayList.CurrentRow.Cells[0].Value);
                                Runway p = new Runway();
                                var entry = db.Entry(p);
                                p.RwNo = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Runway.Attach(p);
                                    db.Runway.Remove(p);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




    }
}
