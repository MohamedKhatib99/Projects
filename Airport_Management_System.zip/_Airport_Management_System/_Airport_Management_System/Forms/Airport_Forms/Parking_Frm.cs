﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Parking_Frm : Form
    {
        public Parking_Frm()
        {
            InitializeComponent();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvParkingList.DataSource = (from a in db.Airport
                                                   from b in db.Parking
                                                   where a.AirportCode == b.AirportCode
                                                   select new
                                                   {
                                                       ID = b.ParkingNo,
                                                       Airport_Name = a.AirportName,
                                                       ParkingName = b.ParkingName,
                                                       Capacity = b.Capacity,
                                                       Fee = b.Fee

                                                   }).ToList();
                        dgvParkingList.Columns[0].Visible = false;
                        dgvParkingList.Columns[1].Width = 130;
                        dgvParkingList.Columns[2].Width = 130;
                        dgvParkingList.Columns[3].Width = 130;
                        dgvParkingList.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvParkingList.DataSource = (from a in db.Airport
                                                   from b in db.Parking
                                                   where a.AirportCode == b.AirportCode && (a.AirportName.Contains(searchvalue) || b.ParkingName.Contains(searchvalue) || b.Capacity.ToString().Contains(searchvalue) || b.Fee.ToString().Contains(searchvalue))
                                                   select new
                                                   {
                                                       ID = b.ParkingNo,
                                                       Airport_Name = a.AirportName,
                                                       ParkingName = b.ParkingName,
                                                       Capacity = b.Capacity,
                                                       Fee = b.Fee
                                                   }).ToList();
                        dgvParkingList.Columns[0].Visible = false;
                        dgvParkingList.Columns[1].Width = 130;
                        dgvParkingList.Columns[2].Width = 130;
                        dgvParkingList.Columns[3].Width = 130;
                        dgvParkingList.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvParkingList.Enabled = false;
            tbSearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvParkingList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void Clear()
        {
            cbAirportName.SelectedIndex = 0;
            tbCapacity.Clear();
            tbParkingName.Clear();
            tbFee.Clear();
        }

        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }

        private void Parking_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;





        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }


        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                if (tbParkingName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Parking Name.";
                    tbParkingName.Focus();
                    return;
                }
                if (tbParkingName.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Parking Name Can Be Maximum 20 Characters.";
                    tbParkingName.Focus();
                    return;
                }
                if (tbCapacity.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Parking Capacity.";
                    tbCapacity.Focus();
                    return;
                }
                if (!Int32.TryParse(tbCapacity.Text, out int value))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbCapacity.Focus();
                    return;
                }
                if (tbFee.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Parking Fee.";
                    tbFee.Focus();
                    return;
                }
                if (!decimal.TryParse(tbFee.Text, out decimal value1))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbFee.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Parking.Where(x => x.AirportCode.ToLower() == cbAirportName.SelectedValue.ToString().ToLower() && x.ParkingName.ToLower() == tbParkingName.Text.Trim().ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbParkingName.Focus();
                        return;
                    }
                    Parking p = new Parking();
                    p.AirportCode = cbAirportName.SelectedValue.ToString();
                    p.ParkingName = tbParkingName.Text.Trim();
                    p.Capacity = int.Parse(tbCapacity.Text.Trim());
                    p.Fee = decimal.Parse(tbFee.Text.Trim());
                    db.Parking.Add(p);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                if (tbParkingName.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Parking Name.";
                    tbParkingName.Focus();
                    return;
                }
                if (tbParkingName.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Parking Name Can Be Maximum 20 Characters.";
                    tbParkingName.Focus();
                    return;
                }
                if (tbCapacity.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Parking Capacity.";
                    tbCapacity.Focus();
                    return;
                }
                if (!Int32.TryParse(tbCapacity.Text, out int value))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbCapacity.Focus();
                    return;
                }
                if (tbFee.Text.Trim() == "")
                {
                    lblMessage1.Text = "Please Enter Parking Fee.";
                    tbFee.Focus();
                    return;
                }
                if (!decimal.TryParse(tbFee.Text, out decimal value1))
                {
                    lblMessage1.Text = "Please Enter Valid Number.";
                    tbFee.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvParkingList.CurrentRow.Cells[0].Value);
                    var result = db.Parking.Where(x => x.AirportCode.ToLower() == cbAirportName.SelectedValue.ToString().ToLower() && x.ParkingName.ToLower() == tbParkingName.Text.Trim().ToLower() && x.ParkingNo != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbParkingName.Focus();
                        return;
                    }
                    Parking p = db.Parking.Where(x => x.ParkingNo == int.Parse(ID)).FirstOrDefault();
                    p.AirportCode = cbAirportName.SelectedValue.ToString();
                    p.ParkingName = tbParkingName.Text.Trim();
                    p.Capacity = int.Parse(tbCapacity.Text.Trim());
                    p.Fee = decimal.Parse(tbFee.Text.Trim());
                    db.Parking.Update(p);
                    db.SaveChanges();
                }
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = ""; lblMessage1.Text = "";

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvParkingList != null && dgvParkingList.Rows.Count > 0)
                {
                    if (dgvParkingList.SelectedRows.Count == 1)
                    {
                        cbAirportName.Text = Convert.ToString(dgvParkingList.CurrentRow.Cells[1].Value);
                        tbParkingName.Text = Convert.ToString(dgvParkingList.CurrentRow.Cells[2].Value);
                        tbCapacity.Text = Convert.ToString(dgvParkingList.CurrentRow.Cells[3].Value);
                        tbFee.Text = Convert.ToString(dgvParkingList.CurrentRow.Cells[4].Value);


                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvParkingList != null && dgvParkingList.Rows.Count > 0)
                {
                    if (dgvParkingList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvParkingList.CurrentRow.Cells[0].Value);
                                Parking p = new Parking();
                                var entry = db.Entry(p);
                                p.ParkingNo = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Parking.Attach(p);
                                    db.Parking.Remove(p);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

 
    }
}
