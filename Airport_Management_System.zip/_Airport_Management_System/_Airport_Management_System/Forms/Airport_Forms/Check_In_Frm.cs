﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Check_In_Frm : Form
    {
        public Check_In_Frm()
        {
            InitializeComponent();
            cbticketCode.SelectedIndex = 0;
            cbSeats.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void refereshTickets()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Tickets = (from t in db.Ticket
                               from p in db.Passenger
                               from f in db.Flights
                               where t.PassengerId == p.PassengerId && f.FlightNo == t.FlightNo && ( (p.PassengerTc == tbTCnum.Text.Trim()||p.Name.ToLower().Trim() == tbFullName.Text.Trim().ToLower()) && f.FlightDate.Date == dtpFDate.Value.Date )
                               select new {
                                   t.TicketNo,
                               }).ToList();

                cbticketCode.DisplayMember = "TicketNo";
                cbticketCode.ValueMember = "TicketNo";
                cbticketCode.DataSource = Tickets;
                cbticketCode.Text = "--Select--";
            }
        }

        private void refereshSeats()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                if(cbticketCode.Text != "--Select--") 
                {
                    var checkin = db.CheckIn.ToList();

                    var Seats = (from s in db.Seats
                                 from f in db.TicketType
                                 from fl in db.Flights
                                 from t in db.Ticket
                                 from a in db.Airplane
                                 where fl.FlightNo == t.FlightNo && fl.AirplaneCode == a.AirplaneCode && a.AirplaneCode == s.AirplaneCode && s.TicketTypeId == f.TicketTypeId && s.TicketTypeId == t.TicketTypeId
                                 && t.TicketNo == cbticketCode.SelectedValue.ToString() && s.ReservationStatus == 0
                                 select new
                                 {
                                     s.SeatId,
                                     s.SeatNo
                                 }).ToList();

                   

                    cbSeats.DisplayMember = "SeatNo";
                    cbSeats.ValueMember = "SeatId";
                    cbSeats.DataSource = Seats;
                    cbSeats.Text = "--Select--";

                }


            }
        }

        private void tbTCnum_TextChanged(object sender, EventArgs e)
        {
            refereshTickets();

        }

        private void tbFullName_TextChanged(object sender, EventArgs e)
        {
            refereshTickets();
        }

        private void Check_In_Frm_Load(object sender, EventArgs e)
        {
            FillGrid("");
            refereshTickets();
            refereshSeats();
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
            label7.ForeColor = ThemeColor.SecondaryColor;
            label8.ForeColor = ThemeColor.SecondaryColor;
            label11.ForeColor = ThemeColor.SecondaryColor;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbTCnum.Text.Length > 0 && tbTCnum.Text.Length < 11)
                {
                    lblMessage.Text = "Please Enter Valid TC Number.";
                    tbTCnum.Focus();
                    return;
                }

                if (tbFullName.Text.Trim().Length > 40)
                {
                    lblMessage.Text = "Please Enter Valid Name.";
                    tbFullName.Focus();
                    return;

                }
                if (cbticketCode.Text == "--Select--")
                {
                    lblMessage1.Text = "Please Select Ticket Code.";
                    cbticketCode.Focus();
                    return;
                }

                if (cbSeats.Text == "--Select--")
                {
                    lblMessage1.Text = "Please Select Seat.";
                    cbSeats.Focus();
                    return;
                } 

                
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    
                    var result = db.CheckIn.Where(x => x.TicketNo == cbticketCode.SelectedValue.ToString())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Checked In!";
                        cbSeats.Focus();
                        return;
                    }
                    
                    CheckIn h = new CheckIn();

                    Seats s = db.Seats.Where(x => x.SeatId == int.Parse(cbSeats.SelectedValue.ToString())).FirstOrDefault();

                    h.TicketNo = cbticketCode.SelectedValue.ToString();
                    h.SeatId = int.Parse(cbSeats.SelectedValue.ToString());
                    s.ReservationStatus = 1;
                    db.Seats.Update(s);
                    db.CheckIn.Add(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void Clear()
        {
            tbTCnum.Clear();
            tbFullName.Clear();
            dtpFDate.Value = DateTime.Today;
            cbticketCode.Text = "--Select--";
            cbSeats.Text = "--Select--";
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvcheckInsList.Enabled = false;
            tbSearch.Enabled = false;
        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvcheckInsList.Enabled = true;
            tbSearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvcheckInsList.DataSource = (from a in db.CheckIn
                                                      from b in db.Ticket
                                                      from c in db.Seats
                                                      from p in db.Passenger
                                                      where a.SeatId == c.SeatId && a.TicketNo == b.TicketNo && b.PassengerId == p.PassengerId
                                                      select new
                                                      {
                                                          ID = a.ChechInId,
                                                          Ticket_No = b.TicketNo,
                                                          TC = p.PassengerTc,
                                                          Passenger_Name = p.Name,
                                                          Seat_Cabin_No = c.SeatNo, 

                                                          

                                                      }).ToList();
                        dgvcheckInsList.Columns[0].Width = 100;
                        dgvcheckInsList.Columns[1].Width = 130;
                        dgvcheckInsList.Columns[2].Width = 130;
                        dgvcheckInsList.Columns[3].Width = 130;
                        dgvcheckInsList.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {

                        dgvcheckInsList.DataSource = (from a in db.CheckIn
                                                      from b in db.Ticket
                                                      from c in db.Seats
                                                      from p in db.Passenger
                                                      where a.SeatId == c.SeatId && a.TicketNo == b.TicketNo && b.PassengerId == p.PassengerId && (b.TicketNo.Contains(searchvalue)||p.PassengerTc.Contains(searchvalue)|| p.Name.Contains(searchvalue))
                                                      select new
                                                      {

                                                          ID = a.ChechInId,
                                                          Ticket_No = b.TicketNo,
                                                          TC = p.PassengerTc,
                                                          Passenger_Name = p.Name,
                                                          Seat_Cabin_No = c.SeatNo,

                                                      }).ToList();
                        dgvcheckInsList.Columns[0].Width = 100;
                        dgvcheckInsList.Columns[1].Width = 130;
                        dgvcheckInsList.Columns[2].Width = 130;
                        dgvcheckInsList.Columns[3].Width = 130;
                        dgvcheckInsList.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void cbticketCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            refereshSeats();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbTCnum.Text.Length > 0 && tbTCnum.Text.Length < 11)
                {
                    lblMessage.Text = "Please Enter Valid TC Number.";
                    tbTCnum.Focus();
                    return;
                }

                if (tbFullName.Text.Trim().Length > 40)
                {
                    lblMessage.Text = "Please Enter Valid Name.";
                    tbFullName.Focus();
                    return;

                }
                if (cbticketCode.Text == "--Select--")
                {
                    lblMessage1.Text = "Please Select Ticket Code.";
                    cbticketCode.Focus();
                    return;
                }

                if (cbSeats.Text == "--Select--")
                {
                    lblMessage1.Text = "Please Select Seat.";
                    cbSeats.Focus();
                    return;
                }


                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[0].Value);
                    var result = db.CheckIn.Where(x => x.TicketNo == cbticketCode.SelectedValue.ToString() && x.ChechInId != int.Parse(ID))
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        cbSeats.Focus();
                        return;
                    }
                    
                    CheckIn h = db.CheckIn.Where(x=> x.ChechInId == int.Parse(ID)).FirstOrDefault();

                    Seats s = db.Seats.Where(x => x.SeatId == int.Parse(cbSeats.SelectedValue.ToString())).FirstOrDefault();

                    h.TicketNo = cbticketCode.SelectedValue.ToString();
                    h.SeatId = int.Parse(cbSeats.SelectedValue.ToString());
                    s.ReservationStatus = 1;
                    db.Seats.Update(s);
                    db.CheckIn.Update(h);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvcheckInsList != null && dgvcheckInsList.Rows.Count > 0)
                {
                    if (dgvcheckInsList.SelectedRows.Count == 1)
                    {
                        using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                        {
                            string ID = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[0].Value);

                            tbTCnum.Text = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[2].Value);
                            tbFullName.Text = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[3].Value);


                            

                            var res = (from a in db.Flights
                                       from b in db.Ticket
                                       where a.FlightNo == b.FlightNo && b.TicketNo == Convert.ToString(dgvcheckInsList.CurrentRow.Cells[1].Value)
                                       select new
                                       {
                                           a.FlightDate

                                       }).FirstOrDefault();

                            dtpFDate.Value = res.FlightDate.Date;
                            
                            CheckIn ac = db.CheckIn.Where(x => x.ChechInId == int.Parse(ID)).FirstOrDefault();
                            Seats s = db.Seats.Where(x => x.SeatId == ac.SeatId).FirstOrDefault();
                            s.ReservationStatus = 0;
                            db.Seats.Update(s);
                            db.SaveChanges();
                            
                        }

                        refereshTickets();
                        refereshSeats();
                        cbticketCode.Text = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[1].Value);
                        cbSeats.Text = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[4].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvcheckInsList != null && dgvcheckInsList.Rows.Count > 0)
                {
                    if (dgvcheckInsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string ID = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[0].Value);
                                CheckIn ac = db.CheckIn.Where(x => x.ChechInId == int.Parse(ID)).FirstOrDefault();
                                Seats s = db.Seats.Where(x => x.SeatId == ac.SeatId).FirstOrDefault();
                                s.ReservationStatus = 0;
                                db.Seats.Update(s);
                                db.CheckIn.Remove(ac);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string ID = Convert.ToString(dgvcheckInsList.CurrentRow.Cells[0].Value);
                    CheckIn ac = db.CheckIn.Where(x => x.ChechInId == int.Parse(ID)).FirstOrDefault();
                    Seats s = db.Seats.Where(x => x.SeatId == ac.SeatId).FirstOrDefault();
                    s.ReservationStatus = 1;
                    db.Seats.Update(s);
                    db.SaveChanges();
                }
                DisableControls();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage1.Text = "";
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }
    }
}
