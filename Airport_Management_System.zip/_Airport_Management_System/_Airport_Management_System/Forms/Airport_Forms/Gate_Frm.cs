﻿using _Airport_Management_System.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System.Forms.Airport_Forms
{
    public partial class Gate_Frm : Form
    {
        public Gate_Frm()
        {
            InitializeComponent();
        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvGatesList.DataSource = (from a in db.Airport
                                                      from b in db.Gate
                                                      where a.AirportCode == b.AirportCode
                                                      select new
                                                      {
                                                          Airport_Name = a.AirportName,
                                                          Gate_No = b.GateNo,
                                                          Purpose = b.Purpose

                                                      }).ToList();
                        dgvGatesList.Columns[0].Width = 130;
                        dgvGatesList.Columns[1].Width = 130;
                        dgvGatesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvGatesList.DataSource = (from a in db.Airport
                                                   from b in db.Gate
                                                   where a.AirportCode == b.AirportCode && (a.AirportName.Contains(searchvalue) || b.GateNo.Contains(searchvalue) || b.Purpose.Contains(searchvalue))
                                                      select new
                                                      {
                                                          Airport_Name = a.AirportName,
                                                          Gate_No = b.GateNo,
                                                          Purpose = b.Purpose
                                                      }).ToList();
                        dgvGatesList.Columns[0].Width = 130;
                        dgvGatesList.Columns[1].Width = 130;
                        dgvGatesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void Clear()
        {
            tbGateNo.Clear();
            tbPurpose.Clear();
            cbAirportName.SelectedIndex = 0;
            tbSearch.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvGatesList.Enabled = false;
            tbSearch.Enabled = false;
            tbGateNo.ReadOnly = true;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvGatesList.Enabled = true;
            tbSearch.Enabled = true;
            tbGateNo.ReadOnly = false;
            FillGrid("");
            Clear();

        }
        void refreshAirports()
        {
            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
            {
                var Airports = db.Airport.ToList();
                Airports.Add(new Airport
                {
                    AirportName = "--Select--"

                });
                Airports.Reverse();
                cbAirportName.DisplayMember = "AirportName";
                cbAirportName.ValueMember = "AirportCode";
                cbAirportName.DataSource = Airports;
                cbAirportName.Refresh();
            }
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Gate_Frm_Load(object sender, EventArgs e)
        {
            LoadTheme();
            refreshAirports();
            FillGrid("");
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.SecondaryColor;
            label4.ForeColor = ThemeColor.SecondaryColor;
            label5.ForeColor = ThemeColor.SecondaryColor;
            label6.ForeColor = ThemeColor.SecondaryColor;
        }


        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbGateNo.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Gate No.";
                    tbGateNo.Focus();
                    return;
                }
                if (tbGateNo.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Gate No Can Be Maximum 10 Characters.";
                    tbGateNo.Focus();
                    return;
                }

                if (tbPurpose.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Gate Purpose.";
                    tbPurpose.Focus();
                    return;
                }
                if (tbPurpose.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Gate Purpose Can Be Maximum 20 Characters.";
                    tbPurpose.Focus();
                    return;
                }


                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    var result = db.Gate.Where(x => x.GateNo.ToLower() == tbGateNo.Text.ToLower())
                                                              .FirstOrDefault();

                    if (result != null)
                    {
                        lblMessage.Text = "Already Registered !";
                        tbGateNo.Focus();
                        return;
                    }
                    Gate g = new Gate();
                    g.GateNo = tbGateNo.Text.Trim();
                    g.Purpose= tbPurpose.Text.Trim();
                    g.AirportCode = cbAirportName.SelectedValue.ToString();
                    db.Gate.Add(g);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGatesList != null && dgvGatesList.Rows.Count > 0)
                {
                    if (dgvGatesList.SelectedRows.Count == 1)
                    {
                        tbGateNo.Text = Convert.ToString(dgvGatesList.CurrentRow.Cells[1].Value);
                        tbPurpose.Text = Convert.ToString(dgvGatesList.CurrentRow.Cells[2].Value);
                        cbAirportName.Text = Convert.ToString(dgvGatesList.CurrentRow.Cells[0].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGatesList != null && dgvGatesList.Rows.Count > 0)
                {
                    if (dgvGatesList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                            {

                                string GateNo = Convert.ToString(dgvGatesList.CurrentRow.Cells[1].Value);
                                Gate ac = new Gate();
                                var entry = db.Entry(ac);
                                ac.GateNo = GateNo;
                                if (entry.State == EntityState.Detached)
                                {
                                    db.Gate.Attach(ac);
                                    db.Gate.Remove(ac);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbSearch.Text);
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbGateNo.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Enter Gate No.";
                    tbGateNo.Focus();
                    return;
                }
                if (tbGateNo.Text.Trim().Length > 30)
                {
                    lblMessage.Text = "Gate No Can Be Maximum 10 Characters.";
                    tbGateNo.Focus();
                    return;
                }

                if (tbPurpose.Text.Trim().Length == 0)
                {
                    lblMessage.Text = "Please Gate Purpose.";
                    tbPurpose.Focus();
                    return;
                }
                if (tbPurpose.Text.Trim().Length > 20)
                {
                    lblMessage.Text = "Gate Purpose Can Be Maximum 20 Characters.";
                    tbPurpose.Focus();
                    return;
                }


                if (cbAirportName.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please Select Airport.";
                    cbAirportName.Focus();
                    return;
                }

                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    string GateNo = Convert.ToString(dgvGatesList.CurrentRow.Cells[1].Value);
                   
                    Gate g = db.Gate.Where(x => x.GateNo == GateNo ).FirstOrDefault();
                    g.GateNo = tbGateNo.Text.Trim();
                    g.Purpose = tbPurpose.Text.Trim();
                    g.AirportCode = cbAirportName.SelectedValue.ToString();
                    db.Gate.Update(g);
                    db.SaveChanges();
                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


    }
}
