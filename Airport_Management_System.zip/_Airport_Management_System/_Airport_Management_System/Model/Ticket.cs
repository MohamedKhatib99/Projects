﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Ticket
    {
        public Ticket()
        {
            CheckIn = new HashSet<CheckIn>();
        }

        public string TicketNo { get; set; }
        public string FlightNo { get; set; }
        public int SupplierId { get; set; }
        public int PassengerId { get; set; }
        public int TicketTypeId { get; set; }

        public virtual Flights FlightNoNavigation { get; set; }
        public virtual Passenger Passenger { get; set; }
        public virtual Supplier Supplier { get; set; }
        public virtual TicketType TicketType { get; set; }
        public virtual ICollection<CheckIn> CheckIn { get; set; }
    }
}
