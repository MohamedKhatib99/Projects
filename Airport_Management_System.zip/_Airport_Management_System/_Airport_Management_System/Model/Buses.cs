﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Buses
    {
        public Buses()
        {
            InternalTransport = new HashSet<InternalTransport>();
        }

        public int BusId { get; set; }
        public string BusName { get; set; }

        public virtual GhTransportAirplane GhTransportAirplane { get; set; }
        public virtual ICollection<InternalTransport> InternalTransport { get; set; }
    }
}
