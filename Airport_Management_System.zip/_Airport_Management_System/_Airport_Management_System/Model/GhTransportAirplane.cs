﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class GhTransportAirplane
    {
        public int GtaId { get; set; }
        public int GhId { get; set; }
        public string AirplaneCode { get; set; }
        public int TransportNo { get; set; }

        public virtual Airplane AirplaneCodeNavigation { get; set; }
        public virtual Gatehouse Gh { get; set; }
        public virtual Buses Gta { get; set; }
    }
}
