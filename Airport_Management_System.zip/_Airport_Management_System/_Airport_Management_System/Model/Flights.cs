﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Flights
    {
        public Flights()
        {
            FlightsPrices = new HashSet<FlightsPrices>();
            InternalTransport = new HashSet<InternalTransport>();
            Ticket = new HashSet<Ticket>();
        }

        public string FlightNo { get; set; }
        public string FlightName { get; set; }
        public string AirplaneCode { get; set; }
        public string GateNo { get; set; }
        public int CtId { get; set; }
        public string StartPoint { get; set; }
        public string EndPoint { get; set; }
        public DateTime FlightDate { get; set; }
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
        public int AvailableTickets { get; set; }
        public int? SoldTickets { get; set; }

        public virtual Airplane AirplaneCodeNavigation { get; set; }
        public virtual ControlTower Ct { get; set; }
        public virtual Gate GateNoNavigation { get; set; }
        public virtual ICollection<FlightsPrices> FlightsPrices { get; set; }
        public virtual ICollection<InternalTransport> InternalTransport { get; set; }
        public virtual ICollection<Ticket> Ticket { get; set; }
    }
}
