﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Runway
    {
        public int RwNo { get; set; }
        public int LaId { get; set; }
        public string RwName { get; set; }
        public double Length { get; set; }
        public double Width { get; set; }

        public virtual LandingArea La { get; set; }
    }
}
