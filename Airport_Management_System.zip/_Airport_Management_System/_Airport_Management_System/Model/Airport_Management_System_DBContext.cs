﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace _Airport_Management_System.Model
{
    public partial class Airport_Management_System_DBContext : DbContext
    {
        public Airport_Management_System_DBContext()
        {
        }

        public Airport_Management_System_DBContext(DbContextOptions<Airport_Management_System_DBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AirlineCompany> AirlineCompany { get; set; }
        public virtual DbSet<Airplane> Airplane { get; set; }
        public virtual DbSet<Airport> Airport { get; set; }
        public virtual DbSet<Buses> Buses { get; set; }
        public virtual DbSet<CheckIn> CheckIn { get; set; }
        public virtual DbSet<City> City { get; set; }
        public virtual DbSet<ControlTower> ControlTower { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Flights> Flights { get; set; }
        public virtual DbSet<FlightsPrices> FlightsPrices { get; set; }
        public virtual DbSet<Gate> Gate { get; set; }
        public virtual DbSet<Gatehouse> Gatehouse { get; set; }
        public virtual DbSet<GhTransportAirplane> GhTransportAirplane { get; set; }
        public virtual DbSet<Helipad> Helipad { get; set; }
        public virtual DbSet<InternalTransport> InternalTransport { get; set; }
        public virtual DbSet<LandingArea> LandingArea { get; set; }
        public virtual DbSet<Luggage> Luggage { get; set; }
        public virtual DbSet<Parking> Parking { get; set; }
        public virtual DbSet<Passenger> Passenger { get; set; }
        public virtual DbSet<Runway> Runway { get; set; }
        public virtual DbSet<Seats> Seats { get; set; }
        public virtual DbSet<Supplier> Supplier { get; set; }
        public virtual DbSet<Ticket> Ticket { get; set; }
        public virtual DbSet<TicketType> TicketType { get; set; }
        public virtual DbSet<UserType> UserType { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<WorkType> WorkType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-UQ3F2RM;Initial Catalog=Airport_Management_System_DB;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AirlineCompany>(entity =>
            {
                entity.HasKey(e => e.AcId)
                    .HasName("PK__Airline___BF5118282D913F8E");

                entity.ToTable("Airline_Company");

                entity.Property(e => e.AcId).HasColumnName("AC_ID");

                entity.Property(e => e.AcName)
                    .IsRequired()
                    .HasColumnName("AC_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Airplane>(entity =>
            {
                entity.HasKey(e => e.AirplaneCode)
                    .HasName("PK__Airplane__021CB379E17DE3F8");

                entity.Property(e => e.AirplaneCode)
                    .HasColumnName("Airplane_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.AcId).HasColumnName("AC_ID");

                entity.HasOne(d => d.Ac)
                    .WithMany(p => p.Airplane)
                    .HasForeignKey(d => d.AcId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Airplane_Airline_Company");
            });

            modelBuilder.Entity<Airport>(entity =>
            {
                entity.HasKey(e => e.AirportCode)
                    .HasName("PK__Airport__DEA35EC3046C0E65");

                entity.Property(e => e.AirportCode)
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.AirportName)
                    .IsRequired()
                    .HasColumnName("Airport_Name")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CityId).HasColumnName("City_ID");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Airport)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Airport_City");
            });

            modelBuilder.Entity<Buses>(entity =>
            {
                entity.HasKey(e => e.BusId);

                entity.Property(e => e.BusId).HasColumnName("Bus_ID");

                entity.Property(e => e.BusName)
                    .IsRequired()
                    .HasColumnName("Bus_Name")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CheckIn>(entity =>
            {
                entity.HasKey(e => e.ChechInId)
                    .HasName("PK__tmp_ms_x__29F33B0B45BE4C03");

                entity.ToTable("Check_in");

                entity.Property(e => e.ChechInId).HasColumnName("Chech_in_ID");

                entity.Property(e => e.SeatId).HasColumnName("Seat_ID");


                entity.Property(e => e.TicketNo)
                    .IsRequired()
                    .HasColumnName("Ticket_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Seat)
                    .WithMany(p => p.CheckIn)
                    .HasForeignKey(d => d.SeatId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Check_in_Seats");

                entity.HasOne(d => d.TicketNoNavigation)
                    .WithMany(p => p.CheckIn)
                    .HasForeignKey(d => d.TicketNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Check_in_Ticket");
            });

            modelBuilder.Entity<City>(entity =>
            {
                entity.Property(e => e.CityId).HasColumnName("City_ID");

                entity.Property(e => e.CityName)
                    .IsRequired()
                    .HasColumnName("City_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ControlTower>(entity =>
            {
                entity.HasKey(e => e.CtId)
                    .HasName("PK__tmp_ms_x__DC4F366B126C9177");

                entity.ToTable("Control_Tower");

                entity.Property(e => e.CtId).HasColumnName("CT_ID");

                entity.Property(e => e.AirportCode)
                    .IsRequired()
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ControllingCapacity)
                    .IsRequired()
                    .HasColumnName("Controlling_Capacity")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CtName)
                    .IsRequired()
                    .HasColumnName("CT_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NoOfTower).HasColumnName("No_of_tower");

                entity.HasOne(d => d.AirportCodeNavigation)
                    .WithMany(p => p.ControlTower)
                    .HasForeignKey(d => d.AirportCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Control_Tower_Airport");
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasKey(e => e.DeptId)
                    .HasName("PK__Departme__72ABC12CEA029A1D");

                entity.Property(e => e.DeptId).HasColumnName("Dept_ID");

                entity.Property(e => e.DeptName)
                    .IsRequired()
                    .HasColumnName("Dept_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Flights>(entity =>
            {
                entity.HasKey(e => e.FlightNo)
                    .HasName("PK__tmp_ms_x__CAC6665021073072");

                entity.Property(e => e.FlightNo)
                    .HasColumnName("Flight_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.AirplaneCode)
                    .IsRequired()
                    .HasColumnName("Airplane_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ArrivalTime)
                    .IsRequired()
                    .HasColumnName("Arrival_Time")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.AvailableTickets).HasColumnName("Available_tickets");

                entity.Property(e => e.CtId).HasColumnName("CT_ID");

                entity.Property(e => e.DepartureTime)
                    .IsRequired()
                    .HasColumnName("Departure_Time")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.EndPoint)
                    .IsRequired()
                    .HasColumnName("end_point")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FlightDate)
                    .HasColumnName("Flight_date")
                    .HasColumnType("date");

                entity.Property(e => e.FlightName)
                    .IsRequired()
                    .HasColumnName("Flight_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GateNo)
                    .IsRequired()
                    .HasColumnName("Gate_No")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SoldTickets).HasColumnName("sold_tickets");

                entity.Property(e => e.StartPoint)
                    .IsRequired()
                    .HasColumnName("start_point")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.HasOne(d => d.AirplaneCodeNavigation)
                    .WithMany(p => p.Flights)
                    .HasForeignKey(d => d.AirplaneCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Flights_Airplane");

                entity.HasOne(d => d.Ct)
                    .WithMany(p => p.Flights)
                    .HasForeignKey(d => d.CtId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Flights_Control_Tower");

                entity.HasOne(d => d.GateNoNavigation)
                    .WithMany(p => p.Flights)
                    .HasForeignKey(d => d.GateNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Flights_Gate");
            });

            modelBuilder.Entity<FlightsPrices>(entity =>
            {
                entity.HasKey(e => e.PriceId)
                    .HasName("PK__tmp_ms_x__A4821BF260B827B6");

                entity.ToTable("Flights_Prices");

                entity.Property(e => e.PriceId).HasColumnName("Price_ID");

                entity.Property(e => e.FlightNo)
                    .IsRequired()
                    .HasColumnName("Flight_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Price).HasColumnType("money");

                entity.Property(e => e.TicketTypeId).HasColumnName("Ticket_Type_ID");

                entity.HasOne(d => d.FlightNoNavigation)
                    .WithMany(p => p.FlightsPrices)
                    .HasForeignKey(d => d.FlightNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Flights_Prices_Flights");

                entity.HasOne(d => d.TicketType)
                    .WithMany(p => p.FlightsPrices)
                    .HasForeignKey(d => d.TicketTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Flights_Prices_Ticket_Type");
            });

            modelBuilder.Entity<Gate>(entity =>
            {
                entity.HasKey(e => e.GateNo)
                    .HasName("PK__Gate__85C3CA4E4D65F914");

                entity.Property(e => e.GateNo)
                    .HasColumnName("Gate_No")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.AirportCode)
                    .IsRequired()
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Purpose)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.AirportCodeNavigation)
                    .WithMany(p => p.Gate)
                    .HasForeignKey(d => d.AirportCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Gate_Airport");
            });

            modelBuilder.Entity<Gatehouse>(entity =>
            {
                entity.HasKey(e => e.GhId)
                    .HasName("PK__tmp_ms_x__270B7A709CC22046");

                entity.Property(e => e.GhId).HasColumnName("GH_ID");

                entity.Property(e => e.AirportCode)
                    .IsRequired()
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Counters)
                    .IsRequired()
                    .HasColumnName("counters")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.GhName)
                    .IsRequired()
                    .HasColumnName("GH_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.JetBridge)
                    .IsRequired()
                    .HasColumnName("Jet_Bridge")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Seating)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.AirportCodeNavigation)
                    .WithMany(p => p.Gatehouse)
                    .HasForeignKey(d => d.AirportCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Gatehouse_Airport");
            });

            modelBuilder.Entity<GhTransportAirplane>(entity =>
            {
                entity.HasKey(e => e.GtaId)
                    .HasName("PK__tmp_ms_x__8729FC45A3078A68");

                entity.ToTable("GH_Transport_airplane");

                entity.Property(e => e.GtaId)
                    .HasColumnName("GTA_ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AirplaneCode)
                    .IsRequired()
                    .HasColumnName("Airplane_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.TransportNo).HasColumnName("Transport_no");

                entity.Property(e => e.GhId).HasColumnName("GH_ID");

                entity.HasOne(d => d.AirplaneCodeNavigation)
                    .WithMany(p => p.GhTransportAirplane)
                    .HasForeignKey(d => d.AirplaneCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GH_Transport_airplane_Airplane");

                entity.HasOne(d => d.Gh)
                    .WithMany(p => p.GhTransportAirplane)
                    .HasForeignKey(d => d.GhId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GH_Transport_airplane_Gatehouse");

                entity.HasOne(d => d.Gta)
                    .WithOne(p => p.GhTransportAirplane)
                    .HasForeignKey<GhTransportAirplane>(d => d.GtaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GH_Transport_airplane_Internal_Transport");
            });

            modelBuilder.Entity<Helipad>(entity =>
            {
                entity.HasKey(e => e.HpId)
                    .HasName("PK__tmp_ms_x__53D22398086034BA");

                entity.Property(e => e.HpId).HasColumnName("HP_ID");

                entity.Property(e => e.HelipadCode)
                    .IsRequired()
                    .HasColumnName("Helipad_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LaId).HasColumnName("LA_ID");

                entity.HasOne(d => d.La)
                    .WithMany(p => p.Helipad)
                    .HasForeignKey(d => d.LaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Helipad_Landing_Area");
            });

            modelBuilder.Entity<InternalTransport>(entity =>
            {
                entity.HasKey(e => e.TransportNo)
                    .HasName("PK__Internal__9EC027BA9ACE350D");

                entity.ToTable("Internal_Transport");

                entity.Property(e => e.TransportNo).HasColumnName("Transport_no");

                entity.Property(e => e.BusId).HasColumnName("Bus_ID");

                entity.Property(e => e.FlightNo)
                    .IsRequired()
                    .HasColumnName("Flight_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Bus)
                    .WithMany(p => p.InternalTransport)
                    .HasForeignKey(d => d.BusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Internal_Transport_Buses");

                entity.HasOne(d => d.FlightNoNavigation)
                    .WithMany(p => p.InternalTransport)
                    .HasForeignKey(d => d.FlightNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Internal_Transport_Flights");
            });

            modelBuilder.Entity<LandingArea>(entity =>
            {
                entity.HasKey(e => e.LaId)
                    .HasName("PK__tmp_ms_x__A57D4D585F65E80B");

                entity.ToTable("Landing_Area");

                entity.Property(e => e.LaId).HasColumnName("LA_ID");

                entity.Property(e => e.AirportCode)
                    .IsRequired()
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.AreaCovered).HasColumnName("Area_Covered");

                entity.Property(e => e.AreaName)
                    .IsRequired()
                    .HasColumnName("Area_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.AirportCodeNavigation)
                    .WithMany(p => p.LandingArea)
                    .HasForeignKey(d => d.AirportCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Landing_Area_Airport");
            });

            modelBuilder.Entity<Luggage>(entity =>
            {
                entity.Property(e => e.LuggageId).HasColumnName("Luggage_ID");

                entity.Property(e => e.PassengerId).HasColumnName("Passenger_ID");

                entity.HasOne(d => d.Passenger)
                    .WithMany(p => p.Luggage)
                    .HasForeignKey(d => d.PassengerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Luggage_Passenger");
            });

            modelBuilder.Entity<Parking>(entity =>
            {
                entity.HasKey(e => e.ParkingNo)
                    .HasName("PK__tmp_ms_x__17B8626FACBFF9B9");

                entity.Property(e => e.ParkingNo).HasColumnName("Parking_No");

                entity.Property(e => e.AirportCode)
                    .IsRequired()
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Fee).HasColumnType("money");

                entity.Property(e => e.ParkingName)
                    .IsRequired()
                    .HasColumnName("Parking_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.AirportCodeNavigation)
                    .WithMany(p => p.Parking)
                    .HasForeignKey(d => d.AirportCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Parking_Airport");
            });

            modelBuilder.Entity<Passenger>(entity =>
            {
                entity.Property(e => e.PassengerId).HasColumnName("Passenger_ID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BirthDate)
                    .HasColumnName("Birth_Date")
                    .HasColumnType("date");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerTc)
                    .IsRequired()
                    .HasColumnName("Passenger_TC")
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PhoneNum)
                    .IsRequired()
                    .HasColumnName("Phone_Num")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Runway>(entity =>
            {
                entity.HasKey(e => e.RwNo)
                    .HasName("PK__tmp_ms_x__B4990E17AC302840");

                entity.Property(e => e.RwNo).HasColumnName("RW_no");

                entity.Property(e => e.LaId).HasColumnName("LA_ID");

                entity.Property(e => e.RwName)
                    .IsRequired()
                    .HasColumnName("RW_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.La)
                    .WithMany(p => p.Runway)
                    .HasForeignKey(d => d.LaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Runway_Landing_Area");
            });

            modelBuilder.Entity<Seats>(entity =>
            {
                entity.HasKey(e => e.SeatId)
                    .HasName("PK__Seats__8B2CE7B6AEE7E575");

                entity.Property(e => e.SeatId).HasColumnName("Seat_ID");

                entity.Property(e => e.AirplaneCode)
                    .IsRequired()
                    .HasColumnName("Airplane_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SeatNo)
                    .IsRequired()
                    .HasColumnName("Seat_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReservationStatus).HasColumnName("Reservation_Status");

                entity.Property(e => e.TicketTypeId).HasColumnName("Ticket_Type_ID");

                entity.HasOne(d => d.AirplaneCodeNavigation)
                    .WithMany(p => p.Seats)
                    .HasForeignKey(d => d.AirplaneCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Seats_Airplane");

                entity.HasOne(d => d.TicketType)
                    .WithMany(p => p.Seats)
                    .HasForeignKey(d => d.TicketTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Seats_Ticket_Type");
            });

            modelBuilder.Entity<Supplier>(entity =>
            {
                entity.Property(e => e.SupplierId).HasColumnName("Supplier_ID");

                entity.Property(e => e.Location)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SupplierName)
                    .HasColumnName("Supplier_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Ticket>(entity =>
            {
                entity.HasKey(e => e.TicketNo)
                    .HasName("PK__Ticket__ED7CB3F30E886EA8");

                entity.Property(e => e.TicketNo)
                    .HasColumnName("Ticket_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.FlightNo)
                    .IsRequired()
                    .HasColumnName("Flight_no")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerId).HasColumnName("Passenger_ID");

                entity.Property(e => e.SupplierId).HasColumnName("Supplier_ID");

                entity.Property(e => e.TicketTypeId).HasColumnName("Ticket_Type_ID");

                entity.HasOne(d => d.FlightNoNavigation)
                    .WithMany(p => p.Ticket)
                    .HasForeignKey(d => d.FlightNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Ticket_Flights");

                entity.HasOne(d => d.Passenger)
                    .WithMany(p => p.Ticket)
                    .HasForeignKey(d => d.PassengerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Ticket_Passenger");

                entity.HasOne(d => d.Supplier)
                    .WithMany(p => p.Ticket)
                    .HasForeignKey(d => d.SupplierId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Ticket_Supplier");

                entity.HasOne(d => d.TicketType)
                    .WithMany(p => p.Ticket)
                    .HasForeignKey(d => d.TicketTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Ticket_Ticket_Type");
            });

            modelBuilder.Entity<TicketType>(entity =>
            {
                entity.ToTable("Ticket_Type");

                entity.Property(e => e.TicketTypeId).HasColumnName("Ticket_Type_ID");

                entity.Property(e => e.TicketTypeName)
                    .IsRequired()
                    .HasColumnName("Ticket_Type_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserType>(entity =>
            {
                entity.ToTable("User_Type");

                entity.Property(e => e.UserTypeId).HasColumnName("User_Type_ID");

                entity.Property(e => e.AccessRights)
                   .IsRequired()
                   .HasColumnName("Access_Rights")
                   .HasMaxLength(10)
                   .IsUnicode(false);

                entity.Property(e => e.UserType1)
                    .IsRequired()
                    .HasColumnName("User_Type")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__tmp_ms_x__206D919061E7A6D9");

                entity.Property(e => e.UserId).HasColumnName("User_ID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.AirportCode)
                    .IsRequired()
                    .HasColumnName("Airport_code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.BirthDate)
                    .HasColumnName("Birth_Date")
                    .HasColumnType("date");

                entity.Property(e => e.DeptId).HasColumnName("Dept_ID");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FullName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .IsRequired()
                    .HasColumnName("Phone_Num")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.UserTypeId).HasColumnName("User_Type_ID");

                entity.Property(e => e.WorkTypeId).HasColumnName("Work_Type_ID");

                entity.HasOne(d => d.AirportCodeNavigation)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.AirportCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_Airport");

                entity.HasOne(d => d.Dept)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.DeptId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_Department");

                entity.HasOne(d => d.UserType)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.UserTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_User_Type");

                entity.HasOne(d => d.WorkType)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.WorkTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_Work_Type");
            });

            modelBuilder.Entity<WorkType>(entity =>
            {
                entity.ToTable("Work_Type");

                entity.Property(e => e.WorkTypeId).HasColumnName("Work_Type_ID");

                entity.Property(e => e.FeePerHour)
                    .HasColumnName("Fee_per_hour")
                    .HasColumnType("money");

                entity.Property(e => e.NumOfHours).HasColumnName("Num_of_hours");

                entity.Property(e => e.WorkName)
                    .IsRequired()
                    .HasColumnName("Work_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
