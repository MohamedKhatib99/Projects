﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Seats
    {
        public Seats()
        {
            CheckIn = new HashSet<CheckIn>();
        }

        public int SeatId { get; set; }
        public string AirplaneCode { get; set; }
        public int TicketTypeId { get; set; }
        public string SeatNo { get; set; }
        public int ReservationStatus { get; set; }


        public virtual Airplane AirplaneCodeNavigation { get; set; }
        public virtual TicketType TicketType { get; set; }
        public virtual ICollection<CheckIn> CheckIn { get; set; }
    }
}
