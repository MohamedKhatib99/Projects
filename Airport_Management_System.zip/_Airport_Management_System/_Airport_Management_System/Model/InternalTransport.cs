﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class InternalTransport
    {
        public int TransportNo { get; set; }
        public string FlightNo { get; set; }
        public int BusId { get; set; }

        public virtual Buses Bus { get; set; }
        public virtual Flights FlightNoNavigation { get; set; }
    }
}
