﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _Airport_Management_System.Model
{
    public partial class Users
    {
        public int UserId { get; set; }
        public string AirportCode { get; set; }
        public int UserTypeId { get; set; }
        public int DeptId { get; set; }
        public int WorkTypeId { get; set; }
        public string FullName { get; set; }
        public DateTime BirthDate { get; set; }
        public string Gender { get; set; }
        public string PhoneNum { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public virtual Airport AirportCodeNavigation { get; set; }
        public virtual Department Dept { get; set; }
        public virtual UserType UserType { get; set; }
        public virtual WorkType WorkType { get; set; }

        public bool login(string email, string password)
        {
            try
            {
                using (Airport_Management_System_DBContext db = new Airport_Management_System_DBContext())
                {
                    Users result = db.Users.Where(x => x.Email.ToLower() == email.ToLower() && x.Password == password).FirstOrDefault();
                    if (result != null)
                    {
                        LoadProfile.u = result;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


        }

    }
}
