﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _Airport_Management_System.Model
{
    public class LoadProfile
    {
        LoadProfile()
        {
            ActiveForm = null;
        }
        public static int UserId { get; set; }
        public static string AirportCode { get; set; }
        public static int UserTypeId { get; set; }
        public static int DeptId { get; set; }
        public static int WorkTypeId { get; set; }
        public static string FullName { get; set; }
        public static DateTime BirthDate { get; set; }
        public static string Gender { get; set; }
        public static string PhoneNum { get; set; }
        public static string Address { get; set; }
        public static string Email { get; set; }
        public static string Password { get; set; }
        public static Form ActiveForm { get; set; }

        public static Panel DesktopPanel { get; set; }
        public static Label Titlelbl { get; set; }
        public static Users u { get; set; }
        public static Supplier s { get; set; }


    }
}
