﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class LandingArea
    {
        public LandingArea()
        {
            Helipad = new HashSet<Helipad>();
            Runway = new HashSet<Runway>();
        }

        public int LaId { get; set; }
        public string AirportCode { get; set; }
        public string AreaName { get; set; }
        public double AreaCovered { get; set; }

        public virtual Airport AirportCodeNavigation { get; set; }
        public virtual ICollection<Helipad> Helipad { get; set; }
        public virtual ICollection<Runway> Runway { get; set; }
    }
}
