﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class WorkType
    {
        public WorkType()
        {
            Users = new HashSet<Users>();
        }

        public int WorkTypeId { get; set; }
        public string WorkName { get; set; }
        public int NumOfHours { get; set; }
        public decimal FeePerHour { get; set; }

        public virtual ICollection<Users> Users { get; set; }
    }
}
