﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Supplier
    {
        public Supplier()
        {
            Ticket = new HashSet<Ticket>();
        }

        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public string Location { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public virtual ICollection<Ticket> Ticket { get; set; }
    }
}
