﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Airplane
    {
        public Airplane()
        {
            Flights = new HashSet<Flights>();
            GhTransportAirplane = new HashSet<GhTransportAirplane>();
            Seats = new HashSet<Seats>();
        }

        public string AirplaneCode { get; set; }
        public int AcId { get; set; }
        public int Capacity { get; set; }

        public virtual AirlineCompany Ac { get; set; }
        public virtual ICollection<Flights> Flights { get; set; }
        public virtual ICollection<GhTransportAirplane> GhTransportAirplane { get; set; }
        public virtual ICollection<Seats> Seats { get; set; }
    }
}
