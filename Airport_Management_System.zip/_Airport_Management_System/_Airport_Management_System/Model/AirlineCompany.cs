﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class AirlineCompany
    {
        public AirlineCompany()
        {
            Airplane = new HashSet<Airplane>();
        }

        public int AcId { get; set; }
        public string AcName { get; set; }
        public string Country { get; set; }

        public virtual ICollection<Airplane> Airplane { get; set; }
    }
}
