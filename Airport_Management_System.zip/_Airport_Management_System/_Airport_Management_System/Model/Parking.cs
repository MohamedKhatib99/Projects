﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Parking
    {
        public int ParkingNo { get; set; }
        public string AirportCode { get; set; }
        public string ParkingName { get; set; }
        public int Capacity { get; set; }
        public decimal Fee { get; set; }

        public virtual Airport AirportCodeNavigation { get; set; }
    }
}
