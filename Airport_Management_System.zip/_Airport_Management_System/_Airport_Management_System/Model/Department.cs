﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Department
    {
        public Department()
        {
            Users = new HashSet<Users>();
        }

        public int DeptId { get; set; }
        public string DeptName { get; set; }

        public virtual ICollection<Users> Users { get; set; }
    }
}
