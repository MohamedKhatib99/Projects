﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Gatehouse
    {
        public Gatehouse()
        {
            GhTransportAirplane = new HashSet<GhTransportAirplane>();
        }

        public int GhId { get; set; }
        public string AirportCode { get; set; }
        public string GhName { get; set; }
        public string Seating { get; set; }
        public string Counters { get; set; }
        public string JetBridge { get; set; }

        public virtual Airport AirportCodeNavigation { get; set; }
        public virtual ICollection<GhTransportAirplane> GhTransportAirplane { get; set; }
    }
}
