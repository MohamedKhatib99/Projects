﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class TicketType
    {
        public TicketType()
        {
            FlightsPrices = new HashSet<FlightsPrices>();
            Seats = new HashSet<Seats>();
            Ticket = new HashSet<Ticket>();
        }

        public int TicketTypeId { get; set; }
        public string TicketTypeName { get; set; }

        public virtual ICollection<FlightsPrices> FlightsPrices { get; set; }
        public virtual ICollection<Seats> Seats { get; set; }
        public virtual ICollection<Ticket> Ticket { get; set; }
    }
}
