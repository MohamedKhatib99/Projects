﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class FlightsPrices
    {
        public int PriceId { get; set; }
        public string FlightNo { get; set; }
        public int TicketTypeId { get; set; }
        public decimal Price { get; set; }

        public virtual Flights FlightNoNavigation { get; set; }
        public virtual TicketType TicketType { get; set; }
    }
}
