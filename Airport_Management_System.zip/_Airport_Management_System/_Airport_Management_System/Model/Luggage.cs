﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Luggage
    {
        public int LuggageId { get; set; }
        public int PassengerId { get; set; }
        public int Bags { get; set; }
        public double Weight { get; set; }

        public virtual Passenger Passenger { get; set; }
    }
}
