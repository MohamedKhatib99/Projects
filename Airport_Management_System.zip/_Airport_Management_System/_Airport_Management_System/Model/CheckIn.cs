﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class CheckIn
    {
        public int ChechInId { get; set; }
        public string TicketNo { get; set; }
        public int SeatId { get; set; }

        public virtual Seats Seat { get; set; }
        public virtual Ticket TicketNoNavigation { get; set; }
    }
}
