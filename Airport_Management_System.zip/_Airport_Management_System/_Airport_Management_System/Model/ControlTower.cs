﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class ControlTower
    {
        public ControlTower()
        {
            Flights = new HashSet<Flights>();
        }

        public int CtId { get; set; }
        public string AirportCode { get; set; }
        public string CtName { get; set; }
        public double Range { get; set; }
        public int NoOfTower { get; set; }
        public string ControllingCapacity { get; set; }

        public virtual Airport AirportCodeNavigation { get; set; }
        public virtual ICollection<Flights> Flights { get; set; }
    }
}
