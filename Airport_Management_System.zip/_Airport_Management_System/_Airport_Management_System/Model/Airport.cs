﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Airport
    {
        public Airport()
        {
            ControlTower = new HashSet<ControlTower>();
            Gate = new HashSet<Gate>();
            Gatehouse = new HashSet<Gatehouse>();
            LandingArea = new HashSet<LandingArea>();
            Parking = new HashSet<Parking>();
            Users = new HashSet<Users>();
        }

        public string AirportCode { get; set; }
        public string AirportName { get; set; }
        public int CityId { get; set; }

        public virtual City City { get; set; }
        public virtual ICollection<ControlTower> ControlTower { get; set; }
        public virtual ICollection<Gate> Gate { get; set; }
        public virtual ICollection<Gatehouse> Gatehouse { get; set; }
        public virtual ICollection<LandingArea> LandingArea { get; set; }
        public virtual ICollection<Parking> Parking { get; set; }
        public virtual ICollection<Users> Users { get; set; }
    }
}
