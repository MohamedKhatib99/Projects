﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Helipad
    {
        public int HpId { get; set; }
        public string HelipadCode { get; set; }
        public int LaId { get; set; }

        public virtual LandingArea La { get; set; }
    }
}
