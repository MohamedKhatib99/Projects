﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class City
    {
        public City()
        {
            Airport = new HashSet<Airport>();
        }

        public int CityId { get; set; }
        public string CityName { get; set; }
        public string Country { get; set; }

        public virtual ICollection<Airport> Airport { get; set; }
    }
}
