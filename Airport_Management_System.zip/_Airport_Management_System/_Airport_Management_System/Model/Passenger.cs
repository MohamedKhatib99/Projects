﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Passenger
    {
        public Passenger()
        {
            Luggage = new HashSet<Luggage>();
            Ticket = new HashSet<Ticket>();
        }

        public int PassengerId { get; set; }
        public string PassengerTc { get; set; }
        public string Name { get; set; }
        public int Gender { get; set; }
        public DateTime BirthDate { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string PhoneNum { get; set; }

        public virtual ICollection<Luggage> Luggage { get; set; }
        public virtual ICollection<Ticket> Ticket { get; set; }
    }
}
