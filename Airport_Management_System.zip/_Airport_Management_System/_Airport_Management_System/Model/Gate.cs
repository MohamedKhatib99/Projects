﻿using System;
using System.Collections.Generic;

namespace _Airport_Management_System.Model
{
    public partial class Gate
    {
        public Gate()
        {
            Flights = new HashSet<Flights>();
        }

        public string GateNo { get; set; }
        public string AirportCode { get; set; }
        public string Purpose { get; set; }

        public virtual Airport AirportCodeNavigation { get; set; }
        public virtual ICollection<Flights> Flights { get; set; }
    }
}
