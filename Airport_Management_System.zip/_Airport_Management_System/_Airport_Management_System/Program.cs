﻿using _Airport_Management_System.Forms.Airport_Forms;
using _Airport_Management_System.Forms.Passenger_Forms;
using _Airport_Management_System.Forms.Supplier_Forms;
using _Airport_Management_System.Forms.User_Forms;
using _Airport_Management_System.Forms;


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Airport_Management_System
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login_Frm());

        }
    }
}
