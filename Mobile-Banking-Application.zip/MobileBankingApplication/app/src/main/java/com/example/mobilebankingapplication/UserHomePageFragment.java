package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class UserHomePageFragment extends Fragment {
    private TextView fullname,balance;
    private Bundle bundle;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource customerDataSource;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_user_home,container,false);
        fullname = v.findViewById(R.id.tvh_fName);
        balance = v.findViewById(R.id.tvh_Balance);
        helper = new MySQLiteOpenHelper(getActivity(), "MobilBank_DB", null, 1);
        customerDataSource = new CustomerDataSource(helper);
        bundle = getArguments();
        int ID = bundle.getInt("ID");
        Customer customer = customerDataSource.getCustomerDataByID(ID);
        fullname.setText(getString(R.string.welcome)+" "+customer.getFullName().toUpperCase());
        balance.setText(customer.getBalance()+"");

        return v;
    }
}
