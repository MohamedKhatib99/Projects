package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class HomeFragment extends Fragment {
    ListView list;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource cds;
    private EditText search;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_home,container,false);
        helper = new MySQLiteOpenHelper(getContext(),"MobilBank_DB",null,1);
        cds = new CustomerDataSource(helper);
        list = v.findViewById(R.id.Lv_Main);
        search = v.findViewById(R.id.et_search_m);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() == 0 ){
                    RefreshListView("");
                }
                else {
                    RefreshListView(s);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        RefreshListView("");
        registerForContextMenu(list);

        return v;
    }


    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo() ;
        if(item.getItemId() == R.id.withdrawitem){
            try {
                TextView txt_name = (TextView) info.targetView.findViewById(R.id.tv_FName1);
                TextView txt_Accno = (TextView) info.targetView.findViewById(R.id.tv_ANum1);
                String Fname = txt_name.getText().toString();
                String Accno = txt_Accno.getText().toString();
                Bundle bundle = new Bundle();
                bundle.putString("FullName",Fname);
                bundle.putString("AccountNumber",Accno);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                WithdrawFragment withdrawFragment = new WithdrawFragment();
                withdrawFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container,withdrawFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
        if(item.getItemId() == R.id.deposititem){
            try {
                TextView txt_name = (TextView) info.targetView.findViewById(R.id.tv_FName1);
                TextView txt_Accno = (TextView) info.targetView.findViewById(R.id.tv_ANum1);
                String Fname = txt_name.getText().toString();
                String Accno = txt_Accno.getText().toString();
                Bundle bundle = new Bundle();
                bundle.putString("FullName",Fname);
                bundle.putString("AccountNumber",Accno);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                DepositFragment depositFragment = new DepositFragment();
                depositFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container,depositFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
        if(item.getItemId() == R.id.transferitem){
            try {
                TextView txt_name = (TextView) info.targetView.findViewById(R.id.tv_FName1);
                TextView txt_Accno = (TextView) info.targetView.findViewById(R.id.tv_ANum1);
                String Fname = txt_name.getText().toString();
                String Accno = txt_Accno.getText().toString();
                Bundle bundle = new Bundle();
                bundle.putString("FullName",Fname);
                bundle.putString("AccountNumber",Accno);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                TransferFragment transferFragment = new TransferFragment();
                transferFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container,transferFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
        if(item.getItemId() == R.id.delete1){
            try {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.ev_id);
                int id = Integer.parseInt(txt_id.getText().toString());
                cds.deleteCostumerById(id);
                RefreshListView("");
                return true;
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
            return true;
        }
        if(item.getItemId() == R.id.edit1){
            try {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.ev_id);
                int id = Integer.parseInt(txt_id.getText().toString());
                Bundle bundle = new Bundle();
                bundle.putInt("ID",id);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                UpdateCustomerFragment updateCustomerFragment = new UpdateCustomerFragment();
                updateCustomerFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container,updateCustomerFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }

        return super.onContextItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.fast_operations_menu,menu);
    }



    private void RefreshListView(CharSequence s){

        HomePageAdapter adapter = new HomePageAdapter(getActivity(),R.layout.customer_item_layout_fast,cds.getCustomersList(s));
        list.setAdapter(adapter);
    }
}
