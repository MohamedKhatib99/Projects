package com.example.mobilebankingapplication;

public class Currency {

    private int CurrencyID;
    private String CurrencyName;
    private String CurrencyUnit;
    private String SellRate;
    private String BuyRate;


    public Currency(String currencyName, String currencyUnit, String sellRate, String buyRate) {
        CurrencyName = currencyName;
        CurrencyUnit = currencyUnit;
        SellRate = sellRate;
        BuyRate = buyRate;
    }

    public int getCurrencyID() {
        return CurrencyID;
    }

    public void setCurrencyID(int currencyID) {
        CurrencyID = currencyID;
    }

    public String getCurrencyName() {
        return CurrencyName;
    }

    public void setCurrencyName(String currencyName) {
        CurrencyName = currencyName;
    }

    public String getCurrencyUnit() {
        return CurrencyUnit;
    }

    public void setCurrencyUnit(String currencyUnit) {
        CurrencyUnit = currencyUnit;
    }

    public String getSellRate() {
        return SellRate;
    }

    public void setSellRate(String sellRate) {
        SellRate = sellRate;
    }

    public String getBuyRate() {
        return BuyRate;
    }

    public void setBuyRate(String buyRate) {
        BuyRate = buyRate;
    }
}
