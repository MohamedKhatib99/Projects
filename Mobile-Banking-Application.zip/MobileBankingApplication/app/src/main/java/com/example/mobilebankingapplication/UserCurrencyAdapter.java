package com.example.mobilebankingapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class UserCurrencyAdapter extends ArrayAdapter {
    private List<Currency> list;
    private Context context;
    private int resId;

    public UserCurrencyAdapter(@NonNull Context context, int resource, @NonNull List list) {
        super(context, resource, list);
        this.list = list;
        this.context = context;
        this.resId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(resId, parent, false);
        TextView name = convertView.findViewById(R.id.tv_us_cname);
        TextView sell = convertView.findViewById(R.id.tv_us_csells);
        TextView buy = convertView.findViewById(R.id.tv_us_cbuys);
        name.setText(list.get(position).getCurrencyName().toUpperCase());
        sell.setText(list.get(position).getSellRate()+"TL");
        buy.setText(list.get(position).getBuyRate()+"TL");
        return convertView;
    }

    @Override
    public int getCount() {
        return list.size();
    }

}

