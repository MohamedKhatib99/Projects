package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class UpdateEmployeeFragment_1 extends Fragment {
    EditText phone,postcode,country,city,address;
    private Button update;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource eds;
    private Bundle bundle ;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_update_employee_1,container,false);
         update = v.findViewById(R.id.btn_update_employee);
         phone = v.findViewById(R.id.eteu_phonenumber);
         postcode = v.findViewById(R.id.eteu_postcode);
         country = v.findViewById(R.id.eteu_country);
         city = v.findViewById(R.id.eteu_city);
         address = v.findViewById(R.id.eteu_address);
         helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
         eds = new EmployeeDataSource(helper);
         bundle = getArguments();
         LoadEmployeeDate();
         update.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 try {
                     if(phone.getText().toString().trim().isEmpty() && postcode.getText().toString().trim().isEmpty() && country.getText().toString().isEmpty() &&city.getText().toString().trim().isEmpty()&&address.getText().toString().trim().isEmpty()){
                         phone.setError(getString(R.string.Enter_Phone));
                         postcode.setError(getString(R.string.Enter_Postcode));
                         country.setError(getString(R.string.Enter_Country));
                         city.setError(getString(R.string.Enter_City));
                         address.setError(getString(R.string.Enter_Address));
                         phone.requestFocus();
                         return;
                     }
                     if(phone.getText().toString().trim().isEmpty()){
                         phone.setError(getString(R.string.Enter_Phone));
                         phone.requestFocus();
                         return;
                     }
                     if(phone.getText().toString().trim().length() < 10){
                         phone.setError(getString(R.string.Invalid_phonenumber));
                         phone.requestFocus();
                         return;
                     }
                     if(postcode.getText().toString().trim().isEmpty()){
                         postcode.setError(getString(R.string.Enter_Postcode));
                         postcode.requestFocus();
                         return;
                     }
                     if(postcode.getText().toString().trim().length() < 5){
                         postcode.setError(getString(R.string.Invalid_Postcode));
                         postcode.requestFocus();
                         return;
                     }
                     if(country.getText().toString().isEmpty()){
                         country.setError(getString(R.string.Enter_Country));
                         country.requestFocus();
                         return;
                     }

                     if(city.getText().toString().trim().isEmpty()){
                         city.setError(getString(R.string.Enter_City));
                         city.requestFocus();
                         return;
                     }
                     if(address.getText().toString().trim().isEmpty()){
                         address.setError(getString(R.string.Enter_Address));
                         address.requestFocus();
                         return;
                     }

                     String TC = bundle.getString("TC");
                     int ID = bundle.getInt("ID");
                     long tc = Long.parseLong(TC.trim());
                     String FULLNAME = bundle.getString("FULLNAME");
                     String AGE = bundle.getString("AGE");
                     String GENDER = bundle.getString("GENDER");
                     String EMAIL = bundle.getString("EMAIL");
                     String PASSWORD = bundle.getString("PASSWORD");
                     String SALARY = bundle.getString("SALARY");
                     float salary = Float.parseFloat(SALARY.trim());
                     String PHONE = phone.getText().toString().trim();
                     long phone1 = Long.parseLong(PHONE.trim().trim());
                     String POSTCODE = postcode.getText().toString().trim();
                     int postcode1 = Integer.parseInt(POSTCODE.trim());
                     String COUNTRY = country.getText().toString().trim();
                     String CITY = city.getText().toString().trim();
                     String ADDRESS = address.getText().toString().trim();
                     boolean verify = eds.verifyEmployeeIfExist(EMAIL,ID);
                     if (verify) {
                         onCreateDialog1(getString(R.string.Email_Already_In_Use));

                         return;
                     }
                     Employee employee = new Employee(tc, FULLNAME, GENDER, AGE, EMAIL, PASSWORD, salary, phone1, postcode1, COUNTRY, CITY, ADDRESS);
                     boolean result = eds.updateEmployeeDate(employee, ID);
                     if (result) {
                         onCreateDialog();


                     } else {
                         onCreateDialog1(getString(R.string.erro_message));
                     }
                 }
                 catch (Exception e){
                     Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                 }

             }
         });


        return v;

    }
    public Dialog onCreateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.Info);
        builder.setMessage(R.string.Updated_Successfully);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentManager manager = getFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().commit();
            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.error);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }

    public void LoadEmployeeDate(){
        phone.setText(bundle.getString("PHONE"));
        postcode.setText(bundle.getString("POSTCODE"));
        country.setText(bundle.getString("COUNTRY"));
        city.setText(bundle.getString("CITY"));
        address.setText(bundle.getString("ADDRESS"));
    }



}
