package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class CreateNewAccountFragment_1 extends Fragment {
    EditText phone,postcode,country,city,address;
    private Button next;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_createnewaccount_1,container,false);
         next = v.findViewById(R.id.btn_next1);
         phone = v.findViewById(R.id.et_phonenumber);
         postcode = v.findViewById(R.id.et_postcode);
         country = v.findViewById(R.id.et_country);
         city = v.findViewById(R.id.et_city);
         address = v.findViewById(R.id.et_address);
         next.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 try {
                     Bundle bundle = getArguments();
                     String PHONE = phone.getText().toString();
                     String POSTCODE = postcode.getText().toString();
                     String COUNTRY = country.getText().toString();
                     String CITY = city.getText().toString();
                     String ADDRESS = address.getText().toString();

                     bundle.putString("PHONE", PHONE);
                     bundle.putString("POSTCODE", POSTCODE);
                     bundle.putString("COUNTRY", COUNTRY);
                     bundle.putString("CITY", CITY);
                     bundle.putString("ADDRESS", ADDRESS);

                     if (phone.getText().toString().trim().isEmpty() && postcode.getText().toString().trim().isEmpty() && country.getText().toString().isEmpty() && city.getText().toString().trim().isEmpty() && address.getText().toString().trim().isEmpty()) {
                         phone.setError(getString(R.string.Enter_Phone));
                         postcode.setError(getString(R.string.Enter_Postcode));
                         country.setError(getString(R.string.Enter_Country));
                         city.setError(getString(R.string.Enter_City));
                         address.setError(getString(R.string.Enter_Address));
                         phone.requestFocus();
                         return;
                     }
                     if (PHONE.isEmpty()) {
                         phone.setError(getString(R.string.Enter_Phone));
                         phone.requestFocus();
                         return;
                     }
                     if (PHONE.length() < 10) {
                         phone.setError(getString(R.string.Invalid_phonenumber));
                         phone.requestFocus();
                         return;
                     }
                     if (POSTCODE.isEmpty()) {
                         postcode.setError(getString(R.string.Enter_Postcode));
                         postcode.requestFocus();
                         return;
                     }
                     if (POSTCODE.length() < 5) {
                         postcode.setError(getString(R.string.Invalid_Postcode));
                         postcode.requestFocus();
                         return;
                     }
                     if (COUNTRY.isEmpty()) {
                         country.setError(getString(R.string.Enter_Country));
                         country.requestFocus();
                         return;
                     }

                     if (CITY.isEmpty()) {
                         city.setError(getString(R.string.Enter_City));
                         city.requestFocus();
                         return;
                     }
                     if (ADDRESS.isEmpty()) {
                         address.setError(getString(R.string.Enter_Address));
                         address.requestFocus();
                         return;
                     }
                     FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                     CreateNewAccountFragment_2 createNewAccountFragment_2 = new CreateNewAccountFragment_2();
                     createNewAccountFragment_2.setArguments(bundle);
                     fragmentTransaction.replace(R.id.fragment_container, createNewAccountFragment_2);
                     fragmentTransaction.addToBackStack(null);
                     fragmentTransaction.commit();
                 }
                 catch (Exception e){
                     Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                 }
             }
         });


        return v;

    }
}
