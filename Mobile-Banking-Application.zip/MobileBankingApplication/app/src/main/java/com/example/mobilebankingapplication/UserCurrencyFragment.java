package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class UserCurrencyFragment extends Fragment {
    private ListView list;
    private MySQLiteOpenHelper helper;
    private CurrencyDataSource cds;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_user_currency,container,false);
        helper = new MySQLiteOpenHelper(getContext(),"MobilBank_DB",null,1);
        cds = new CurrencyDataSource(helper);
        list = v.findViewById(R.id.lv_user_currency);
        RefreshListView("");
        return v;
    }
    private void RefreshListView(CharSequence s) {
        try {
            UserCurrencyAdapter adapter = new UserCurrencyAdapter(getActivity(), R.layout.user_currency_item_layout, cds.getCurrencyList(s));
            list.setAdapter(adapter);
        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}
