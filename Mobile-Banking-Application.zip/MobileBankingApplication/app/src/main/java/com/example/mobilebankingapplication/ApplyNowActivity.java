package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;


public class ApplyNowActivity extends AppCompatActivity {
    private EditText Tc,FullName,BirthDate,PhoneNumber,Email;
    private Button btnApplyNow;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource cds;
    AwesomeValidation awesomeValidation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_now);
        helper = new MySQLiteOpenHelper(this,"MobilBank_DB",null,1);
        cds = new CustomerDataSource(helper);
        Tc = findViewById(R.id.et_tc);
        FullName = findViewById(R.id.et_fullname);
        BirthDate = findViewById(R.id.et_birthdate);
        PhoneNumber = findViewById(R.id.et_phone);
        Email = findViewById(R.id.et_email);
        btnApplyNow = findViewById(R.id.btn_applynow);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        awesomeValidation.addValidation(this,R.id.et_tc, "[0-9]{11}$",R.string.Invalid_tc);
        awesomeValidation.addValidation(this,R.id.et_fullname, RegexTemplate.NOT_EMPTY,R.string.Invalid_fullname);
        awesomeValidation.addValidation(this,R.id.et_birthdate, "[0-3]{1}[0-9]{1}[/]{1}[0-1]{1}[0-9]{1}[/]{1}[0-9]{4}$",R.string.Invalid_birthdate);
        awesomeValidation.addValidation(this,R.id.et_phone, "[5-5]{1}[0-9]{9}$",R.string.Invalid_phonenumber);
        awesomeValidation.addValidation(this,R.id.et_email, Patterns.EMAIL_ADDRESS,R.string.invalid_email);
        btnApplyNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(awesomeValidation.validate()){
                    try {
                        long tc = Long.parseLong(Tc.getText().toString().trim());
                        String fullname = FullName.getText().toString().trim();
                        String birthdate = BirthDate.getText().toString().trim();
                        long phone = Long.parseLong(PhoneNumber.getText().toString().trim());
                        String email = Email.getText().toString().trim();
                        Customer cst = new Customer(tc,fullname,birthdate,phone,email);
                        cds.addNewApplication(cst);
                        clear();
                        onCreateDialog(getString(R.string.Info),getString(R.string.ApplicationSent));
                    }
                    catch (Exception e){
                        Toast.makeText(ApplyNowActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                    }

                }
            }
        });

    }
    private void clear(){
        Tc.setText("");
        FullName.setText("");
        BirthDate.setText("");
        PhoneNumber.setText("");
        Email.setText("");
    }
    public Dialog onCreateDialog(String info, String Message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ApplyNowActivity.this);
        builder.setTitle(info);
        builder.setMessage(Message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.create();
        return builder.show();
    }


}
