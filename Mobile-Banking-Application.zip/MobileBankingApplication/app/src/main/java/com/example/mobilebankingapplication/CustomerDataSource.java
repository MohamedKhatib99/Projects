package com.example.mobilebankingapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class CustomerDataSource extends Person{
    private MySQLiteOpenHelper helper;
    private SQLiteDatabase db;
    public CustomerDataSource(MySQLiteOpenHelper helper) {
        this.helper = helper;
        db = helper.getWritableDatabase();
    }
    public boolean Login(String email,String password){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CustomersTable WHERE Email = ? AND Password = ?",new String[]{email,password});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean verifyCustomerIfExist(String tc,String email,String accountnum){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CustomersTable join AccountsTable on CustomersTable.CustomerID = AccountsTable.CustomerID WHERE TC = ? or Email = ? or AccountNumber = ?",new String[]{tc,email,accountnum});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean verifyCustomerIfExist(String email,int id){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CustomersTable WHERE Email = ? AND CustomerID != ?",new String[]{email,id+""});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }

    public boolean updateCustomerAccName(String accname,int ID){
        Cursor cursor = db.rawQuery("UPDATE AccountsTable SET AccountName = ? WHERE CustomerID = ?",new String[]{accname,ID+""});
        return true;
    }

    public boolean addNewCustomer(Customer cst){
        ContentValues values = new ContentValues();
        values.put("TC",cst.getTC());
        values.put("FullName",cst.getFullName());
        values.put("FatherName",cst.getFatherName());
        values.put("MotherName",cst.getMotherName());
        values.put("BirthDate",cst.getBirthDate());
        values.put("Gender",cst.getGender());
        values.put("Email",cst.getEmail());
        values.put("Password",cst.getPassword());
        values.put("AccessType",cst.getAccessType());

        ContentValues values1 = new ContentValues();
        values1.put("PhoneNumber",cst.getPhoneNumber());
        values1.put("PostCode",cst.getPostcode());
        values1.put("Country",cst.getCountry());
        values1.put("City",cst.getCity());
        values1.put("Address",cst.getAddress());

        ContentValues values2 = new ContentValues();
        values2.put("AccountNumber",cst.getAccountNumber());
        values2.put("AccountType",cst.getAccountType());
        values2.put("AccountName",cst.getAccountName());
        values2.put("Balance",cst.getBalance());
        values2.put("Description",cst.getDescription());
        long id2 = db.insert("AccountsTable",null,values2);
        long id1 = db.insert("CustomersContactInfoTable",null,values1);
        long id = db.insert("CustomersTable",null,values);
        if(id == -1 || id1 == -1 || id2 == -1){
            return false;
        }
        else return true;
    }




    public boolean updateCustomerDate(Customer ca,int ID){
        ContentValues values = new ContentValues();
        values.put("TC",ca.getTC());
        values.put("FullName",ca.getFullName());
        values.put("FatherName",ca.getFatherName());
        values.put("MotherName",ca.getMotherName());
        values.put("BirthDate",ca.getBirthDate());
        values.put("Gender",ca.getGender());
        values.put("Email",ca.getEmail());
        values.put("Password",ca.getPassword());

        ContentValues values1 = new ContentValues();
        values1.put("PhoneNumber",ca.getPhoneNumber());
        values1.put("PostCode",ca.getPostcode());
        values1.put("Country",ca.getCountry());
        values1.put("City",ca.getCity());
        values1.put("Address",ca.getAddress());

        ContentValues values2 = new ContentValues();
        values2.put("AccountNumber",ca.getAccountNumber());
        values2.put("AccountType",ca.getAccountType());
        values2.put("AccountName",ca.getAccountName());
        values2.put("Balance",ca.getBalance());
        values2.put("Description",ca.getDescription());
        long id2 = db.update("AccountsTable",values2,"CustomerID =  "+ID,null);
        long id1 = db.update("CustomersContactInfoTable",values1,"CustomerID = "+ID,null);
        long id = db.update("CustomersTable",values,"CustomerID = "+ID,null);
        if(id == -1 || id1 == -1 || id2 == -1){
            return false;
        }
        else return true;
    }



    public Customer getCustomerDataByID(int ID){
        Cursor cursor = db.query("CustomersTable",new String[]{"TC","FullName","FatherName","MotherName","BirthDate","Gender","Email","Password"},"CustomerID = ? ",new String[]{ID+""},null,null,null,null);
        cursor.moveToFirst();
        Cursor cursor1 = db.query("CustomersContactInfoTable",new String[]{"PhoneNumber","PostCode","Country","City","Address"},"CustomerID = ?",new String[]{ID+""},null,null,null,null);
        cursor1.moveToFirst();
        Cursor cursor2 = db.query("AccountsTable",new String[]{"AccountNumber","AccountType","AccountName","Balance","Description"},"CustomerID = ?",new String[]{ID+""},null,null,null,null);
        cursor2.moveToFirst();
        Customer customer = null;
        while(!cursor.isAfterLast() && !cursor1.isAfterLast()&& !cursor2.isAfterLast()){
            long TC = cursor.getLong(0);
            String FullName = cursor.getString(1);
            String FatherName = cursor.getString(2);
            String MotherName = cursor.getString(3);
            String Age = cursor.getString(4);
            String Gender = cursor.getString(5);
            String Email = cursor.getString(6);
            String Password = cursor.getString(7);
            long phone = cursor1.getLong(0) ;
            int postcode = cursor1.getInt(1);
            String country = cursor1.getString(2);
            String city = cursor1.getString(3);
            String address = cursor1.getString(4);
            long AccountNumber = cursor2.getLong(0) ;
            String AccountType = cursor2.getString(1);
            String AccountName = cursor2.getString(2);
            float Balance = cursor2.getFloat(3);
            String Description = cursor2.getString(4);
            customer = new Customer(TC,FullName,FatherName,MotherName,Gender,Age,Email,Password,phone,postcode,country,city,address,AccountNumber,AccountType,Balance,AccountName,Description);
            customer.set_id(ID);
            cursor.moveToNext();
            cursor1.moveToNext();
            cursor2.moveToNext();

        }
        cursor.close();
        cursor1.close();
        cursor2.close();
        return customer;
    }
    public boolean addNewApplication(Customer cst){
        ContentValues values = new ContentValues();
        values.put("TC",cst.getTC()+"");
        values.put("FullName",cst.getFullName());
        values.put("BirthDate",cst.getBirthDate());
        values.put("PhoneNumber",cst.getPhoneNumber()+"");
        values.put("Email",cst.getEmail());
        long id = db.insert("ApplicationsTable",null,values);
        if(id == -1)
        {return false;}
        else return true;

    }
    public Customer getCustomerByEmailAndPassword(String email, String password) {
        Customer customer = null;
        int id = 0;
        Cursor cursor = db.query("CustomersTable",new String[]{"CustomerID","TC","FullName","FatherName","MotherName","BirthDate","Gender","Email","Password"},"Email = ? AND Password = ?",new String[]{email,password},null,null,null,null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()) {
            id = cursor.getInt(0) ;
            long TC = cursor.getLong(1);
            String FullName = cursor.getString(2);
            String FatherName = cursor.getString(3);
            String MotherName = cursor.getString(4);
            String Age = cursor.getString(5);
            String Gender = cursor.getString(6);
            String Email = cursor.getString(7);
            String Password = cursor.getString(8);
            cursor.moveToNext();
            customer = new Customer(TC,FullName,FatherName,MotherName,Gender,Age,Email,Password);
            customer.set_id(id);
        }
        Cursor cursor1 = db.query("CustomersContactInfoTable",new String[]{"PhoneNumber","PostCode","Country","City","Address"},"CustomerID = ?",new String[]{id+""},null,null,null,null);
        cursor1.moveToFirst();
        while(!cursor1.isAfterLast()) {
            long phone = cursor1.getLong(0) ;
            int postcode = cursor1.getInt(1);
            String country = cursor1.getString(2);
            String city = cursor1.getString(3);
            String address = cursor1.getString(4);
            customer.setPhoneNumber(phone);
            customer.setCountry(country);
            customer.setPostcode(postcode);
            customer.setCity(city);
            customer.setAddress(address);
            cursor1.moveToNext();
        }

        Cursor cursor2 = db.query("AccountsTable",new String[]{"AccountNumber","AccountType","AccountName","Balance","Description"},"CustomerID = ?",new String[]{id+""},null,null,null,null);
        cursor2.moveToFirst();
        while(!cursor2.isAfterLast()) {
            long AccountNumber = cursor2.getLong(0) ;
            String AccountType = cursor2.getString(1);
            String AccountName = cursor2.getString(2);
            float Balance = cursor2.getFloat(3);
            String Description = cursor2.getString(4);
            customer.setAccountNumber(AccountNumber);
            customer.setAccountName(AccountName);
            customer.setAccountType(AccountType);
            customer.setBalance(Balance);
            customer.setDescription(Description);
            cursor2.moveToNext();
        }
        cursor2.close();
        cursor1.close();
        cursor.close();
        return customer;
    }
    public List getCustomersList(CharSequence s){
        ArrayList<Customer> List = new ArrayList<>();
        Cursor cursor = db.query("CustomersTable",new String[]{"CustomerID","TC","FullName","FatherName","MotherName","BirthDate","Gender","Email","Password"},null,null,null,null,null,null);
        cursor.moveToFirst();
        Cursor cursor1 = db.query("CustomersContactInfoTable",new String[]{"PhoneNumber","PostCode","Country","City","Address"},null,null,null,null,null,null);
        cursor1.moveToFirst();
        Cursor cursor2 = db.query("AccountsTable",new String[]{"AccountNumber","AccountType","AccountName","Balance","Description"},null,null,null,null,null,null);
        cursor2.moveToFirst();
        Customer customer;
        int id = 0;
        while(!cursor.isAfterLast() && !cursor1.isAfterLast() && !cursor2.isAfterLast()){
            id = cursor.getInt(0) ;
            long TC = cursor.getLong(1);
            String FullName = cursor.getString(2);
            String FatherName = cursor.getString(3);
            String MotherName = cursor.getString(4);
            String BirthDate = cursor.getString(5);
            String Gender = cursor.getString(6);
            String Email = cursor.getString(7);
            String Password = cursor.getString(8);
            long phone = cursor1.getLong(0) ;
            int postcode = cursor1.getInt(1);
            String country = cursor1.getString(2);
            String city = cursor1.getString(3);
            String address = cursor1.getString(4);
            long AccountNumber = cursor2.getLong(0) ;
            String AccountType = cursor2.getString(1);
            String AccountName = cursor2.getString(2);
            float Balance = cursor2.getFloat(3);
            String Description = cursor2.getString(4);
            customer = new Customer(TC,FullName,FatherName,MotherName,Gender,BirthDate,Email,Password,phone,postcode,country,city,address,AccountNumber,AccountType,Balance,AccountName,Description);
            customer.set_id(id);
            if(customer.getFullName().toLowerCase().trim().contains(s.toString().toLowerCase())){
                List.add(customer);
            }
            cursor.moveToNext();
            cursor1.moveToNext();
            cursor2.moveToNext();
        }
        cursor.close();
        cursor1.close();
        cursor2.close();
        return List;
    }
    public void deleteCostumerById(int id ){
        db.delete("CustomersTable","CustomerID=?",new String[]{Integer.toString(id)});
        db.delete("CustomersContactInfoTable","CustomerID=?",new String[]{Integer.toString(id)});
        db.delete("AccountsTable","CustomerID=?",new String[]{Integer.toString(id)});
    }
    public void deleteApplicationById(int id ){
        db.delete("ApplicationsTable","_id=?",new String[]{Integer.toString(id)});
    }
    public List getAllApplicationData(CharSequence s){
        ArrayList<Customer> List = new ArrayList<>();
        Cursor cursor = db.query("ApplicationsTable",new String[]{"_id","TC","FullName","BirthDate","PhoneNumber","Email"},null,null,null,null,null,null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            int _id = cursor.getInt(0) ;
            long TC = cursor.getLong(1);
            String FullName = cursor.getString(2);
            String Age = cursor.getString(3);
            long ContactNo = cursor.getLong(4);
            String Email = cursor.getString(5);
            Customer cst = new Customer(TC,FullName,Age,ContactNo,Email);
            cst.set_id(_id);
            if(FullName.trim().toLowerCase().contains(s.toString().toLowerCase())){
                List.add(cst);
            }
            cursor.moveToNext();

        }
        cursor.close();
        return List;
    }



}
