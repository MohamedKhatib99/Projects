package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class AccountsFragment extends Fragment {
    private Button createaccount,viewcustomerslist;
    private MySQLiteOpenHelper helper ;
    private CustomerDataSource cds;
    private ListView list;
    private EditText search;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_accounts,container,false);
        helper = new MySQLiteOpenHelper(getContext(),"MobilBank_DB",null,1);
        cds = new CustomerDataSource(helper);
        viewcustomerslist = v.findViewById(R.id.btn_viewaccountslist);
         createaccount = v.findViewById(R.id.btn_newaccount);
         list = v.findViewById(R.id.customers_listview);
         search = v.findViewById(R.id.et_search);
         search.addTextChangedListener(new TextWatcher() {
             @Override
             public void beforeTextChanged(CharSequence s, int start, int count, int after) {

             }

             @Override
             public void onTextChanged(CharSequence s, int start, int before, int count) {
                 if(s.length() == 0 ){
                     RefreshListView("");
                 }
                 else {
                     RefreshListView(s);
                 }
             }

             @Override
             public void afterTextChanged(Editable s) {

             }
         });
         createaccount.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                 fragmentTransaction.replace(R.id.fragment_container,new CreateNewAccountsFragment());
                 fragmentTransaction.addToBackStack(null);
                 fragmentTransaction.commit();
             }
         });
         viewcustomerslist.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 RefreshListView("");
             }
         });
        registerForContextMenu(list);
        RefreshListView("");
        return v;

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo() ;
        if(item.getItemId() == R.id.delete){
            try {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.tvca_ID);
                int id = Integer.parseInt(txt_id.getText().toString());
                cds.deleteCostumerById(id);
                RefreshListView("");
                return true;
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
            TextView txt_id = (TextView) info.targetView.findViewById(R.id.tvca_ID);
            int id = Integer.parseInt(txt_id.getText().toString());
            cds.deleteCostumerById(id);
            RefreshListView("");
            return true;
        }
        if(item.getItemId() == R.id.edit2){
            try {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.tvca_ID);
                int id = Integer.parseInt(txt_id.getText().toString());
                Bundle bundle = new Bundle();
                bundle.putInt("ID",id);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                UpdateCustomerFragment updateCustomerFragment = new UpdateCustomerFragment();
                updateCustomerFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container,updateCustomerFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
            catch (Exception e){
                Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
        if(item.getItemId() == R.id.profile){

        }

        return super.onContextItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.context_menu3,menu);
    }

    private void RefreshListView(CharSequence s ){

        CustomersAdapter adapter = new CustomersAdapter(getActivity(),R.layout.customers_item_layout,cds.getCustomersList(s));
        list.setAdapter(adapter);
    }
}
