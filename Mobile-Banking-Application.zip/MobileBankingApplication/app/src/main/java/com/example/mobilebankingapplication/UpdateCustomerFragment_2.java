package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class UpdateCustomerFragment_2 extends Fragment {
    private Button update;
    EditText accno,acctype,accname,balance,description;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource cds;
    private Bundle bundle;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_update_customer_2,container,false);
         helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
         cds = new CustomerDataSource(helper);
         update = v.findViewById(R.id.btnca_update);
         accno = v.findViewById(R.id.etca_accno);
         acctype = v.findViewById(R.id.etca_acctype);
         accname = v.findViewById(R.id.etca_accname);
         balance = v.findViewById(R.id.etca_balance);
         description = v.findViewById(R.id.etca_description);
         bundle = getArguments();
         LoadCustomerData();
         update.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 try {
                     if (accno.getText().toString().isEmpty() && acctype.getText().toString().trim().isEmpty() && accname.getText().toString().trim().isEmpty() && balance.getText().toString().trim().isEmpty() && description.getText().toString().trim().isEmpty()) {
                         accno.setError(getString(R.string.Enter_Account_Number));
                         acctype.setError(getString(R.string.Enter_Account_Type));
                         accname.setError(getString(R.string.Enter_Account_Name));
                         balance.setError(getString(R.string.Enter_Balance));
                         description.setError(getString(R.string.Enter_Description));
                         accno.requestFocus();
                         return;
                     }
                     if (accno.getText().toString().isEmpty()) {
                         accno.setError(getString(R.string.Enter_Account_Number));
                         accno.requestFocus();
                         return;
                     }
                     if (accno.getText().toString().length() < 10) {
                         accno.setError(getString(R.string.Invalid_Account_Number));
                         accno.requestFocus();
                         return;
                     }
                     if (acctype.getText().toString().trim().isEmpty()) {
                         acctype.setError(getString(R.string.Enter_Account_Type));
                         acctype.requestFocus();
                         return;
                     }
                     if (accname.getText().toString().trim().isEmpty()) {
                         accname.setError(getString(R.string.Enter_Account_Name));
                         accname.requestFocus();
                         return;
                     }

                     if (balance.getText().toString().trim().isEmpty()) {
                         balance.setError(getString(R.string.Enter_Balance));
                         balance.requestFocus();
                         return;
                     }
                     if (description.getText().toString().trim().isEmpty()) {
                         description.setError(getString(R.string.Enter_Description));
                         description.requestFocus();
                         return;
                     }
                     int id = bundle.getInt("ID");
                     String TC = bundle.getString("TC");
                     long tc = Long.parseLong(TC.trim());
                     String FULLNAME = bundle.getString("FULLNAME");
                     String FATHERNAME = bundle.getString("FATHERNAME");
                     String MOTHERNAME = bundle.getString("MOTHERNAME");
                     String AGE = bundle.getString("AGE");
                     String GENDER = bundle.getString("GENDER");
                     String EMAIL = bundle.getString("EMAIL");
                     String PASSWORD = bundle.getString("PASSWORD");
                     String PHONE = bundle.getString("PHONE");
                     long phone = Long.parseLong(PHONE.trim());
                     String POSTCODE = bundle.getString("POSTCODE");
                     int postcode = Integer.parseInt(POSTCODE.trim());
                     String COUNTRY = bundle.getString("COUNTRY");
                     String CITY = bundle.getString("CITY");
                     String ADDRESS = bundle.getString("ADDRESS");
                     String AccountNumber = accno.getText().toString().trim();
                     long An = Long.parseLong(AccountNumber);
                     String AccountType = acctype.getText().toString().trim();
                     String AccountName = accname.getText().toString().trim();
                     String Balance = balance.getText().toString().trim();
                     float bal = Float.parseFloat(Balance);
                     String Description = description.getText().toString().trim();
                     boolean verify = cds.verifyCustomerIfExist(EMAIL,id);
                     if (verify) {
                         onCreateDialog1(getString(R.string.Email_Already_In_Use));

                         return;
                     }
                     Customer cs = new Customer(tc, FULLNAME, FATHERNAME, MOTHERNAME, GENDER, AGE, EMAIL, PASSWORD, phone, postcode, COUNTRY, CITY, ADDRESS, An, AccountType, bal, AccountName, Description);
                     boolean result = cds.updateCustomerDate(cs, id);
                     if (result) {
                         onCreateDialog();
                     } else {
                         onCreateDialog1(getString(R.string.erro_message));
                     }


                 }
                 catch (Exception e){
                     Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                 }
             }
         });


        return v;

    }
    public Dialog onCreateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.Info);
        builder.setMessage(R.string.Updated_Successfully);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentManager manager = getFragmentManager();
                assert manager != null;
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().commit();

            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.error);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    public void LoadCustomerData(){
        accno.setText(bundle.getString("ACCOUNTNUMBER"));
        acctype.setText(bundle.getString("ACCOUNTTYPE"));
        accname.setText(bundle.getString("ACCOUNTNAME"));
        balance.setText(bundle.getString("BALANCE"));
        description.setText(bundle.getString("DESCRIPTION"));
    }

}
