package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class WithdrawFragment extends Fragment {
    EditText account,amount;
    Button withdraw;
    private MySQLiteOpenHelper helper;
    private Actions actions;
    Bundle bundle ;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_withdraw,container,false);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        actions = new Actions(helper);
        account = v.findViewById(R.id.etw_accno);
        amount = v.findViewById(R.id.etw_amount);
        withdraw = v.findViewById(R.id.btnwithdraw);
        bundle = getArguments();
        if(bundle != null){
            account.setText(bundle.getString("AccountNumber"));
        }
        withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (account.getText().toString().trim().isEmpty() && amount.getText().toString().trim().isEmpty()) {
                        account.setError(getString(R.string.Enter_Account_Number));
                        amount.setError(getString(R.string.Enter_Amount));
                        account.requestFocus();
                        return;
                    }
                    if (account.getText().toString().trim().isEmpty()) {
                        account.setError(getString(R.string.Enter_Account_Number));
                        account.requestFocus();
                        return;
                    }
                    if (account.getText().toString().trim().length() != 10 ) {
                        account.setError(getString(R.string.Invalid_Account_Number));
                        account.requestFocus();
                        return;
                    }
                    if (amount.getText().toString().trim().isEmpty()) {
                        amount.setError(getString(R.string.Enter_Amount));
                        amount.requestFocus();
                        return;
                    }
                    if (Float.parseFloat(amount.getText().toString().trim()) < 0) {
                        amount.setError(getString(R.string.Negative_Amount));
                        amount.requestFocus();
                        return;
                    }
                    long accountnum = Long.parseLong(account.getText().toString().trim());
                    float withdrawalamount = Float.parseFloat(amount.getText().toString().trim());
                    boolean verify = actions.VerifyAccount(accountnum);
                    if (!verify) {
                        onCreateDialog(getString(R.string.error), getString(R.string.Account_is_not_exist));
                        account.requestFocus();
                        return;
                    } else {
                        boolean balanceIsOk = actions.verifyBalance(accountnum, withdrawalamount);
                        if (!balanceIsOk) {
                            onCreateDialog(getString(R.string.error), getString(R.string.Balance_is_not_enough));
                            amount.requestFocus();
                            return;
                        } else {
                            boolean result = actions.withDrawAmount(accountnum, withdrawalamount);
                            if (result) {
                                onCreateDialog1(getString(R.string.Info), getString(R.string.Amount_Withdrawn_Successfully));
                                Clear();
                            } else {
                                onCreateDialog(getString(R.string.error), getString(R.string.erro_message));
                            }
                        }

                    }
                }
                catch (Exception e){
                    Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                }

            }
        });
        return v;
    }
    public Dialog onCreateDialog(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_error_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentManager manager = getFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().commit();
            }
        });
        builder.create();
        return builder.show();
    }
    void Clear(){
        account.setText("");
        amount.setText("");
    }
}
