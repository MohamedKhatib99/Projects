package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

public class UserTransferFragment extends Fragment {
    EditText senderaccount,receiveraccount,amount;
    Button transfer;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource customerDataSource;
    private Actions actions;
    Bundle bundle;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_transfer,container,false);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        actions = new Actions(helper);
        customerDataSource = new CustomerDataSource(helper);
        senderaccount = v.findViewById(R.id.ett_sender);
        receiveraccount = v.findViewById(R.id.ett_receiver);
        amount = v.findViewById(R.id.ett_amount);
        transfer = v.findViewById(R.id.btn_transfer);
        bundle = getArguments();
        if(bundle != null){
            int ID = bundle.getInt("ID");
            Customer customer = customerDataSource.getCustomerDataByID(ID);
            senderaccount.setText(customer.getAccountNumber()+"");
            senderaccount.setEnabled(false);
        }
        transfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (senderaccount.getText().toString().trim().isEmpty() && receiveraccount.getText().toString().trim().isEmpty() && amount.getText().toString().trim().isEmpty()) {
                        senderaccount.setError(getString(R.string.enter_sender_account_number));
                        receiveraccount.setError(getString(R.string.enter_receiver_account_number));
                        amount.setError(getString(R.string.enter_transfer_amount));
                        senderaccount.requestFocus();
                        return;
                    }
                    if (senderaccount.getText().toString().trim().isEmpty()) {
                        senderaccount.setError(getString(R.string.enter_sender_account_number));
                        senderaccount.requestFocus();
                        return;
                    }
                    if (senderaccount.getText().toString().trim().length() < 10) {
                        senderaccount.setError(getString(R.string.Invalid_Sender_Account));
                        senderaccount.requestFocus();
                        return;
                    }
                    if (receiveraccount.getText().toString().trim().isEmpty()) {
                        receiveraccount.setError(getString(R.string.enter_receiver_account_number));
                        receiveraccount.requestFocus();
                        return;
                    }
                    if (receiveraccount.getText().toString().trim().length() < 10) {
                        receiveraccount.setError(getString(R.string.Invalid_Receiever_Account));
                        receiveraccount.requestFocus();
                        return;
                    }
                    if (amount.getText().toString().trim().isEmpty()) {
                        amount.setError(getString(R.string.enter_transfer_amount));
                        amount.requestFocus();
                        return;
                    }
                    if (Float.parseFloat(amount.getText().toString().trim()) < 0) {
                        amount.setError(getString(R.string.Negative_Transfer_Amount));
                        amount.requestFocus();
                        return;
                    }
                    long senderaccountnum = Long.parseLong(senderaccount.getText().toString().trim());
                    long receiveraccountnum = Long.parseLong(receiveraccount.getText().toString().trim());
                    float transferamount = Float.parseFloat(amount.getText().toString().trim());
                    boolean verify = actions.VerifyAccount(senderaccountnum);
                    boolean verify1 = actions.VerifyAccount(receiveraccountnum);
                    if (!verify || !verify1) {
                        onCreateDialog(getString(R.string.error), getString(R.string.Sender_Or_Recevier_Not_Exist));
                        senderaccount.requestFocus();
                        return;
                    } else {
                        boolean balanceIsOk = actions.verifyBalance(senderaccountnum, transferamount);
                        if (!balanceIsOk) {
                            onCreateDialog(getString(R.string.error), getString(R.string.Balance_is_not_enough_to_transfer));
                            amount.requestFocus();
                            return;
                        }
                        if (senderaccountnum == receiveraccountnum) {
                            onCreateDialog(getString(R.string.error), getString(R.string.You_can_not_transfer_to_yourself));
                            receiveraccount.requestFocus();

                        } else {
                            boolean result = actions.transferAmount(senderaccountnum, receiveraccountnum, transferamount);
                            if (result) {
                                onCreateDialog1(getString(R.string.Info), getString(R.string.Amount_Transferred_Successfully));
                                Clear();
                            } else {
                                onCreateDialog(getString(R.string.error), getString(R.string.erro_message));
                            }
                        }

                    }
                }
                catch (Exception e){
                    Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                }


            }
        });
        return  v;
    }
    public Dialog onCreateDialog(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_error_black_24dp);
        builder.setPositiveButton(getString(R.string.Ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(getString(R.string.Ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    void Clear(){
        senderaccount.setText("");
        receiveraccount.setText("");
        amount.setText("");
    }
}
