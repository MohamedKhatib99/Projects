package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class AddCurrencyFragment extends Fragment {
    EditText currencyname,currencyunit,currencysell,currencybuy;
    Button btnSaveCurrency;
    private MySQLiteOpenHelper helper;
    private CurrencyDataSource cds;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_addcurrency,container,false);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        cds = new CurrencyDataSource(helper);

        btnSaveCurrency = v.findViewById(R.id.btn_savecurrency);
        currencyname = v.findViewById(R.id.et_currencyname);
        currencyunit = v.findViewById(R.id.et_currencyunit);
        currencysell = v.findViewById(R.id.et_sellrate);
        currencybuy = v.findViewById(R.id.et_buyrate);
        btnSaveCurrency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String CurrencyName = currencyname.getText().toString().trim();
                    String CurrencyUnit = currencyunit.getText().toString().trim();
                    String SellRate = currencysell.getText().toString().trim();
                    String BuyRate = currencybuy.getText().toString().trim();
                    if (CurrencyName.isEmpty() && CurrencyUnit.isEmpty() && SellRate.isEmpty() && BuyRate.isEmpty()) {
                        currencyname.setError(getString(R.string.Enter_Currency_Name));
                        currencyunit.setError(getString(R.string.Currency_Unit));
                        currencysell.setError(getString(R.string.Currency_Sell));
                        currencybuy.setError(getString(R.string.Currency_Buy));
                        currencyname.requestFocus();
                        return;
                    }
                    if (CurrencyName.isEmpty()) {
                        currencyname.setError(getString(R.string.Enter_Currency_Name));
                        currencyname.requestFocus();
                        return;
                    }
                    if (CurrencyUnit.isEmpty()) {
                        currencyunit.setError(getString(R.string.Currency_Unit));
                        currencyunit.requestFocus();
                        return;
                    }
                    if (SellRate.isEmpty()) {
                        currencysell.setError(getString(R.string.Currency_Sell));
                        currencysell.requestFocus();

                    }
                    if (Float.parseFloat(currencysell.getText().toString().trim()) < 0) {
                        currencysell.setError(getString(R.string.Negative_Sell));
                        currencysell.requestFocus();
                        return;
                    }
                    if (BuyRate.isEmpty()) {
                        currencybuy.setError(getString(R.string.Currency_Buy));
                        currencybuy.requestFocus();
                        return;
                    }
                    if (Float.parseFloat(currencybuy.getText().toString().trim()) < 0) {
                        currencybuy.setError(getString(R.string.Negative_Buy));
                        currencybuy.requestFocus();
                        return;
                    }
                    Currency ca = new Currency(CurrencyName, CurrencyUnit, SellRate, BuyRate);
                    boolean verify = cds.verifyCurrency(CurrencyName, CurrencyUnit);
                    if (verify) {
                        onCreateDialog(getString(R.string.error), getString(R.string.Currency_Exist));
                        currencyname.requestFocus();
                        return;
                    } else {
                        boolean result = cds.addNewCurrency(ca);
                        if (result) {
                            onCreateDialog1(getString(R.string.Info), getString(R.string.Currency_Added));
                            Clear();

                        } else {
                            onCreateDialog(getString(R.string.error), getString(R.string.erro_message));
                        }
                    }
                }
                catch (Exception e){
                    Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                }

            }
        });


        return v;
    }
    public Dialog onCreateDialog(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_error_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentManager manager = getFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().commit();
            }
        });
        builder.create();
        return builder.show();
    }
    void Clear(){
        currencyname.setText("");
        currencyunit.setText("");
        currencysell.setText("");
        currencybuy.setText("");
    }
}
