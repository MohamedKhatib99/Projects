package com.example.mobilebankingapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class CurrencyAdapter extends ArrayAdapter {
    private List<Currency> list;
    private Context context;
    private int resId;

    public CurrencyAdapter(@NonNull Context context, int resource, @NonNull List list) {
        super(context, resource, list);
        this.list = list;
        this.context = context;
        this.resId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(resId, parent, false);
        TextView id = convertView.findViewById(R.id.tvc_ID);
        TextView name = convertView.findViewById(R.id.tvc_Name);
        TextView unit = convertView.findViewById(R.id.tvc_Unit);
        TextView sell = convertView.findViewById(R.id.tvc_Sell);
        TextView buy = convertView.findViewById(R.id.tvc_Buy);
        id.setText(list.get(position).getCurrencyID() +"");
        name.setText(list.get(position).getCurrencyName()+"");
        unit.setText(list.get(position).getCurrencyUnit()+"");
        sell.setText(list.get(position).getSellRate()+"TL");
        buy.setText(list.get(position).getBuyRate()+"TL");
        return convertView;
    }

    @Override
    public int getCount() {
        return list.size();
    }

}

