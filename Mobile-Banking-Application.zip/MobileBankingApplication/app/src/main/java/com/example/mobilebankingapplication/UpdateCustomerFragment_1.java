package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class UpdateCustomerFragment_1 extends Fragment {
    EditText phone,postcode,country,city,address;
    private Button next;
    private Bundle bundle;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_update_customer_1,container,false);
         next = v.findViewById(R.id.btnca_next1);
         phone = v.findViewById(R.id.etca_phonenumber);
         postcode = v.findViewById(R.id.etca_postcode);
         country = v.findViewById(R.id.etca_country);
         city = v.findViewById(R.id.etca_city);
         address = v.findViewById(R.id.etca_address);
         bundle = getArguments();
         LoadCustomerDate();
         next.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 try {
                     String PHONE = phone.getText().toString().trim();
                     String POSTCODE = postcode.getText().toString().trim();
                     String COUNTRY = country.getText().toString().trim();
                     String CITY = city.getText().toString().trim();
                     String ADDRESS = address.getText().toString().trim();
                     if (phone.getText().toString().trim().isEmpty() && postcode.getText().toString().trim().isEmpty() && country.getText().toString().isEmpty() && city.getText().toString().trim().isEmpty() && address.getText().toString().trim().isEmpty()) {
                         phone.setError(getString(R.string.Enter_Phone));
                         postcode.setError(getString(R.string.Enter_Postcode));
                         country.setError(getString(R.string.Enter_Country));
                         city.setError(getString(R.string.Enter_City));
                         address.setError(getString(R.string.Enter_Address));
                         phone.requestFocus();
                         return;
                     }
                     if (PHONE.isEmpty()) {
                         phone.setError(getString(R.string.Enter_Phone));
                         phone.requestFocus();
                         return;
                     }
                     if (PHONE.length() < 10) {
                         phone.setError(getString(R.string.Invalid_phonenumber));
                         phone.requestFocus();
                         return;
                     }
                     if (POSTCODE.isEmpty()) {
                         postcode.setError(getString(R.string.Enter_Postcode));
                         postcode.requestFocus();
                         return;
                     }
                     if (POSTCODE.length() < 5) {
                         postcode.setError(getString(R.string.Invalid_Postcode));
                         postcode.requestFocus();
                         return;
                     }
                     if (COUNTRY.isEmpty()) {
                         country.setError(getString(R.string.Enter_Country));
                         country.requestFocus();
                         return;
                     }

                     if (CITY.isEmpty()) {
                         city.setError(getString(R.string.Enter_City));
                         city.requestFocus();
                         return;
                     }
                     if (ADDRESS.isEmpty()) {
                         address.setError(getString(R.string.Enter_Address));
                         address.requestFocus();
                         return;
                     }
                     bundle.putString("PHONE", PHONE);
                     bundle.putString("POSTCODE", POSTCODE);
                     bundle.putString("COUNTRY", COUNTRY);
                     bundle.putString("CITY", CITY);
                     bundle.putString("ADDRESS", ADDRESS);
                     FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                     UpdateCustomerFragment_2 updateCustomerFragment_2 = new UpdateCustomerFragment_2();
                     updateCustomerFragment_2.setArguments(bundle);
                     fragmentTransaction.replace(R.id.fragment_container, updateCustomerFragment_2);
                     fragmentTransaction.addToBackStack(null);
                     fragmentTransaction.commit();
                 }
                 catch (Exception e){
                     Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                 }
             }
         });

        return v;

    }
    public void LoadCustomerDate(){
        phone.setText(bundle.getString("PHONE"));
        postcode.setText(bundle.getString("POSTCODE"));
        country.setText(bundle.getString("COUNTRY"));
        city.setText(bundle.getString("CITY"));
        address.setText(bundle.getString("ADDRESS"));
    }
}
