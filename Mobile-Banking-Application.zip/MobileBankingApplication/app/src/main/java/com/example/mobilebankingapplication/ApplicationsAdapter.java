package com.example.mobilebankingapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class ApplicationsAdapter extends ArrayAdapter {
    private List<Customer> list;
    private Context context;
    private int resId;

    public ApplicationsAdapter(@NonNull Context context, int resource, @NonNull List list) {
        super(context, resource, list);
        this.list = list;
        this.context = context;
        this.resId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(resId, parent, false);
        TextView id = convertView.findViewById(R.id.tva_id);
        TextView tc = convertView.findViewById(R.id.tva_tc);
        TextView fullname = convertView.findViewById(R.id.tva_fullname);
        TextView birth = convertView.findViewById(R.id.tva_birth);
        TextView phone = convertView.findViewById(R.id.tva_phone);
        TextView email = convertView.findViewById(R.id.tva_email);
        id.setText(list.get(position).get_id() +"");
        tc.setText(Long.toString(list.get(position).getTC()));
        fullname.setText(list.get(position).getFullName()+"");
        birth.setText(list.get(position).getBirthDate()+"");
        phone.setText(Long.toString(list.get(position).getPhoneNumber()));
        email.setText(list.get(position).getEmail()+"");
        return convertView;
    }

    @Override
    public int getCount() {
        return list.size();
    }

}

