package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {
    private EditText oldpassword,newpassword,confirmpassword;
    private Button btnchangePasswor;
    private Bundle bundle;
    private String password,email;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource eds ;
    private Employee emp;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_settings,container,false);
        oldpassword = v.findViewById(R.id.et_oldpassword);
        newpassword = v.findViewById(R.id.et_newPassword);
        confirmpassword = v.findViewById(R.id.et_confirmpassword);
        btnchangePasswor = v.findViewById(R.id.btn_changepassword);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        eds = new EmployeeDataSource(helper);
        bundle = getArguments();
        if(bundle != null){
            int id = bundle.getInt("ID");
            emp = eds.getEmployeeDataByID(id);
        }
        btnchangePasswor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(oldpassword.getText().toString().trim().isEmpty() && newpassword.getText().toString().trim().isEmpty() && confirmpassword.getText().toString().trim().isEmpty()){
                        oldpassword.setError(getString(R.string.EnterOldPassword));
                        newpassword.setError(getString(R.string.EnterNewPassword));
                        confirmpassword.setError(getString(R.string.ConfirmPassword));
                        oldpassword.requestFocus();
                        return;
                    }
                    if(oldpassword.getText().toString().trim().isEmpty()){
                        oldpassword.setError(getString(R.string.EnterOldPassword));
                        oldpassword.requestFocus();
                        return;
                    }
                    if(oldpassword.getText().toString().trim().length() < 8){
                        oldpassword.setError(getString(R.string.Password_Must_Be));
                        oldpassword.requestFocus();
                        return;
                    }
                    if(newpassword.getText().toString().trim().isEmpty()){
                        newpassword.setError(getString(R.string.EnterNewPassword));
                        newpassword.requestFocus();
                        return;
                    }
                    if(newpassword.getText().toString().trim().length() < 8){
                        newpassword.setError(getString(R.string.Password_Must_Be));
                        newpassword.requestFocus();
                        return;
                    }
                    if(confirmpassword.getText().toString().trim().isEmpty()){
                        confirmpassword.setError(getString(R.string.ConfirmPassword));
                        confirmpassword.requestFocus();
                        return;

                    }
                    if(confirmpassword.getText().toString().trim().length() < 8){
                        confirmpassword.setError(getString(R.string.Password_Must_Be));
                        confirmpassword.requestFocus();
                        return;

                    }
                    if(!newpassword.getText().toString().trim().equals(confirmpassword.getText().toString().trim())){
                        confirmpassword.setError(getString(R.string.PasswordsNotMach));
                        confirmpassword.requestFocus();
                        return;

                    }
                    if(!oldpassword.getText().toString().trim().equals(emp.get_Password())){
                        oldpassword.setError(getString(R.string.Inccorectoldpassword));
                        oldpassword.requestFocus();
                        return;
                    }
                    emp.set_Password(newpassword.getText().toString().trim());
                    boolean res = eds.updateEmployeeDate(emp,emp.get_EmployeeID());
                    if(res){
                        onCreateDialog1(getString(R.string.Info), getString(R.string.passwordchangedsuccesfully));
                        Clear();
                    }
                    else {
                        onCreateDialog(getString(R.string.error), getString(R.string.erro_message));

                    }





                }
                catch (Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        return v;
    }
    public Dialog onCreateDialog(String title , String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_error_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }

    public Dialog onCreateDialog1(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    void Clear(){
        oldpassword.setText("");
        newpassword.setText("");
        confirmpassword.setText("");
    }
}
