package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class UpdateEmployeeFragment extends Fragment {
    private EditText tc,fullname,age,email,password,salary;
    private String phone,postcode,country,city,address;
    private int id;
    private RadioButton rbmale,rbfemale;
    private TextView error;
    private RadioGroup rg;
    private Button btnNext;
    private String gender;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource eds;
    private Bundle bundle;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_update_employee,container,false);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        eds = new EmployeeDataSource(helper);
        btnNext = v.findViewById(R.id.btneu_next);
        tc = v.findViewById(R.id.eteu_TC);
        fullname = v.findViewById(R.id.eteu_FullName);
        age = v.findViewById(R.id.eteu_BirthDate);
        email = v.findViewById(R.id.eteu_Email);
        password = v.findViewById(R.id.eteu_Password);
        salary = v.findViewById(R.id.eteu_Salary);
        rg = v.findViewById(R.id.radioGroup);
        rbmale = v.findViewById(R.id.rbeu_Male);
        rbfemale = v.findViewById(R.id.rbeu_Female);
        error = v.findViewById(R.id.eteu_error);
        LoadEmployeeDate();
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String Tc = tc.getText().toString();
                    String FULLNAME = fullname.getText().toString();
                    String AGE = age.getText().toString();
                    gender();
                    String GENDER = gender;
                    String EMAIL = email.getText().toString();
                    String PASSWORD = password.getText().toString();
                    String SALARY = salary.getText().toString().trim();
                    if (Tc.isEmpty() && FULLNAME.isEmpty() && AGE.isEmpty() && !rbmale.isChecked() && !rbfemale.isChecked() && EMAIL.isEmpty() && PASSWORD.isEmpty() && SALARY.isEmpty()) {
                        tc.setError(getString(R.string.Enter_TC));
                        fullname.setError(getString(R.string.enter_FullName));
                        age.setError(getString(R.string.enter_Birth_Date));
                        error.setError(getString(R.string.Select_Gender));
                        email.setError(getString(R.string.Enter_email));
                        password.setError(getString(R.string.Enter_Password));
                        salary.setError(getString(R.string.Enter_Salary));
                        tc.requestFocus();
                        return;
                    }
                    if (Tc.isEmpty()) {
                        tc.setError(getString(R.string.Enter_TC));
                        tc.requestFocus();
                        return;
                    }
                    if (FULLNAME.isEmpty()) {
                        fullname.setError(getString(R.string.enter_FullName));
                        fullname.requestFocus();
                        return;
                    }
                    if (AGE.isEmpty()) {
                        age.setError(getString(R.string.enter_Birth_Date));
                        age.requestFocus();
                        return;
                    }
                    if (!rbmale.isChecked() && !rbfemale.isChecked()) {
                        error.setError(getString(R.string.Select_Gender));
                        error.requestFocus();
                        return;
                    }
                    if (EMAIL.isEmpty()) {
                        email.setError(getString(R.string.Enter_email));
                        email.requestFocus();
                        return;
                    }
                    if (!EMAIL.contains("@") || !EMAIL.endsWith("com")) {
                        email.setError(getString(R.string.invalid_email));
                        email.requestFocus();
                        return;
                    }
                    if (PASSWORD.isEmpty()) {
                        password.setError(getString(R.string.Enter_Password));
                        password.requestFocus();
                        return;
                    }
                    if (password.getText().toString().trim().length() < 8) {
                        password.setError(getString(R.string.Password_Must_Be));
                        password.requestFocus();
                        return;
                    }
                    if (SALARY.isEmpty()) {
                        salary.setError(getString(R.string.Enter_Salary));
                        salary.requestFocus();
                        return;
                    }

                    bundle.putInt("ID", id);
                    bundle.putString("TC", Tc);
                    bundle.putString("FULLNAME", FULLNAME);
                    bundle.putString("AGE", AGE);
                    bundle.putString("GENDER", GENDER);
                    bundle.putString("EMAIL", EMAIL);
                    bundle.putString("PASSWORD", PASSWORD);
                    bundle.putString("SALARY", SALARY);
                    bundle.putString("PHONE", phone);
                    bundle.putString("POSTCODE", postcode);
                    bundle.putString("COUNTRY", country);
                    bundle.putString("CITY", city);
                    bundle.putString("ADDRESS", address);


                    FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                    UpdateEmployeeFragment_1 updateEmployeeFragment_1 = new UpdateEmployeeFragment_1();
                    updateEmployeeFragment_1.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, updateEmployeeFragment_1);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
                catch (Exception e){
                    Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });

        return v;
    }
    public String gender(){
        if(rbmale.isChecked())
        {
            gender = rbmale.getText().toString();
        }
        else if(rbfemale.isChecked())
        {
            gender = rbfemale.getText().toString();
        }
        else{
            return null;
        }
        return gender;
    }
    public void LoadEmployeeDate(){
        try {
            bundle = getArguments();
            if (!bundle.isEmpty()) {
                id = bundle.getInt("ID");
                Employee emp = eds.getEmployeeDataByID(id);
                tc.setText(Long.toString(emp.get_TC()));
                fullname.setText(emp.get_FullName());
                age.setText(emp.get_BirthDate());
                email.setText(emp.get_Email());
                password.setText(emp.get_Password());
                salary.setText(Float.toString(emp.get_Salary()));
                phone = Long.toString(emp.get_PhoneNumber());
                postcode = Integer.toString(emp.get_PostCode());
                country = emp.get_Country();
                city = emp.get_City();
                address = emp.get_Address();
                if (emp.get_Gender().toUpperCase().equals("MALE") ||emp.get_Gender().toUpperCase().equals("ERKEK")) {
                    rbmale.setChecked(true);
                } else {
                    rbfemale.setChecked(true);
                }

            }
        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}
