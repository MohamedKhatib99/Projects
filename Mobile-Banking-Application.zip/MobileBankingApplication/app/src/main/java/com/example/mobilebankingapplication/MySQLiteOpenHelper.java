package com.example.mobilebankingapplication;

        import android.content.Context;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;

        import androidx.annotation.Nullable;

public class MySQLiteOpenHelper extends SQLiteOpenHelper {
    public MySQLiteOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = " CREATE TABLE ApplicationsTable( _id integer NOT NULL PRIMARY KEY AUTOINCREMENT," +
                " TC integer NOT NULL, FullName TEXT NOT NULL, " +
                "BirthDate TEXT NOT NULL, PhoneNumber integer NOT NULL," +
                " Email TEXT NOT NULL);";
        String query1 = "CREATE TABLE CustomersTable(CustomerID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                " TC INTEGER NOT NULL, FullName TEXT NOT NULL," +
                "FatherName TEXT NOT NULL, MotherName TEXT NOT NULL," +
                " BirthDate TEXT NOT NULL,Gender TEXT NOT NULL, Email TEXT NOT NULL, Password TEXT NOT NULL,AccessType INTEGER NOT NULL);";
        String query2 = " CREATE TABLE CustomersContactInfoTable(CustomerID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "PhoneNumber INTEGER NOT NULL,PostCode INTEGER NOT NULL, Country TEXT NOT NULL, " +
                "City TEXT NOT NULL," +
                " Address TEXT NOT NULL);";
        String query3 = " CREATE TABLE AccountsTable(CustomerID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "AccountNumber INTEGER NOT NULL,AccountType TEXT NOT NULL, AccountName TEXT NOT NULL, " +
                "Balance INTEGER NOT NULL," +
                " Description TEXT NOT NULL);";
        String query4 = "CREATE TABLE EmployeeInfo(EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "TC INTEGER NOT NULL,FullName TEXT NOT NULL,BirthDate TEXT NOT NULL,Gender TEXT NOT NULL," +
                "Email TEXT NOT NULL,Password TEXT NOT NULL," +
                "Salary INTEGER NOT NULL,AccessType INTEGER NOT NULL);";
        String query5 = " CREATE TABLE EmployeeContactInfo(EmployeeID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "PhoneNumber INTEGER NOT NULL,PostCode INTEGER NOT NULL, Country TEXT NOT NULL, " +
                "City TEXT NOT NULL," +
                " Address TEXT NOT NULL);";
        String query6 ="CREATE TABLE CurrencyInfo(CurrencyID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "Currency_Name TEXT NOT NULL,"+
                "Currency_Unit	TEXT NOT NULL," +
                "Sell_Rate TEXT NOT NULL,"+
                "Buy_Rate TEXT NOT NULL );";
        db.execSQL(query);
        db.execSQL(query1);
        db.execSQL(query2);
        db.execSQL(query3);
        db.execSQL(query4);
        db.execSQL(query5);
        db.execSQL(query6);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
