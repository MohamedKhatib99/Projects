package com.example.mobilebankingapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Actions {
    private MySQLiteOpenHelper helper;
    private SQLiteDatabase db;

    public Actions(MySQLiteOpenHelper helper) {
        this.helper = helper;
        db = helper.getWritableDatabase();
    }
    public boolean withDrawAmount(long accountnumber,float amount){
        db.execSQL("UPDATE AccountsTable set Balance = Balance - ? where AccountNumber = ?",new String[]{amount+"",accountnumber+""});
        return  true;
    }
    public boolean depositDrawAmount(long accountnumber,float amount){
        db.execSQL("UPDATE AccountsTable set Balance = Balance + ? where AccountNumber = ?",new String[]{amount+"",accountnumber+""});
        return true;

    }
    public boolean transferAmount(long senderaccountnumber,long receiveraccountnumber,float amount){
        db.execSQL("UPDATE AccountsTable set Balance = Balance - ? where AccountNumber = ?",new String[]{amount+"",senderaccountnumber+""});
        db.execSQL("UPDATE AccountsTable set Balance = Balance + ? where AccountNumber = ?",new String[]{amount+"",receiveraccountnumber+""});
        return  true;

    }
    public boolean VerifyAccount(long accountnumber){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM AccountsTable WHERE AccountNumber = "+accountnumber,null);
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean verifyBalance(long accountnumber , float amount){

        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT Balance FROM AccountsTable WHERE AccountNumber = ? AND Balance >= ?",new String[]{accountnumber+"",amount+""});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;

    }
}
