package com.example.mobilebankingapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class AddEmployeeFragment extends Fragment {
    EditText tc,fullname,age,email,password,salary;
    RadioButton rbmale,rbfemale;
    TextView error;
    RadioGroup rg;
    Button btnNext;
    String gender;
    MySQLiteOpenHelper helper;
    EmployeeDataSource eds;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_addemployee,container,false);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        eds = new EmployeeDataSource(helper);
        btnNext = v.findViewById(R.id.btne_next);
        tc = v.findViewById(R.id.ete_TC);
        fullname = v.findViewById(R.id.ete_fullname);
        age = v.findViewById(R.id.ete_birthdate);
        email = v.findViewById(R.id.ete_email);
        password = v.findViewById(R.id.ete_password);
        salary = v.findViewById(R.id.ete_salary);
        rg = v.findViewById(R.id.rg_gender1);
        rbmale = v.findViewById(R.id.rb_male1);
        rbfemale = v.findViewById(R.id.rb_female1);
        error = v.findViewById(R.id.eterror);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View v) {
                try {
                    String Tc = tc.getText().toString();
                    String FULLNAME = fullname.getText().toString();
                    String AGE = age.getText().toString();
                    gender();
                    String GENDER = gender;
                    String EMAIL = email.getText().toString();
                    String PASSWORD = password.getText().toString();
                    String SALARY = salary.getText().toString().trim();
                    if (Tc.isEmpty() && FULLNAME.isEmpty() && AGE.isEmpty() && !rbmale.isChecked() && !rbfemale.isChecked() && EMAIL.isEmpty() && PASSWORD.isEmpty() && SALARY.isEmpty()) {
                        tc.setError(getString(R.string.Enter_TC));
                        fullname.setError(getString(R.string.enter_FullName));
                        age.setError(getString(R.string.enter_Birth_Date));
                        error.setError(getString(R.string.Select_Gender));
                        email.setError(getString(R.string.Enter_Email));
                        password.setError(getString(R.string.Enter_Password));
                        salary.setError(getString(R.string.Enter_Salary));
                        tc.requestFocus();
                        return;
                    }
                    if (Tc.isEmpty()) {
                        tc.setError(getString(R.string.Enter_TC));
                        tc.requestFocus();
                        return;
                    }
                    if (FULLNAME.isEmpty()) {
                        fullname.setError(getString(R.string.enter_FullName));
                        fullname.requestFocus();
                        return;
                    }
                    if (AGE.isEmpty()) {
                        age.setError(getString(R.string.enter_Birth_Date));
                        age.requestFocus();
                        return;
                    }
                    if (!rbmale.isChecked() && !rbfemale.isChecked()) {
                        error.setError(getString(R.string.Select_Gender));
                        error.requestFocus();
                        return;
                    }
                    if (EMAIL.isEmpty()) {
                        email.setError(getString(R.string.Enter_Email));
                        email.requestFocus();
                        return;
                    }
                    if (!EMAIL.contains("@") || !EMAIL.endsWith("com")) {
                        email.setError(getString(R.string.invalid_email));
                        email.requestFocus();
                        return;
                    }
                    if (PASSWORD.isEmpty()) {
                        password.setError(getString(R.string.Enter_Password));
                        password.requestFocus();
                        return;
                    }
                    if (password.getText().toString().trim().length() < 8) {
                        password.setError(getString(R.string.Password_Must_Be));
                        password.requestFocus();
                        return;
                    }
                    if (SALARY.isEmpty()) {
                        salary.setError(getString(R.string.Enter_Salary));
                        salary.requestFocus();
                        return;
                    }
                    Bundle bundle = new Bundle();
                    bundle.putString("TC", Tc);
                    bundle.putString("FULLNAME", FULLNAME);
                    bundle.putString("AGE", AGE);
                    bundle.putString("GENDER", GENDER);
                    bundle.putString("EMAIL", EMAIL);
                    bundle.putString("PASSWORD", PASSWORD);
                    bundle.putString("SALARY", SALARY);


                    FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                    AddEmployeeFragment_1 addEmployeeFragment_1 = new AddEmployeeFragment_1();
                    addEmployeeFragment_1.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, addEmployeeFragment_1);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
                catch (Exception e){
                    Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }

        });
        return v;
    }
    public String gender(){
        if(rbmale.isChecked())
        {
            gender = rbmale.getText().toString();
        }
        else if(rbfemale.isChecked())
        {
            gender = rbfemale.getText().toString();
        }
        else{
            return null;
        }
        return gender;
    }

}
