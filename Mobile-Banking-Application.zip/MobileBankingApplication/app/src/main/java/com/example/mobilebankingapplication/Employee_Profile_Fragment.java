package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Employee_Profile_Fragment extends Fragment {
    private TextView tc,fullname,birthdate,gender,email,salary,phone,postcode,country,city,address;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource employeeDataSource;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_employee_profile_details,container,false);
        try {
            helper = new MySQLiteOpenHelper(getActivity(), "MobilBank_DB", null, 1);
            employeeDataSource = new EmployeeDataSource(helper);
            tc = v.findViewById(R.id.tv_p_TC);
            fullname = v.findViewById(R.id.tv_p_FullName);
            birthdate = v.findViewById(R.id.tv_p_Birth_Date);
            gender = v.findViewById(R.id.tv_p_Gender);
            email = v.findViewById(R.id.tv_p_Email);
            salary = v.findViewById(R.id.tv_p_Salary);
            phone = v.findViewById(R.id.tv_p_Phone_Number);
            postcode = v.findViewById(R.id.tv_p_Post_Code);
            country = v.findViewById(R.id.tv_p_Country);
            city = v.findViewById(R.id.tv_p_City);
            address = v.findViewById(R.id.tv_p_Address);

        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
        LoadProfileData();
        return v;
    }
    void LoadProfileData(){
        try {
            Bundle bundle = getArguments();
            int ID = bundle.getInt("ID");
            Employee employee = employeeDataSource.getEmployeeDataByID(ID);
            tc.setText(employee.get_TC()+"");
            fullname.setText(employee.get_FullName());
            birthdate.setText(employee.get_BirthDate());
            gender.setText(employee.get_Gender());
            email.setText(employee.get_Email());
            salary.setText(employee.get_Salary()+"TL");
            phone.setText(employee.get_PhoneNumber()+"");
            postcode.setText(employee.get_PostCode()+"");
            country.setText(employee.get_Country()+"");
            city.setText(employee.get_City()+"");
            address.setText(employee.get_Address()+"");
        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}
