package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class UpdateCurrencyFragment extends Fragment {
    EditText currencyname,currencyunit,currencysell,currencybuy;
    Button btnUpdateCurrency;
    private MySQLiteOpenHelper helper;
    private CurrencyDataSource cds;
    private Bundle bundle;
    int id;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_update_currency,container,false);
        helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
        cds = new CurrencyDataSource(helper);
        btnUpdateCurrency = v.findViewById(R.id.btn_updatecurrency);
        currencyname = v.findViewById(R.id.etc_currencyname);
        currencyunit = v.findViewById(R.id.etc_currencyunit);
        currencysell = v.findViewById(R.id.etc_sellrate);
        currencybuy = v.findViewById(R.id.etc_buyrate);
        btnUpdateCurrency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String CurrencyName = currencyname.getText().toString().trim();
                    String CurrencyUnit = currencyunit.getText().toString().trim();
                    String SellRate = currencysell.getText().toString().trim();
                    String BuyRate = currencybuy.getText().toString().trim();
                    if (CurrencyName.isEmpty() && CurrencyUnit.isEmpty() && SellRate.isEmpty() && BuyRate.isEmpty()) {
                        currencyname.setError(getString(R.string.Enter_Currency_Name));
                        currencyunit.setError(getString(R.string.Currency_Unit));
                        currencysell.setError(getString(R.string.Currency_Sell));
                        currencybuy.setError(getString(R.string.Currency_Buy));
                        currencyname.requestFocus();
                        return;
                    }
                    if (CurrencyName.isEmpty()) {
                        currencyname.setError(getString(R.string.Enter_Currency_Name));
                        currencyname.requestFocus();
                        return;
                    }
                    if (CurrencyUnit.isEmpty()) {
                        currencyunit.setError(getString(R.string.Currency_Unit));
                        currencyunit.requestFocus();
                        return;
                    }
                    if (SellRate.isEmpty()) {
                        currencysell.setError(getString(R.string.Currency_Sell));
                        currencysell.requestFocus();

                    }
                    if (Float.parseFloat(currencysell.getText().toString().trim()) < 0) {
                        currencysell.setError(getString(R.string.Negative_Sell));
                        currencysell.requestFocus();
                        return;
                    }
                    if (BuyRate.isEmpty()) {
                        currencybuy.setError(getString(R.string.Currency_Buy));
                        currencybuy.requestFocus();
                        return;
                    }
                    if (Float.parseFloat(currencybuy.getText().toString().trim()) < 0) {
                        currencybuy.setError(getString(R.string.Negative_Buy));
                        currencybuy.requestFocus();
                        return;
                    }
                    Currency ca = new Currency(CurrencyName, CurrencyUnit, SellRate, BuyRate);
                    boolean verify = cds.verifyCurrency(CurrencyName, CurrencyUnit,id);
                    if (verify) {
                        onCreateDialog(getString(R.string.error), getString(R.string.Currency_Exist));
                        currencyname.requestFocus();
                        return;
                    } else {
                        boolean result = cds.updateCurrency(ca, id);
                        if (result) {
                            onCreateDialog1(getString(R.string.Info), getString(R.string.Updated_Successfully));
                            Clear();

                        } else {
                            onCreateDialog(getString(R.string.error), getString(R.string.erro_message));
                        }
                    }
                }
                catch (Exception e){
                    Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                }

            }
        });

        LoadCurrencyDate();
        return v;
    }
    public Dialog onCreateDialog(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_error_black_24dp);
        builder.setPositiveButton(getString(R.string.Ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String title ,String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(getString(R.string.Ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentManager manager = getFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().commit();
            }
        });
        builder.create();
        return builder.show();
    }

    void LoadCurrencyDate(){
        bundle = getArguments();
        id = bundle.getInt("ID");
        Currency car = cds.getCurrencyById(id);
        currencyname.setText(car.getCurrencyName());
        currencyunit.setText(car.getCurrencyUnit());
        currencysell.setText(car.getSellRate());
        currencybuy.setText(car.getBuyRate());
    }

    void Clear(){
        currencyname.setText("");
        currencyunit.setText("");
        currencysell.setText("");
        currencybuy.setText("");
    }
}
