package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btnapplynow,btnsignin,btnthenearestbranch;
    private EditText email,password;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource eds;
    private CustomerDataSource cds;
    private Switch sw;
    private String My_Preferences= "com.example.mobilebankingapplication.preferences";
    private TextView tvpass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helper = new MySQLiteOpenHelper(this,"MobilBank_DB",null,1);
        eds = new EmployeeDataSource(helper);
        cds = new CustomerDataSource(helper);
        email = (EditText) findViewById(R.id.etemail);
        password = (EditText) findViewById(R.id.etpassword);
        btnapplynow = findViewById(R.id.btnApplyNow);
        btnsignin = findViewById(R.id.btnsignin);
        sw = findViewById(R.id.s_rememberme);
        tvpass = findViewById(R.id.tv_forget);
        tvpass.setPaintFlags(tvpass.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        btnthenearestbranch = findViewById(R.id.btnthenearestbranch);
        SharedPreferences preferences = getSharedPreferences(My_Preferences,MODE_PRIVATE);
        String Email = preferences.getString("email","");
        String Password = preferences.getString("password","");
        boolean sw1 = preferences.getBoolean("switch",false);
        email.setText(Email);
        password.setText(Password);
        if(sw1){

            sw.setChecked(true);
        }
        btnthenearestbranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Branchs_Locations.class);
                startActivity(intent);
            }
        });
        btnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (email.getText().toString().trim().isEmpty() && password.getText().toString().trim().isEmpty()) {
                        email.setError(getString(R.string.Enter_email));
                        password.setError(getString(R.string.Enter_Password));
                        email.requestFocus();
                        return;
                    }
                    if (email.getText().toString().trim().isEmpty()) {
                        email.setError(getString(R.string.Enter_email));
                        email.requestFocus();

                        return;
                    }
                    if (!email.getText().toString().contains("@") || !email.getText().toString().endsWith(".com")) {
                        email.setError(getString(R.string.invalid_email));
                        email.requestFocus();
                        return;
                    }

                    if (password.getText().toString().isEmpty()) {
                        password.setError(getString(R.string.Enter_Password));
                        password.requestFocus();

                        return;
                    }
                    if (password.getText().toString().trim().length() < 8) {
                        password.setError(getString(R.string.Password_Must_Be));
                        password.requestFocus();
                        return;
                    }

                    boolean result = eds.Login(email.getText().toString().trim(), password.getText().toString().trim());
                    boolean result1 = cds.Login(email.getText().toString().trim(), password.getText().toString().trim());
                    if (result ) {
                        controlRemembering();
                        Intent intent = new Intent(MainActivity.this, Home.class);
                        Employee emp = eds.getEmployeeDataByEmailAndPassword(email.getText().toString().trim(),password.getText().toString().trim());
                        intent.putExtra("ID",emp.get_EmployeeID());
                        startActivity(intent);
                    }
                    else if(result1){
                        controlRemembering();
                        Intent intent = new Intent(MainActivity.this, UserHomeActivity.class);
                        Customer customer = cds.getCustomerByEmailAndPassword( email.getText().toString().trim(),password.getText().toString().trim());
                        intent.putExtra("ID",customer.get_id());
                        startActivity(intent);
                    }

                    else {
                        onCreateDialog(getString(R.string.error),getString(R.string.Check_Email_Password),getString(R.string.Ok));
                    }
                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                }



            }
        });
        btnapplynow.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent(MainActivity.this,ApplyNowActivity.class);
                 startActivity(intent);
             }
         });

    }
    void controlRemembering(){
        if (sw.isChecked()) {
            SharedPreferences.Editor editor = getSharedPreferences(My_Preferences, MODE_PRIVATE).edit();
            editor.putString("email", email.getText().toString().trim());
            editor.putString("password", password.getText().toString().trim());
            editor.putBoolean("switch", true);
            editor.commit();
        } else {
            SharedPreferences.Editor editor = getSharedPreferences(My_Preferences, MODE_PRIVATE).edit();
            editor.remove("email");
            editor.remove("password");
            editor.remove("switch");
            editor.commit();
        }
    }
    @Override
    public void onBackPressed() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.question);
        builder.setMessage(R.string.Exit);
        builder.setIcon(R.drawable.ic_help_outline_black_24dp);
        builder.setCancelable(true);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.create().show();

    }

    public Dialog onCreateDialog(String error, String Message,String btn) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(error);
        builder.setMessage(Message);
        builder.setIcon(R.drawable.ic_error_black_24dp);
        builder.setPositiveButton(btn, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            email.setText("");
            password.setText("");
            }
        });
        builder.create();
        return builder.show();
    }

    public void forget_password(View view) {
    Intent intent = new Intent(MainActivity.this ,Password_Recover_Activity.class);
        startActivity(intent);
    }
}
