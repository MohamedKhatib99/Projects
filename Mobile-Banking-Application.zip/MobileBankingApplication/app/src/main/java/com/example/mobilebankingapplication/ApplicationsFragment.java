package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ApplicationsFragment extends Fragment {
    private Button ViewApplications;
    private EditText search;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource cds;
    private View v;
    ListView list;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_applications,container,false);
        ViewApplications = v.findViewById(R.id.btnapplicationslist);
        helper = new MySQLiteOpenHelper(getContext(),"MobilBank_DB",null,1);
        cds = new CustomerDataSource(helper);
        list = (ListView) v.findViewById(R.id.applications_listview);
        search = v.findViewById(R.id.btna_search);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() == 0 ){
                    RefreshListView("");
                }
                else {
                    RefreshListView(s);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }

        });
        registerForContextMenu(list);
        RefreshListView("");
        ViewApplications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RefreshListView("");
            }
        });

        return v;
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo() ;
        if(item.getItemId() == R.id.del){
            TextView txt_id = (TextView) info.targetView.findViewById(R.id.tva_id);
            int id = Integer.parseInt(txt_id.getText().toString());
            cds.deleteApplicationById(id);
            RefreshListView("");
            return true;
        }
        return  super.onContextItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.context_menu1,menu);
    }

    private void RefreshListView(CharSequence s){

        ApplicationsAdapter adapter = new ApplicationsAdapter(getActivity(),R.layout.applications_item_layout,cds.getAllApplicationData(s));
        list.setAdapter(adapter);
    }
}
