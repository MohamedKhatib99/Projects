package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class UserProfileFragment extends Fragment {
    private TextView Email ,fullname,ID,ContactNo,Gender;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource customerDataSource;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_user_profile,container,false);
        try {
            ID = v.findViewById(R.id.tv_usCustomerId);
            Email = v.findViewById(R.id.tv_usEmail);
            fullname = v.findViewById(R.id.tv_usfullname);
            ContactNo = v.findViewById(R.id.tv_usPhonenumber);
            Gender = v.findViewById(R.id.tv_usGender);
            helper = new MySQLiteOpenHelper(getActivity(), "MobilBank_DB", null, 1);
            customerDataSource = new CustomerDataSource(helper);
            Bundle bundle = getArguments();
            int id = bundle.getInt("ID");
            Customer customer = customerDataSource.getCustomerDataByID(id);
            fullname.setText(customer.getFullName().toUpperCase());
            ID.setText(Integer.toString(customer.get_id()));
            Email.setText(customer.getEmail());
            ContactNo.setText(Long.toString(customer.getPhoneNumber()));
            if(customer.getGender().toLowerCase().equals("male") || customer.getGender().toLowerCase().equals("erkek")){
                Gender.setText(getString(R.string.male));
            }
            else {
                Gender.setText(getString(R.string.female));
            }


        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return v;
    }
}
