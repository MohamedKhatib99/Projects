package com.example.mobilebankingapplication;

public class Customer {


    private int _id;
    private long TC;
    private String FullName;
    private String FatherName;
    private String MotherName;
    private String Gender;
    private String BirthDate;
    private String Email;
    private String Password;
    private long PhoneNumber;
    private int Postcode;
    private String Country;
    private String City;
    private String Address;
    private long AccountNumber;
    private String AccountType;
    private float Balance;
    private String AccountName;
    private String Description;
    private int AccessType;



    public int getAccessType() {
        return AccessType;
    }

    public void setAccessType(int accessType) {
        AccessType = accessType;
    }

    public Customer() {

    }

    public String getFatherName() {
        return FatherName;
    }

    public void setFatherName(String fatherName) {
        FatherName = fatherName;
    }

    public String getMotherName() {
        return MotherName;
    }

    public void setMotherName(String motherName) {
        MotherName = motherName;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public int getPostcode() {
        return Postcode;
    }

    public void setPostcode(int postcode) {
        Postcode = postcode;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public long getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        AccountNumber = accountNumber;
    }

    public String getAccountType() {
        return AccountType;
    }

    public void setAccountType(String accountType) {
        AccountType = accountType;
    }

    public float getBalance() {
        return Balance;
    }

    public void setBalance(float balance) {
        Balance = balance;
    }

    public String getAccountName() {
        return AccountName;
    }

    public void setAccountName(String accountName) {
        AccountName = accountName;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }


    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public long getTC() {
        return TC;
    }

    public void setTC(long TC) {
        this.TC = TC;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getBirthDate() {
        return BirthDate;
    }

    public void setBirthDate(String birthdate) {
        BirthDate = birthdate;
    }

    public long getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public Customer(long TC, String fullName, String birthdate, long phonenumber, String email) {
        this.TC = TC;
        FullName = fullName;
        BirthDate = birthdate;
        PhoneNumber = phonenumber;
        Email = email;
    }
    public Customer(long TC, String fullName, String fatherName, String motherName, String gender, String birthdate, String email, String password, long phonenumber, int postcode, String country, String city, String address, long accountNumber, String accountType, float balance, String accountName, String description) {
        this.TC = TC;
        FullName = fullName;
        FatherName = fatherName;
        MotherName = motherName;
        Gender = gender;
        BirthDate = birthdate;
        Email = email;
        Password = password;
        PhoneNumber = phonenumber;
        Postcode = postcode;
        Country = country;
        City = city;
        Address = address;
        AccountNumber = accountNumber;
        AccountType = accountType;
        Balance = balance;
        AccountName = accountName;
        Description = description;
        AccessType = 0;
    }
    public Customer(long tc, String fullName, String fatherName, String motherName, String gender, String age, String email, String password) {
        this.TC = TC;
        FullName = fullName;
        FatherName = fatherName;
        MotherName = motherName;
        Gender = gender;
        BirthDate = age;
        Email = email;
        Password = password;
    }

}
