package com.example.mobilebankingapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class CurrencyDataSource {

    private MySQLiteOpenHelper helper;
    private SQLiteDatabase db;

    public CurrencyDataSource(MySQLiteOpenHelper helper) {
        this.helper = helper;
        db = helper.getWritableDatabase();
    }
    public boolean verifyCurrency(String currency_ame,String currency_unit){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CurrencyInfo WHERE Currency_Name = ? AND Currency_Unit = ?",new String[]{currency_ame,currency_unit});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean verifyCurrency(String currency_ame,String currency_unit,int id){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CurrencyInfo WHERE Currency_Name = ? AND Currency_Unit = ? AND CurrencyID != ?",new String[]{currency_ame,currency_unit,id+""});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean addNewCurrency(Currency ca){
        ContentValues values = new ContentValues();
        values.put("Currency_Name",ca.getCurrencyName());
        values.put("Currency_Unit",ca.getCurrencyUnit());
        values.put("Sell_Rate",ca.getSellRate());
        values.put("Buy_Rate",ca.getBuyRate());
        long id = db.insert("CurrencyInfo",null,values);
        if(id == -1)
        {return false;}
        else return true;

    }

    public boolean updateCurrency(Currency ca,int ID){
        ContentValues values = new ContentValues();
        values.put("Currency_Name",ca.getCurrencyName());
        values.put("Currency_Unit",ca.getCurrencyUnit());
        values.put("Sell_Rate",ca.getSellRate());
        values.put("Buy_Rate",ca.getBuyRate());
        long id = db.update("CurrencyInfo",values,"CurrencyID = ?",new String[]{""+ID});
        if(id == -1)
        {return false;}
        else return true;

    }
    public void deleteCurrencyById(int id ){
        db.delete("CurrencyInfo","CurrencyID=?",new String[]{Integer.toString(id)});
    }

    public Currency getCurrencyById(int Id){
        Cursor cursor = db.query("CurrencyInfo",new String[]{"Currency_Name","Currency_Unit","Sell_Rate","Buy_Rate"},"CurrencyID = ?",new String[]{Id+""},null,null,null,null);
        cursor.moveToFirst();
        Currency ca = null;
        while (!cursor.isAfterLast()){
            String name = cursor.getString(0);
            String unit = cursor.getString(1);
            String sell = cursor.getString(2);
            String buy = cursor.getString(3);
            ca = new Currency(name,unit,sell,buy);
            ca.setCurrencyID(Id);
            cursor.moveToNext();
        }
        cursor.close();
        return ca;
    }


    public List getCurrencyList(CharSequence s){
        ArrayList<Currency> List = new ArrayList<>();
        Cursor cursor = db.query("CurrencyInfo",new String[]{"CurrencyID","Currency_Name","Currency_Unit","Sell_Rate","Buy_Rate"},null,null,null,null,null,null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            int id = cursor.getInt(0) ;
            String name = cursor.getString(1);
            String unit = cursor.getString(2);
            String sell = cursor.getString(3);
            String buy = cursor.getString(4);
            Currency ca = new Currency(name,unit,sell,buy);
            ca.setCurrencyID(id);
            if(name.trim().toLowerCase().contains(s.toString().toLowerCase())){
                List.add(ca);
            }
            cursor.moveToNext();
        }
        return List;
    }
}
