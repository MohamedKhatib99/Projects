package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {
    private TextView Email ,fullname,salary,ID,ContactNo,Gender;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource employeeDataSource;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_profile,container,false);
        try {
            ID = v.findViewById(R.id.emp_id);
            Email = v.findViewById(R.id.tvp_email);
            fullname = v.findViewById(R.id.emp_fullname);
            ContactNo = v.findViewById(R.id.emp_contactno);
            Gender = v.findViewById(R.id.emp_gender);
            salary = v.findViewById(R.id.emp_salary);
            helper = new MySQLiteOpenHelper(getActivity(), "MobilBank_DB", null, 1);
            employeeDataSource = new EmployeeDataSource(helper);
            Bundle bundle = getArguments();
            int id = bundle.getInt("ID");
            Employee employee;
            employee = employeeDataSource.getEmployeeDataByID(id);
            fullname.setText(employee.get_FullName());
            ID.setText(Integer.toString(employee.get_EmployeeID()));
            Email.setText(employee.get_Email());
            ContactNo.setText(Long.toString(employee.get_PhoneNumber()));
            if(employee.get_Gender().toLowerCase().equals("male") || employee.get_Gender().toLowerCase().equals("erkek")){
                Gender.setText(getString(R.string.male));
            }
            else {
                Gender.setText(getString(R.string.female));
            }
            salary.setText((employee.get_Salary()) + "TL");
        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return v;
    }
}
