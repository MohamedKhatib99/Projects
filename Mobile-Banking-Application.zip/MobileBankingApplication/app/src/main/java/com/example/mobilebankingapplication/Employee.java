package com.example.mobilebankingapplication;

public class Employee extends Person{
    private int _EmployeeID;
    private long _TC;
    private String _FullName;
    private String _Gender;
    private String _BirthDate;
    private String _Email;
    private String _Password;
    private float _Salary;
    private long _PhoneNumber;
    private int _PostCode;
    private String _Country;
    private String _City;
    private String _Address;

    public Employee() {

    }


    public int get_AccessType() {
        return _AccessType;
    }

    public void set_AccessType(int _AccessType) {
        this._AccessType = _AccessType;
    }

    private int _AccessType;

    public Employee(long _TC, String _FullName, String _Gender, String _BirthDate, String _Email, float _Salary) {
        this._TC = _TC;
        this._FullName = _FullName;
        this._Gender = _Gender;
        this._BirthDate = _BirthDate;
        this._Email = _Email;
        this._Salary = _Salary;
    }

    public Employee(long _TC, String _FullName, String _Gender, String _BirthDate, String _Email, String _Password, float _Salary, long _PhoneNumber, int _PostCode, String _Country, String _City, String _Address) {
        this._TC = _TC;
        this._FullName = _FullName;
        this._Gender = _Gender;
        this._BirthDate = _BirthDate;
        this._Email = _Email;
        this._Password = _Password;
        this._Salary = _Salary;
        this._PhoneNumber = _PhoneNumber;
        this._PostCode = _PostCode;
        this._Country = _Country;
        this._City = _City;
        this._Address = _Address;
        this._AccessType = 1;
    }

    public int get_EmployeeID() {
        return _EmployeeID;
    }

    public void set_EmployeeID(int _EmployeeID) {
        this._EmployeeID = _EmployeeID;
    }

    public long get_TC() {
        return _TC;
    }

    public void set_TC(long _TC) {
        this._TC = _TC;
    }

    public String get_FullName() {
        return _FullName;
    }

    public void set_FullName(String _FullName) {
        this._FullName = _FullName;
    }

    public String get_Gender() {
        return _Gender;
    }

    public void set_Gender(String _Gender) {
        this._Gender = _Gender;
    }

    public String get_BirthDate() {
        return _BirthDate;
    }

    public void set_BirthDate(String _BirthDate) {
        this._BirthDate = _BirthDate;
    }

    public String get_Email() {
        return _Email;
    }

    public void set_Email(String _Email) {
        this._Email = _Email;
    }

    public String get_Password() {
        return _Password;
    }

    public void set_Password(String _Password) {
        this._Password = _Password;
    }

    public float get_Salary() {
        return _Salary;
    }

    public void set_Salary(float _Salary) {
        this._Salary = _Salary;
    }

    public long get_PhoneNumber() {
        return _PhoneNumber;
    }

    public void set_PhoneNumber(long _PhoneNumber) {
        this._PhoneNumber = _PhoneNumber;
    }

    public int get_PostCode() {
        return _PostCode;
    }

    public void set_PostCode(int _PostCode) {
        this._PostCode = _PostCode;
    }

    public String get_Country() {
        return _Country;
    }

    public void set_Country(String _Country) {
        this._Country = _Country;
    }

    public String get_City() {
        return _City;
    }

    public void set_City(String _City) {
        this._City = _City;
    }

    public String get_Address() {
        return _Address;
    }

    public void set_Address(String _Address) {
        this._Address = _Address;
    }
}

