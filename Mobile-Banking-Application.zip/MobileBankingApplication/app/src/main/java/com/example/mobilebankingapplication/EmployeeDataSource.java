package com.example.mobilebankingapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDataSource {

    private MySQLiteOpenHelper helper;
    private SQLiteDatabase db;

    public EmployeeDataSource(MySQLiteOpenHelper helper) {
        this.helper = helper;
        db = helper.getWritableDatabase();
    }

    public boolean Login(String email,String password){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM EmployeeInfo WHERE Email = ? AND Password = ?",new String[]{email,password});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean verifyEmployeeIfExist(String tc,String email){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM EmployeeInfo  WHERE TC = ? or Email = ? ",new String[]{tc,email});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean verifyEmployeeIfExist(String email,int id){
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM EmployeeInfo WHERE Email = ? AND EmployeeID != ?",new String[]{email,id+""});
        if(cursor.getCount() > 0){
            return true;
        }
        else return false;
    }
    public boolean updateEmployeePassword(String email,String newpassword,String password){
        db.rawQuery("UPDATE EmployeeInfo SET Password = ? WHERE Email = ? AND Password = ?",new String[]{newpassword,email,password});
        return true;
    }
    public boolean addNewEmployee(Employee emp){
        ContentValues values = new ContentValues();
        values.put("TC",emp.get_TC());
        values.put("FullName",emp.get_FullName());
        values.put("BirthDate",emp.get_BirthDate());
        values.put("Gender",emp.get_Gender());
        values.put("Email",emp.get_Email());
        values.put("Password",emp.get_Password());
        values.put("Salary",emp.get_Salary());
        values.put("AccessType",emp.get_AccessType());

        ContentValues values1 = new ContentValues();
        values1.put("PhoneNumber",emp.get_PhoneNumber());
        values1.put("PostCode",emp.get_PostCode());
        values1.put("Country",emp.get_Country());
        values1.put("City",emp.get_City());
        values1.put("Address",emp.get_Address());
        long id = db.insert("EmployeeInfo",null,values);
        long id1 = db.insert("EmployeeContactInfo",null,values1);
        if(id == -1 &&id1 == -1){
            return false;
        }
        else return true;
    }
    public Employee getEmployeeDataByEmailAndPassword(String email, String password){
        Cursor cursor = db.query("EmployeeInfo",new String[]{"EmployeeID","TC","FullName","BirthDate","Gender","Email","Salary"},"Email = ? AND Password = ?",new String[]{email,password},null,null,null,null);
        cursor.moveToFirst();
        Employee emp = null;
        int id = 0;
        while(!cursor.isAfterLast()){
            id = cursor.getInt(0) ;
            long TC = cursor.getLong(1);
            String FullName = cursor.getString(2);
            String Age = cursor.getString(3);
            String Gender = cursor.getString(4);
            String Email = cursor.getString(5);
            Float Salary = cursor.getFloat(6);
            emp = new Employee(TC,FullName,Gender,Age,Email,Salary);
            emp.set_EmployeeID(id);
            cursor.moveToNext();

        }
        Cursor cursor1 = db.query("EmployeeContactInfo",new String[]{"PhoneNumber","PostCode","Country","City","Address"},"EmployeeID = ?",new String[]{id+""},null,null,null,null);
        cursor1.moveToFirst();
        while(!cursor1.isAfterLast()){
            long phone = cursor1.getLong(0) ;
            int postcode = cursor1.getInt(1);
            String Country = cursor1.getString(2);
            String city = cursor1.getString(3);
            String address = cursor1.getString(4);
            emp.set_PostCode(postcode);
            emp.set_PhoneNumber(phone);
            emp.set_Country(Country);
            emp.set_City(city);
            emp.set_Address(address);
            cursor1.moveToNext();

        }
        return emp;
    }
    public Employee getEmployeeDataByID(int ID){
        Cursor cursor = db.query("EmployeeInfo",new String[]{"TC","FullName","BirthDate","Gender","Email","Password","Salary"},"EmployeeID = ? ",new String[]{ID+""},null,null,null,null);
        cursor.moveToFirst();
        Cursor cursor1 = db.query("EmployeeContactInfo",new String[]{"PhoneNumber","PostCode","Country","City","Address"},"EmployeeID = ?",new String[]{ID+""},null,null,null,null);
        cursor1.moveToFirst();
        Employee emp = null;
        while(!cursor.isAfterLast() && !cursor1.isAfterLast()){
            long TC = cursor.getLong(0);
            String FullName = cursor.getString(1);
            String Age = cursor.getString(2);
            String Gender = cursor.getString(3);
            String Email = cursor.getString(4);
            String Password = cursor.getString(5);
            float Salary = cursor.getFloat(6);
            long phone = cursor1.getLong(0) ;
            int postcode = cursor1.getInt(1);
            String country = cursor1.getString(2);
            String city = cursor1.getString(3);
            String address = cursor1.getString(4);
            emp =  new Employee(TC,FullName,Gender,Age,Email,Password,Salary,phone,postcode,country,city,address);
            emp.set_EmployeeID(ID);
            cursor.moveToNext();
            cursor1.moveToNext();

        }
        cursor.close();
        cursor1.close();
        return emp;
    }


    public boolean updateEmployeeDate(Employee emp,int ID){
        ContentValues values = new ContentValues();
        values.put("TC",emp.get_TC());
        values.put("FullName",emp.get_FullName());
        values.put("BirthDate",emp.get_BirthDate());
        values.put("Gender",emp.get_Gender());
        values.put("Email",emp.get_Email());
        values.put("Password",emp.get_Password());
        values.put("Salary",emp.get_Salary());
        values.put("AccessType",emp.get_AccessType());

        ContentValues values1 = new ContentValues();
        values1.put("PhoneNumber",emp.get_PhoneNumber());
        values1.put("PostCode",emp.get_PostCode());
        values1.put("Country",emp.get_Country());
        values1.put("City",emp.get_City());
        values1.put("Address",emp.get_Address());
        long id = db.update("EmployeeInfo",values,"EmployeeID = "+ID,null);
        long id1 = db.update("EmployeeContactInfo",values1,"EmployeeID = "+ID,null);
        if(id == -1 &&id1 == -1){
            return false;
        }
        else return true;
    }

    public List getEmployeesList(CharSequence s){
        ArrayList<Employee> List = new ArrayList<>();
        Cursor cursor = db.query("EmployeeInfo",new String[]{"EmployeeID","TC","FullName","BirthDate","Gender","Email","Password","Salary"},null,null,null,null,null,null);
        cursor.moveToFirst();
        Cursor cursor1 = db.query("EmployeeContactInfo",new String[]{"PhoneNumber","PostCode","Country","City","Address"},null,null,null,null,null,null);
        cursor1.moveToFirst();
        Employee emp = null;
        int id = 0;
        while(!cursor.isAfterLast() && !cursor1.isAfterLast()){
            id = cursor.getInt(0) ;
            long TC = cursor.getLong(1);
            String FullName = cursor.getString(2);
            String Age = cursor.getString(3);
            String Gender = cursor.getString(4);
            String Email = cursor.getString(5);
            String Password = cursor.getString(6);
            float Salary = cursor.getFloat(7);
            long phone = cursor1.getLong(0) ;
            int postcode = cursor1.getInt(1);
            String country = cursor1.getString(2);
            String city = cursor1.getString(3);
            String address = cursor1.getString(4);
            emp = new Employee(TC,FullName,Gender,Age,Email,Password,Salary,phone,postcode,country,city,address);
            emp.set_EmployeeID(id);
            if(emp.get_FullName().toLowerCase().trim().contains(s.toString().toLowerCase())){
                List.add(emp);
            }
            cursor.moveToNext();
            cursor1.moveToNext();


        }
        cursor.close();
        cursor1.close();
        return List;
    }
    public void deleteEmployeeById(int id ){
        db.delete("EmployeeInfo","EmployeeID=?",new String[]{Integer.toString(id)});
        db.delete("EmployeeContactInfo","EmployeeID=?",new String[]{Integer.toString(id)});
    }

}
