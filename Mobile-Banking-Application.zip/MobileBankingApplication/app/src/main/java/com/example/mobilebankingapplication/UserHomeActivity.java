package com.example.mobilebankingapplication;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class UserHomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private DrawerLayout drawerLayout;
    private TextView fullname;
    private ImageView IMGV;
    private int id;
    private Bundle bundle;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource customerDataSource;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private NavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        try {

            helper = new MySQLiteOpenHelper(this,"MobilBank_DB",null,1);
            customerDataSource = new CustomerDataSource(helper);
            drawerLayout = findViewById(R.id.drawer1);
            navigationView = findViewById(R.id.drawer_nav1);
            navigationView.setNavigationItemSelectedListener(UserHomeActivity.this);
            actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.Open,R.string.Close);
            drawerLayout.addDrawerListener(actionBarDrawerToggle);
            actionBarDrawerToggle.syncState();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            id = getIntent().getIntExtra("ID",0);
            Customer customer = customerDataSource.getCustomerDataByID(id);
            View header = navigationView.getHeaderView(0);
            fullname = header.findViewById(R.id.h_usfullname);
            fullname.setText(customer.getFullName().toUpperCase());
            IMGV = header.findViewById(R.id.img_view_us);
            if(savedInstanceState == null){
                bundle = new Bundle();
                bundle.putInt("ID",customer.get_id());
                UserHomePageFragment userHomePageFragment = new UserHomePageFragment();
                userHomePageFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,userHomePageFragment).addToBackStack(null).commit();
                navigationView.setCheckedItem(R.id.nav_home_us);
            }
        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
        }


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true ;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.nav_profile_us:
                UserProfileFragment profileFragment = new UserProfileFragment();
                profileFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,profileFragment).addToBackStack(null).commit();
                break;
            case R.id.nav_home_us:
                UserHomePageFragment userHomePageFragment = new UserHomePageFragment();
                userHomePageFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,userHomePageFragment).addToBackStack(null).commit();
                break;
            case R.id.nav_accounts_us:
                UserAccountFragment userAccountFragment = new UserAccountFragment();
                userAccountFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,userAccountFragment).addToBackStack(null).commit();
                break;
            case R.id.nav_transfer_us:
                UserTransferFragment userTransferFragment = new UserTransferFragment();
                userTransferFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,userTransferFragment).addToBackStack(null).commit();
                break;
            case R.id.nav_currency_us:
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,new UserCurrencyFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_settings_us:
                UserSettingsFragment userSettingsFragment = new UserSettingsFragment();
                userSettingsFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,userSettingsFragment).addToBackStack(null).commit();
                break;
            case R.id.nav_logout_us:
                onBackPressed();
                break;
            case R.id.nav_supportcenter_us:
                getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,new SupportCenter()).addToBackStack(null).commit();

                break;

        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.question)
                .setMessage(R.string.logout)
                .setIcon(R.drawable.ic_help_outline_black_24dp)
                .setNegativeButton(R.string.no, null)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        UserHomeActivity.super.onBackPressed();
                        finish();
                    }
                }).create().show();
    }

    public void openProfile(View view) {
        try {
            Bundle bundle = new Bundle();
            bundle.putInt("ID",id);
            UserProfileFragment profileFragment = new UserProfileFragment();
            profileFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.us_fragment_container,profileFragment).addToBackStack(null).commit();
        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
        }


    }
}
