package com.example.mobilebankingapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class EmployeesAdapter extends ArrayAdapter {
    private List<Employee> list;
    private Context context;
    private int resId;

    public EmployeesAdapter(@NonNull Context context, int resource, @NonNull List list) {
        super(context, resource, list);
        this.list = list;
        this.context = context;
        this.resId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(resId, parent, false);
        TextView id = convertView.findViewById(R.id.tvm_ID);
        TextView tc = convertView.findViewById(R.id.tvm_TC);
        TextView fullname = convertView.findViewById(R.id.tvm_FullName);
        TextView birth = convertView.findViewById(R.id.tvm_BirthDate);
        TextView phone = convertView.findViewById(R.id.tvm_Phone);
        TextView email = convertView.findViewById(R.id.tvm_Email);
        TextView salary = convertView.findViewById(R.id.tvm_Salary);
        id.setText(list.get(position).get_EmployeeID() +"");
        tc.setText(Long.toString(list.get(position).get_TC()));
        fullname.setText(list.get(position).get_FullName()+"");
        birth.setText(list.get(position).get_BirthDate()+"");
        phone.setText(Long.toString(list.get(position).get_PhoneNumber()));
        email.setText(list.get(position).get_Email()+"");
        salary.setText(list.get(position).get_Salary()+"TL");
        return convertView;
    }

    @Override
    public int getCount() {
        return list.size();
    }

}

