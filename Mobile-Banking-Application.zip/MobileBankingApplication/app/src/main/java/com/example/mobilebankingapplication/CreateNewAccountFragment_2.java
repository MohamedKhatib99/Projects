package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class CreateNewAccountFragment_2 extends Fragment {
    private Button save;
    EditText accno,acctype,accname,balance,description;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource cds;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_createnewaccount_2,container,false);
         save = v.findViewById(R.id.btn_save);
         accno = v.findViewById(R.id.et_accountno);
         acctype = v.findViewById(R.id.et_accounttype);
         accname = v.findViewById(R.id.et_accountname);
         balance = v.findViewById(R.id.et_balance);
         description = v.findViewById(R.id.et_description);
         helper = new MySQLiteOpenHelper(getActivity(),"MobilBank_DB",null,1);
         cds = new CustomerDataSource(helper);

        save.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 try {
                     if (accno.getText().toString().isEmpty() && acctype.getText().toString().trim().isEmpty() && accname.getText().toString().trim().isEmpty() && balance.getText().toString().trim().isEmpty() && description.getText().toString().trim().isEmpty()) {
                         accno.setError(getString(R.string.Enter_Account_Number));
                         acctype.setError(getString(R.string.Enter_Account_Type));
                         accname.setError(getString(R.string.Enter_Account_Name));
                         balance.setError(getString(R.string.Enter_Balance));
                         description.setError(getString(R.string.Enter_Description));
                         accno.requestFocus();
                         return;
                     }
                     if (accno.getText().toString().isEmpty()) {
                         accno.setError(getString(R.string.Enter_Account_Number));
                         accno.requestFocus();
                         return;
                     }
                     if (accno.getText().toString().length() < 10) {
                         accno.setError(getString(R.string.Invalid_Account_Number));
                         accno.requestFocus();
                         return;
                     }
                     if (acctype.getText().toString().trim().isEmpty()) {
                         acctype.setError(getString(R.string.Enter_Account_Type));
                         acctype.requestFocus();
                         return;
                     }
                     if (accname.getText().toString().trim().isEmpty()) {
                         accname.setError(getString(R.string.Enter_Account_Name));
                         accname.requestFocus();
                         return;
                     }

                     if (balance.getText().toString().trim().isEmpty()) {
                         balance.setError(getString(R.string.Enter_Balance));
                         balance.requestFocus();
                         return;
                     }
                     if (description.getText().toString().trim().isEmpty()) {
                         description.setError(getString(R.string.Enter_Description));
                         description.requestFocus();
                         return;
                     }
                     Bundle bundle = getArguments();
                     String TC = bundle.getString("TC");
                     long tc = Long.parseLong(TC.trim());
                     String FULLNAME = bundle.getString("FULLNAME");
                     String FATHERNAME = bundle.getString("FATHERNAME");
                     String MOTHERNAME = bundle.getString("MOTHERNAME");
                     String AGE = bundle.getString("AGE");
                     String GENDER = bundle.getString("GENDER");
                     String EMAIL = bundle.getString("EMAIL");
                     String PASSWORD = bundle.getString("PASSWORD");
                     String PHONE = bundle.getString("PHONE");
                     long phone = Long.parseLong(PHONE.trim());
                     String POSTCODE = bundle.getString("POSTCODE");
                     int postcode = Integer.parseInt(POSTCODE.trim());
                     String COUNTRY = bundle.getString("COUNTRY");
                     String CITY = bundle.getString("CITY");
                     String ADDRESS = bundle.getString("ADDRESS");
                     long ACCOUNTNUMBER = Long.parseLong(accno.getText().toString());
                     String ACCOUNTTYPE = acctype.getText().toString().trim();
                     String ACCOUNTNAME = accname.getText().toString().trim();
                     float BALANCE = Long.parseLong(balance.getText().toString().trim());
                     String DESCRIPTION = description.getText().toString().trim();
                     boolean verify = cds.verifyCustomerIfExist(TC,EMAIL,accno.getText().toString());
                     if (verify) {
                         onCreateDialog1(getString(R.string.Customer_Already_Exist));

                         return;
                     }
                     Customer cs = new Customer(tc, FULLNAME, FATHERNAME, MOTHERNAME, GENDER, AGE, EMAIL, PASSWORD, phone, postcode, COUNTRY, CITY, ADDRESS, ACCOUNTNUMBER, ACCOUNTTYPE, BALANCE, ACCOUNTNAME, DESCRIPTION);
                     boolean result = cds.addNewCustomer(cs);
                     if (result) {
                         onCreateDialog();



                     } else {
                         onCreateDialog1(getString(R.string.erro_message));
                     }


                 }
                 catch (Exception e){
                     Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
                 }
             }
         });


        return v;

    }
    public Dialog onCreateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.Info);
        builder.setMessage(R.string.Account_Added);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentManager manager = getFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().commit();
            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.error);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }

}
