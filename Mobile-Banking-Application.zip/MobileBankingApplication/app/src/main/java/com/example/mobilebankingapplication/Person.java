package com.example.mobilebankingapplication;

public class Person {

}
