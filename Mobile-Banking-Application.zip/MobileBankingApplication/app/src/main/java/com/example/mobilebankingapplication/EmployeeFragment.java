package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class EmployeeFragment extends Fragment {
    private Button btnaddemployee,viewemployeeslist;
    private ListView list;
    private EditText search;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource eds;
    EmployeesAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragments_employee,container,false);
        try {
            helper = new MySQLiteOpenHelper(getContext(), "MobilBank_DB", null, 1);
            eds = new EmployeeDataSource(helper);
            btnaddemployee = v.findViewById(R.id.btn_addemployee);
            viewemployeeslist = v.findViewById(R.id.btn_viewemployeeslist);
            search = v.findViewById(R.id.btn_searchemployee);
            list = v.findViewById(R.id.employeesListView);
            viewemployeeslist.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RefreshListView("");
                }
            });
            btnaddemployee.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_container, new AddEmployeeFragment());
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
            search.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if(s.length() == 0 ){
                        RefreshListView("");
                    }
                    else {
                        RefreshListView(s);
                    }


                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
            RefreshListView("");
            registerForContextMenu(list);
        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return v;
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        try {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            if (item.getItemId() == R.id.delete) {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.tvm_ID);
                int id = Integer.parseInt(txt_id.getText().toString());
                eds.deleteEmployeeById(id);
                RefreshListView("");
                return true;
            }
            if (item.getItemId() == R.id.profile) {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.tvm_ID);
                int id = Integer.parseInt(txt_id.getText().toString());
                Bundle bundle = new Bundle();
                bundle.putInt("ID", id);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                Employee_Profile_Fragment epf = new Employee_Profile_Fragment();
                epf.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, epf);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
            if (item.getItemId() == R.id.btnedit) {
                TextView txt_id = (TextView) info.targetView.findViewById(R.id.tvm_ID);
                int id = Integer.parseInt(txt_id.getText().toString());
                Bundle bundle = new Bundle();
                bundle.putInt("ID", id);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                UpdateEmployeeFragment emp = new UpdateEmployeeFragment();
                emp.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, emp);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }

        }
        catch (Exception e){
            Toast.makeText(getActivity(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return super.onContextItemSelected(item);

    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.context_menu2,menu);
    }

    private void RefreshListView(CharSequence s){

        adapter = new EmployeesAdapter(getActivity(),R.layout.employee_item_layout,eds.getEmployeesList(s));
        list.setAdapter(adapter);
    }

}
