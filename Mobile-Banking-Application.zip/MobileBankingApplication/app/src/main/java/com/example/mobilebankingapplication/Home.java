package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;
    private TextView fullname;
    ImageView IMGV;
    private int ID;
    private MySQLiteOpenHelper helper;
    private EmployeeDataSource employeeDataSource;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private NavigationView navigationView;
    private Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        try {
            helper = new MySQLiteOpenHelper(this,"MobilBank_DB",null,1);
            employeeDataSource = new EmployeeDataSource(helper);
            drawerLayout = findViewById(R.id.drawer);
            navigationView = findViewById(R.id.drawer_nav);
            navigationView.setNavigationItemSelectedListener(Home.this);
            actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.Open,R.string.Close);
            drawerLayout.addDrawerListener(actionBarDrawerToggle);
            actionBarDrawerToggle.syncState();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            if(savedInstanceState == null){
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).commit();
                navigationView.setCheckedItem(R.id.nav_home);
            }
            ID = getIntent().getIntExtra("ID",0);
            Employee employee = employeeDataSource.getEmployeeDataByID(ID);
            View header = navigationView.getHeaderView(0);
            fullname = header.findViewById(R.id.tfullname);
            fullname.setText(employee.get_FullName().toUpperCase());
            IMGV = header.findViewById(R.id.img_view);
            bundle = new Bundle();
            bundle.putInt("ID",ID);
            ProfileFragment profileFragment = new ProfileFragment();
            profileFragment.setArguments(bundle);
        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true ;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.nav_profile:
                ProfileFragment profileFragment = new ProfileFragment();
                profileFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,profileFragment).addToBackStack(null).commit();
            break;
            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_accounts:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new AccountsFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_employees:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new EmployeeFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_withdraw:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new WithdrawFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_deposit:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new DepositFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_transfer:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new TransferFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_currency:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new CurrencyFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_settings:
                SettingsFragment settingsFragment = new SettingsFragment();
                settingsFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,settingsFragment).addToBackStack(null).commit();
                break;
            case R.id.nav_applications:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new ApplicationsFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_logout:
                onCreateDialog();
                break;
            case R.id.nav_supportcenter:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new SupportCenter()).addToBackStack(null).commit();

                break;

        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public Dialog onCreateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
        builder.setTitle(R.string.question);
        builder.setMessage(R.string.logout);
        builder.setIcon(R.drawable.ic_help_outline_black_24dp);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.setNegativeButton(R.string.no,null);
        builder.create();
        return builder.show();
    }

    public void openProfile(View view) {
        try {
            Bundle bundle = new Bundle();
            bundle.putInt("ID",ID);
            ProfileFragment profileFragment = new ProfileFragment();
            profileFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,profileFragment).addToBackStack(null).commit();
        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
        }


    }
}

