package com.example.mobilebankingapplication;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;

public class Password_Recover_Activity extends AppCompatActivity {
    EditText email,tc;
    AwesomeValidation awesomeValidation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password__recover_);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        awesomeValidation.addValidation(this,R.id.et_tc_us, "[0-9]{11}$",R.string.Invalid_tc);
        awesomeValidation.addValidation(this,R.id.et_email_us, Patterns.EMAIL_ADDRESS,R.string.invalid_email);
    }

    public void resetPassword(View v) {
        if(awesomeValidation.validate()){
            Toast.makeText(this, getString(R.string.ResetMsg), Toast.LENGTH_SHORT).show();
        }
    }
}
