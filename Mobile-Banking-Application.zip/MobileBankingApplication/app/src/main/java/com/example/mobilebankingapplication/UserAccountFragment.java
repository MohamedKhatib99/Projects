package com.example.mobilebankingapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

public class UserAccountFragment extends Fragment {
    private Button edit,update;
    private TextView balance,accno;
    private EditText acname;
    private MySQLiteOpenHelper helper;
    private CustomerDataSource cds;
    private Bundle bundle;
    private int ID;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_user_account,container,false);
        helper = new MySQLiteOpenHelper(getContext(),"MobilBank_DB",null,1);
        cds = new CustomerDataSource(helper);
        edit = v.findViewById(R.id.btn_us_Cancel);
        update = v.findViewById(R.id.btn_us_update);
        balance = v.findViewById(R.id.tv_us_balance);
        accno = v.findViewById(R.id.tv_us_accno);
        acname = v.findViewById(R.id.et_us_accname);

        bundle = getArguments();
        if(bundle != null){
            int ID = bundle.getInt("ID");
            Customer customer = cds.getCustomerDataByID(ID);
            balance.setText(customer.getBalance() + " TL");
            accno.setText(customer.getAccountNumber()+"");
            acname.setText(customer.getAccountName());
            ID = customer.get_id();

        }
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edit.getText().toString() != getString(R.string.cancel)){
                    update.setEnabled(true);
                    edit.setText(getString(R.string.cancel));
                    update.setBackgroundResource(R.drawable.rounded_button);
                    acname.setEnabled(true);
                }
                else {
                    update.setEnabled(false);
                    edit.setText(getString(R.string.edit));
                    update.setBackgroundResource(R.drawable.rounded_button_grey);
                    acname.setEnabled(false);
                }


            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String AccountName = acname.getText().toString().trim();

                boolean res = cds.updateCustomerAccName(AccountName,ID);
                if(res){
                    onCreateDialog();
                    update.setEnabled(false);
                    edit.setText(getString(R.string.edit));
                    update.setBackgroundResource(R.drawable.rounded_button_grey);
                    acname.setEnabled(false);
                }



            }
        });
        return v;
    }
    public Dialog onCreateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.Info);
        builder.setMessage(R.string.Updated_Successfully);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {


            }
        });
        builder.create();
        return builder.show();
    }
    public Dialog onCreateDialog1(String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.error);
        builder.setMessage(message);
        builder.setIcon(R.drawable.ic_info_black_24dp);
        builder.setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create();
        return builder.show();
    }
}
