﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class LessonsTable
    {
        public LessonsTable()
        {
            StudentTable = new HashSet<StudentTable>();
        }

        public int LessonId { get; set; }
        public int BranchId { get; set; }
        public int LanguageId { get; set; }
        public int LevelId { get; set; }
        public int TeacherId { get; set; }
        public int ClassRoomId { get; set; }
        public string LessonName { get; set; }
        public string DayName { get; set; }
        public int WeekId { get; set; }

        public virtual BranchTable Branch { get; set; }
        public virtual ClassRoomInBranch ClassRoom { get; set; }
        public virtual LanguagesTable Language { get; set; }
        public virtual LevelsTable Level { get; set; }
        public virtual TeachersTable Teacher { get; set; }
        public virtual WeekDaysHours Week { get; set; }
        public virtual ICollection<StudentTable> StudentTable { get; set; }
    }
}
