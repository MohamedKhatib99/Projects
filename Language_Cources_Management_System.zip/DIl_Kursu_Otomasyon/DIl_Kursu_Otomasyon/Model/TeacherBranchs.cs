﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class TeacherBranchs
    {
        public int TeacherBranchId { get; set; }
        public int TeacherId { get; set; }
        public int BranchId { get; set; }

        public virtual BranchTable Branch { get; set; }
        public virtual TeachersTable Teacher { get; set; }
    }
}
