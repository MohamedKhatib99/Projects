﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIl_Kursu_Otomasyon.Model
{
    public  class LoadProfile
    {
        public static int UserId { get; set; }
        public static int BranchId { get; set; }
        public static string UserType { get; set; }
        public static string FullName { get; set; }
        public static string Gender { get; set; }
        public static string Email { get; set; }
        public static string ContactNo { get; set; }
        public static string Address { get; set; }
        public static string UserName { get; set; }
        public static string Password { get; set; }
    }
}
