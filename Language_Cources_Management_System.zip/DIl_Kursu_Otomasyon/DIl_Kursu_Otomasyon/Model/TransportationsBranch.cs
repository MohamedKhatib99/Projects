﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class TransportationsBranch
    {
        public int BranchTransportationId { get; set; }
        public int BranchId { get; set; }
        public int TransportationId { get; set; }
        public string Description { get; set; }

        public virtual BranchTable Branch { get; set; }
        public virtual TransportationTable BranchTransportation { get; set; }
    }
}
