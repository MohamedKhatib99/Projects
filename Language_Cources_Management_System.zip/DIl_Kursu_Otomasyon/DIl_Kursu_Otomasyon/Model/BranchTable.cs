﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class BranchTable
    {
        public BranchTable()
        {
            ClassRoomInBranch = new HashSet<ClassRoomInBranch>();
            CommunicationsBranch = new HashSet<CommunicationsBranch>();
            LessonsTable = new HashSet<LessonsTable>();
            StudentTable = new HashSet<StudentTable>();
            TeacherBranchs = new HashSet<TeacherBranchs>();
            TransportationsBranch = new HashSet<TransportationsBranch>();
            UsersTable = new HashSet<UsersTable>();
        }

        public int BranchId { get; set; }
        public string BranchName { get; set; }
        public string Address { get; set; }

        public virtual ICollection<ClassRoomInBranch> ClassRoomInBranch { get; set; }
        public virtual ICollection<CommunicationsBranch> CommunicationsBranch { get; set; }
        public virtual ICollection<LessonsTable> LessonsTable { get; set; }
        public virtual ICollection<StudentTable> StudentTable { get; set; }
        public virtual ICollection<TeacherBranchs> TeacherBranchs { get; set; }
        public virtual ICollection<TransportationsBranch> TransportationsBranch { get; set; }
        public virtual ICollection<UsersTable> UsersTable { get; set; }
    }
}
