﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class CommunicationTable
    {
        public CommunicationTable()
        {
            CommunicationsBranch = new HashSet<CommunicationsBranch>();
        }

        public int CommunicationId { get; set; }
        public string CommunicationName { get; set; }

        public virtual ICollection<CommunicationsBranch> CommunicationsBranch { get; set; }
    }
}
