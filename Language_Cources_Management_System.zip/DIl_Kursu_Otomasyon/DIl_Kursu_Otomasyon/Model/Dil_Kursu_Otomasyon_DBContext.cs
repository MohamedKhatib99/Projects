﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class Dil_Kursu_Otomasyon_DBContext : DbContext
    {
        public Dil_Kursu_Otomasyon_DBContext()
        {
        }

        public Dil_Kursu_Otomasyon_DBContext(DbContextOptions<Dil_Kursu_Otomasyon_DBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BranchTable> BranchTable { get; set; }
        public virtual DbSet<ClassRoomInBranch> ClassRoomInBranch { get; set; }
        public virtual DbSet<CommunicationTable> CommunicationTable { get; set; }
        public virtual DbSet<CommunicationsBranch> CommunicationsBranch { get; set; }
        public virtual DbSet<LanguagesTable> LanguagesTable { get; set; }
        public virtual DbSet<LessonsTable> LessonsTable { get; set; }
        public virtual DbSet<LevelsTable> LevelsTable { get; set; }
        public virtual DbSet<StudentPayment> StudentPayment { get; set; }
        public virtual DbSet<StudentTable> StudentTable { get; set; }
        public virtual DbSet<TeacherBranchs> TeacherBranchs { get; set; }
        public virtual DbSet<TeacherLanguages> TeacherLanguages { get; set; }
        public virtual DbSet<TeachersTable> TeachersTable { get; set; }
        public virtual DbSet<TransportationTable> TransportationTable { get; set; }
        public virtual DbSet<TransportationsBranch> TransportationsBranch { get; set; }
        public virtual DbSet<UsersTable> UsersTable { get; set; }
        public virtual DbSet<WeekDaysHours> WeekDaysHours { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-UQ3F2RM;Initial Catalog=Dil_Kursu_Otomasyon_DB;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BranchTable>(entity =>
            {
                entity.HasKey(e => e.BranchId);

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.BranchName)
                    .IsRequired()
                    .HasColumnName("Branch_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ClassRoomInBranch>(entity =>
            {
                entity.HasKey(e => e.ClassRoomId);

                entity.ToTable("ClassRoom_In_Branch");

                entity.Property(e => e.ClassRoomId).HasColumnName("ClassRoom_ID");

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.ClassRoomCode)
                    .IsRequired()
                    .HasColumnName("ClassRoom_Code")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.ClassRoomInBranch)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClassRoom_In_Branch_BranchTable");
            });

            modelBuilder.Entity<CommunicationTable>(entity =>
            {
                entity.HasKey(e => e.CommunicationId);

                entity.ToTable("Communication_Table");

                entity.Property(e => e.CommunicationId).HasColumnName("Communication_ID");

                entity.Property(e => e.CommunicationName)
                    .IsRequired()
                    .HasColumnName("Communication_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CommunicationsBranch>(entity =>
            {
                entity.HasKey(e => e.BranchCoomunicationId)
                    .HasName("PK__tmp_ms_x__A0465DCEE5198A20");

                entity.ToTable("Communications_Branch");

                entity.Property(e => e.BranchCoomunicationId).HasColumnName("Branch_Coomunication_ID");

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.CommunicationId).HasColumnName("Communication_ID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .IsUnicode(false);

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.CommunicationsBranch)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Communications_Branch_BranchTable");

                entity.HasOne(d => d.Communication)
                    .WithMany(p => p.CommunicationsBranch)
                    .HasForeignKey(d => d.CommunicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Communications_Branch_Communication_Table");
            });

            modelBuilder.Entity<LanguagesTable>(entity =>
            {
                entity.HasKey(e => e.LanguageId);

                entity.ToTable("Languages_Table");

                entity.Property(e => e.LanguageId).HasColumnName("Language_ID");

                entity.Property(e => e.LanguageName)
                    .IsRequired()
                    .HasColumnName("Language_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LessonsTable>(entity =>
            {
                entity.HasKey(e => e.LessonId);

                entity.ToTable("Lessons_Table");

                entity.Property(e => e.LessonId).HasColumnName("Lesson_ID");

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.ClassRoomId).HasColumnName("ClassRoom_ID");

                entity.Property(e => e.DayName)
                    .IsRequired()
                    .HasColumnName("Day_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LanguageId).HasColumnName("Language_ID");

                entity.Property(e => e.LessonName)
                    .IsRequired()
                    .HasColumnName("Lesson_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LevelId).HasColumnName("Level_ID");

                entity.Property(e => e.TeacherId).HasColumnName("Teacher_ID");

                entity.Property(e => e.WeekId).HasColumnName("Week_ID");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.LessonsTable)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Lessons_Table_BranchTable");

                entity.HasOne(d => d.ClassRoom)
                    .WithMany(p => p.LessonsTable)
                    .HasForeignKey(d => d.ClassRoomId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Lessons_Table_ClassRoom_In_Branch");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.LessonsTable)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Lessons_Table_Languages_Table");

                entity.HasOne(d => d.Level)
                    .WithMany(p => p.LessonsTable)
                    .HasForeignKey(d => d.LevelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Lessons_Table_Levels_Table");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.LessonsTable)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Lessons_Table_Teachers_Table");

                entity.HasOne(d => d.Week)
                    .WithMany(p => p.LessonsTable)
                    .HasForeignKey(d => d.WeekId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Lessons_Table_Week_Days_Hours");
            });

            modelBuilder.Entity<LevelsTable>(entity =>
            {
                entity.HasKey(e => e.LevelId);

                entity.ToTable("Levels_Table");

                entity.Property(e => e.LevelId).HasColumnName("Level_ID");

                entity.Property(e => e.LevelName)
                    .IsRequired()
                    .HasColumnName("Level_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StudentPayment>(entity =>
            {
                entity.HasKey(e => e.PaymentId);

                entity.ToTable("Student_Payment");

                entity.Property(e => e.PaymentId).HasColumnName("Payment_ID");

                entity.Property(e => e.PaymentAmount)
                    .HasColumnName("Payment_Amount")
                    .HasColumnType("money");

                entity.Property(e => e.PaymentDate)
                    .HasColumnName("Payment_Date")
                    .HasColumnType("date");

                entity.Property(e => e.PaymentName)
                    .IsRequired()
                    .HasColumnName("Payment_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaymentStatus)
                    .IsRequired()
                    .HasColumnName("Payment_Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaymentType)
                    .IsRequired()
                    .HasColumnName("Payment_Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StudentId).HasColumnName("Student_ID");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.StudentPayment)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Payment_Student_Table");
            });

            modelBuilder.Entity<StudentTable>(entity =>
            {
                entity.HasKey(e => e.StudentId);

                entity.ToTable("Student_Table");

                entity.Property(e => e.StudentId).HasColumnName("Student_ID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.ContactNo)
                    .IsRequired()
                    .HasColumnName("Contact_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gsm)
                    .IsRequired()
                    .HasColumnName("GSM")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LanguageId).HasColumnName("Language_ID");

                entity.Property(e => e.LessonId).HasColumnName("Lesson_ID");

                entity.Property(e => e.StudentName)
                    .IsRequired()
                    .HasColumnName("Student_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.StudentTable)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Table_BranchTable");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.StudentTable)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Table_Languages_Table");

                entity.HasOne(d => d.Lesson)
                    .WithMany(p => p.StudentTable)
                    .HasForeignKey(d => d.LessonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Table_Lessons_Table");
            });

            modelBuilder.Entity<TeacherBranchs>(entity =>
            {
                entity.HasKey(e => e.TeacherBranchId)
                    .HasName("PK__tmp_ms_x__F60FB24EE9DCEBB5");

                entity.ToTable("Teacher_Branchs");

                entity.Property(e => e.TeacherBranchId).HasColumnName("Teacher_Branch_ID");

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.TeacherId).HasColumnName("Teacher_ID");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.TeacherBranchs)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teacher_Branchs_BranchTable");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.TeacherBranchs)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teacher_Branchs_Teachers_Table");
            });

            modelBuilder.Entity<TeacherLanguages>(entity =>
            {
                entity.HasKey(e => e.TeacherLanguageId)
                    .HasName("PK__tmp_ms_x__BF73F33E6712E5D7");

                entity.ToTable("Teacher_Languages");

                entity.Property(e => e.TeacherLanguageId).HasColumnName("Teacher_Language_ID");

                entity.Property(e => e.LanguageId).HasColumnName("Language_ID");

                entity.Property(e => e.TeacherId).HasColumnName("Teacher_ID");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.TeacherLanguages)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teacher_Languages_Languages_Table");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.TeacherLanguages)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teacher_Languages_Teachers_Table");
            });

            modelBuilder.Entity<TeachersTable>(entity =>
            {
                entity.HasKey(e => e.TeacherId);

                entity.ToTable("Teachers_Table");

                entity.Property(e => e.TeacherId).HasColumnName("Teacher_ID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gsm)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartingDate)
                    .HasColumnName("Starting_Date")
                    .HasColumnType("date");

                entity.Property(e => e.TeacherName)
                    .IsRequired()
                    .HasColumnName("Teacher_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TransportationTable>(entity =>
            {
                entity.HasKey(e => e.TransportationId);

                entity.ToTable("Transportation_Table");

                entity.Property(e => e.TransportationId).HasColumnName("Transportation_ID");

                entity.Property(e => e.TransportationName)
                    .IsRequired()
                    .HasColumnName("Transportation_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TransportationsBranch>(entity =>
            {
                entity.HasKey(e => e.BranchTransportationId);

                entity.ToTable("Transportations_Branch");

                entity.Property(e => e.BranchTransportationId)
                    .HasColumnName("Branch_Transportation_ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.TransportationId).HasColumnName("Transportation_ID");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.TransportationsBranch)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Transportations_Branch_BranchTable");

                entity.HasOne(d => d.BranchTransportation)
                    .WithOne(p => p.TransportationsBranch)
                    .HasForeignKey<TransportationsBranch>(d => d.BranchTransportationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Transportations_Branch_Transportation_Table");
            });

            modelBuilder.Entity<UsersTable>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.Property(e => e.UserId).HasColumnName("User_ID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.BranchId).HasColumnName("Branch_ID");

                entity.Property(e => e.ContactNo)
                    .IsRequired()
                    .HasColumnName("Contact_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FullName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasColumnName("User_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserType)
                    .IsRequired()
                    .HasColumnName("User_Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.UsersTable)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UsersTable_BranchTable");
            });

            modelBuilder.Entity<WeekDaysHours>(entity =>
            {
                entity.HasKey(e => e.WeekId);

                entity.ToTable("Week_Days_Hours");

                entity.Property(e => e.WeekId).HasColumnName("Week_ID");

                entity.Property(e => e.DayName)
                    .IsRequired()
                    .HasColumnName("Day_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Hours)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TeacherId).HasColumnName("Teacher_ID");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.WeekDaysHours)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Week_Days_Hours_Teachers_Table");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
