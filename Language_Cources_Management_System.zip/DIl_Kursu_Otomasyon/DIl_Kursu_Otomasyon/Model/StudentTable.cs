﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class StudentTable
    {
        public StudentTable()
        {
            StudentPayment = new HashSet<StudentPayment>();
        }

        public int StudentId { get; set; }
        public int BranchId { get; set; }
        public int LanguageId { get; set; }
        public int LessonId { get; set; }
        public string StudentName { get; set; }
        public string Gender { get; set; }
        public string Gsm { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }

        public virtual BranchTable Branch { get; set; }
        public virtual LanguagesTable Language { get; set; }
        public virtual LessonsTable Lesson { get; set; }
        public virtual ICollection<StudentPayment> StudentPayment { get; set; }
    }
}
