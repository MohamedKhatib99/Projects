﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }
        void FillGrid(string searchvalue)
        {
            try
            {
                
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvBranchesList.DataSource = (from b in db.BranchTable
                                                      select new
                                                      {
                                                          ID = b.BranchId,
                                                          BranchName = b.BranchName,
                                                          Address = b.Address
                                                      }).ToList();
                        dgvBranchesList.Columns[0].Width = 100;
                        dgvBranchesList.Columns[1].Width = 150;
                        dgvBranchesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvBranchesList.DataSource = db.BranchTable.Where(x => x.BranchName.Contains(searchvalue))
                                                        .Select(b => new
                                                        {
                                                            ID = b.BranchId,
                                                            BranchName = b.BranchName,
                                                            Address = b.Address
                                                        })
                                                        .ToList();
                        dgvBranchesList.Columns[0].Width = 100;
                        dgvBranchesList.Columns[1].Width = 150;
                        dgvBranchesList.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {
                if (tb_BranchName.Text.Trim() == "")
                {
                    ep.SetError(tb_BranchName, "Please Enter Branch Name.");
                    tb_BranchName.Focus();
                    return;
                }
                if (tb_BranchAddress.Text.Trim() == "")
                {
                    ep.SetError(tb_BranchAddress, "Please Enter Branch Address.");
                    tb_BranchAddress.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var query = (from c in db.BranchTable
                                 select new
                                 {
                                     ID = c.BranchId,
                                     Name = c.BranchName
                                 }).ToList();
                    foreach (var item in query)
                    {

                        if (item.Name.ToUpper() == tb_BranchName.Text.Trim().ToUpper())
                        {
                            ep.SetError(tb_BranchName, "Already Registered!");
                            tb_BranchName.Focus();
                            return;
                        }
                    }
                    BranchTable b = new BranchTable();
                    b.BranchName = tb_BranchName.Text.Trim();
                    b.Address = tb_BranchAddress.Text.Trim();
                    db.BranchTable.Add(b);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        void Clear()
        {
            tb_BranchName.Text = "";
            tb_BranchAddress.Text = "";
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvBranchesList.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvBranchesList.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvBranchesList != null && dgvBranchesList.Rows.Count > 0)
                {
                    if (dgvBranchesList.SelectedRows.Count == 1)
                    {
                        tb_BranchName.Text = Convert.ToString(dgvBranchesList.CurrentRow.Cells[1].Value);
                        tb_BranchAddress.Text = Convert.ToString(dgvBranchesList.CurrentRow.Cells[2].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }

            
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {
                if (tb_BranchName.Text.Trim() == "")
                {
                    ep.SetError(tb_BranchName, "Please Enter Branch Name.");
                    tb_BranchName.Focus();
                    return;
                }
                if (tb_BranchAddress.Text.Trim() == "")
                {
                    ep.SetError(tb_BranchAddress, "Please Enter Branch Address.");
                    tb_BranchAddress.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvBranchesList.CurrentRow.Cells[0].Value);
                    var query = (from c in db.BranchTable
                                                     select new
                                                      {
                                                      ID = c.BranchId,
                                                      Name = c.BranchName
                                                     }).ToList();
                    foreach (var item in query)
                    {

                        if (item.ID != int.Parse(ID) && item.Name.ToUpper() == tb_BranchName.Text.Trim().ToUpper())
                        {
                            ep.SetError(tb_BranchName, "Already Registered!");
                            tb_BranchName.Focus();
                            return;
                        }
                    }
                    
                    BranchTable b = new BranchTable();
                    b.BranchName = tb_BranchName.Text.Trim();
                    b.Address = tb_BranchAddress.Text.Trim();
                    b.BranchId = int.Parse(ID);
                    db.BranchTable.Attach(b);
                    db.Entry(b).State = EntityState.Modified;
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisableControls();


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
         
                Clear();
                DisableControls();
            
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text.Trim());
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvBranchesList != null && dgvBranchesList.Rows.Count > 0)
                {
                    if (dgvBranchesList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvBranchesList.CurrentRow.Cells[0].Value);
                                BranchTable b = new BranchTable();
                                var entry = db.Entry(b);
                                b.BranchId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.BranchTable.Attach(b);
                                    db.BranchTable.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}

