﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Branch_Forms
{
    public partial class Transportation_Branch : Form
    {
        public Transportation_Branch()
        {
            InitializeComponent();
        }

        private void Transportation_Branch_Load(object sender, EventArgs e)
        {


            try
            {
                if (LoadProfile.UserType != "System Adminstration")
                {
                    btnAddBranch.Enabled = false;
                }
                refreshbranch();
                refreshtransportation();
                cbBranch.Text = "--Select--";
                cbTransportation.Text = "--Select--";
                FillGrid("");
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cbBranch.Text == "--Select--")
            {
                ep.SetError(btnAddBranch, "Please Select Branch.");
                cbBranch.Focus();
                return;
            }
            if (cbTransportation.Text == "--Select--")
            {
                ep.SetError(btnAddCommunication, "Please Select Transportation.");
                cbTransportation.Focus();
                return;
            }
            if (tbDescription.Text.Length == 0)
            {
                ep.SetError(tbDescription, "Please Enter Description.");
                tbDescription.Focus();
                return;

            }
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var check = db.TransportationsBranch.Where(x => x.BranchId == int.Parse(cbBranch.SelectedValue.ToString()) && x.TransportationId == int.Parse(cbTransportation.SelectedValue.ToString())).FirstOrDefault();
                    if (check != null)
                    {
                        ep.SetError(btnAddBranch, "Already Registered.");
                        btnAddBranch.Focus();
                        return;
                    }
                    TransportationsBranch tb = new TransportationsBranch();
                    tb.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    tb.TransportationId = int.Parse(cbTransportation.SelectedValue.ToString());
                    tb.Description = tbDescription.Text.Trim();
                    db.TransportationsBranch.Add(tb);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                FillGrid("");
                Clear();
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           

        }

        private void Clear()
        {
            cbBranch.Text = "--Select--";
            cbTransportation.Text = "--Select--";
            tbDescription.Text = "";
        }

        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvBranches_TransportationsList.DataSource = (from b in db.TransportationsBranch
                                                                      from c in db.TransportationTable
                                                                      from d in db.BranchTable
                                                                      where c.TransportationId == b.TransportationId && d.BranchId == b.BranchId
                                                      select new
                                                      {
                                                          ID = b.BranchTransportationId,
                                                          BranchName = d.BranchName,
                                                          Transportation = c.TransportationName, 
                                                          Description = b.Description
                                                      }).ToList();
                        dgvBranches_TransportationsList.Columns[0].Width = 100;
                        dgvBranches_TransportationsList.Columns[1].Width = 150;
                        dgvBranches_TransportationsList.Columns[2].Width = 150;
                        dgvBranches_TransportationsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvBranches_TransportationsList.DataSource = (from b in db.TransportationsBranch
                                                                      from c in db.TransportationTable
                                                                      from d in db.BranchTable
                                                                      where c.TransportationId == b.TransportationId && d.BranchId == b.BranchId && d.BranchName.Contains(searchvalue)
                                                                      select new
                                                                      {
                                                                          ID = b.BranchTransportationId,
                                                                          BranchName = d.BranchName,
                                                                          Transportation = c.TransportationName,
                                                                          Description = b.Description
                                                                      }).ToList();
                        dgvBranches_TransportationsList.Columns[0].Width = 100;
                        dgvBranches_TransportationsList.Columns[1].Width = 150;
                        dgvBranches_TransportationsList.Columns[2].Width = 150;
                        dgvBranches_TransportationsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvBranches_TransportationsList.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvBranches_TransportationsList.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvBranches_TransportationsList != null && dgvBranches_TransportationsList.Rows.Count > 0)
            {
                if (dgvBranches_TransportationsList.SelectedRows.Count == 1)
                {
                    cbBranch.Text = Convert.ToString(dgvBranches_TransportationsList.CurrentRow.Cells[1].Value);
                    cbTransportation.Text = Convert.ToString(dgvBranches_TransportationsList.CurrentRow.Cells[2].Value);
                    tbDescription.Text = Convert.ToString(dgvBranches_TransportationsList.CurrentRow.Cells[3].Value);
                    EnableControls();
                }
                else
                {
                    MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvBranches_TransportationsList != null && dgvBranches_TransportationsList.Rows.Count > 0)
            {
                if (dgvBranches_TransportationsList.SelectedRows.Count == 1)
                {
                    if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                        {

                            string ID = Convert.ToString(dgvBranches_TransportationsList.CurrentRow.Cells[0].Value);
                            TransportationsBranch b = new TransportationsBranch();
                            var entry = db.Entry(b);
                            b.BranchTransportationId = int.Parse(ID);
                            if (entry.State == EntityState.Detached)
                            {
                                db.TransportationsBranch.Attach(b);
                                db.TransportationsBranch.Remove(b);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }
                            else
                            {
                                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {

                if (cbBranch.Text == "--Select--")
                {
                    ep.SetError(btnAddBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (cbTransportation.Text == "--Select--")
                {
                    ep.SetError(btnAddCommunication, "Please Select Transportation.");
                    cbTransportation.Focus();
                    return;
                }
                if (tbDescription.Text.Length == 0)
                {
                    ep.SetError(tbDescription, "Please Enter Description.");
                    tbDescription.Focus();
                    return;

                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvBranches_TransportationsList.CurrentRow.Cells[0].Value);
                    var check = db.TransportationsBranch.Where(x => x.BranchId == int.Parse(cbBranch.SelectedValue.ToString()) && x.TransportationId == int.Parse(cbTransportation.SelectedValue.ToString()) && x.BranchTransportationId != int.Parse(ID)).FirstOrDefault();
                    if (check != null)
                    {
                        ep.SetError(btnAddBranch, "Already Registered.");
                        btnAddBranch.Focus();
                        return;
                    }
                    TransportationsBranch tb = new TransportationsBranch();
                    tb.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    tb.TransportationId = int.Parse(cbTransportation.SelectedValue.ToString());
                    tb.Description = tbDescription.Text.Trim();
                    tb.BranchTransportationId = int.Parse(ID);
                    db.TransportationsBranch.Attach(tb);
                    db.Entry(tb).State = EntityState.Modified;
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisableControls();


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddBranch_Click(object sender, EventArgs e)
        {
            Form1 b = new Form1();
            b.ShowDialog();
            refreshbranch();
        }

        private void btnAddCommunication_Click(object sender, EventArgs e)
        {
            Transportation ts = new Transportation();
            ts.ShowDialog();
            refreshtransportation();
        }

        private void btnRefreshBranch_Click(object sender, EventArgs e)
        {

            refreshbranch();
        }

        private void btnRefreshCommunications_Click(object sender, EventArgs e)
        {
            refreshtransportation();
        }

        void refreshbranch()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Branches = (from d in db.BranchTable
                                select new { d.BranchId, d.BranchName })
                                  .ToList();

                cbBranch.DisplayMember = "BranchName";
                cbBranch.ValueMember = "BranchId";
                cbBranch.DataSource = Branches;
                cbBranch.Text = "--Select--";

            }

        }
        void refreshtransportation()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Transportations = (from d in db.TransportationTable
                                       select new { d.TransportationId, d.TransportationName })
                                  .ToList();

                cbTransportation.DisplayMember = "TransportationName";
                cbTransportation.ValueMember = "TransportationId";
                cbTransportation.DataSource = Transportations;
                cbTransportation.Text = "--Select--";

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
