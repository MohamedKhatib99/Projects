﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Branch_Forms
{
    public partial class Transportation : Form
    {
        public Transportation()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {
              
                if (tbtransportation.Text.Trim() == "")
                {
                    ep.SetError(tbtransportation, "Please Enter Branch Address.");
                    tbtransportation.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {

                    var result = db.TransportationTable.Where(x => x.TransportationName.ToLower() == tbtransportation.Text.ToLower())
                                                            .FirstOrDefault();

                    if (result != null)
                    {
                        ep.SetError(tbtransportation, "Already Registered!");
                        tbtransportation.Focus();
                        return;
                    }




                    TransportationTable t = new TransportationTable();
                    t.TransportationName = tbtransportation.Text.Trim();
                    db.TransportationTable.Add(t);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvTransportationsList.DataSource = (from b in db.TransportationTable
                                                             select new
                                                              {
                                                                 ID = b.TransportationId,
                                                                 TransportationName = b.TransportationName
                                                             }).ToList();
                        dgvTransportationsList.Columns[0].Width = 100;
                        dgvTransportationsList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvTransportationsList.DataSource = db.TransportationTable.Where(x => x.TransportationName.Contains(searchvalue))
                                                        .Select(b => new
                                                        {
                                                            ID = b.TransportationId,
                                                            TransportationName = b.TransportationName
                                                          
                                                        })
                                                        .ToList();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clear()
        {
            tbtransportation.Clear();
        }

        private void Transportation_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text.Trim());
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTransportationsList != null && dgvTransportationsList.Rows.Count > 0)
                {
                    if (dgvTransportationsList.SelectedRows.Count == 1)
                    {
                        tbtransportation.Text = Convert.ToString(dgvTransportationsList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

           
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTransportationsList != null && dgvTransportationsList.Rows.Count > 0)
                {
                    if (dgvTransportationsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvTransportationsList.CurrentRow.Cells[0].Value);
                                TransportationTable b = new TransportationTable();
                                var entry = db.Entry(b);
                                b.TransportationId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.TransportationTable.Attach(b);
                                    db.TransportationTable.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            tbtransportation.Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            tbtransportation.Clear();
            DisableControls();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvTransportationsList.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvTransportationsList.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {

                if (tbtransportation.Text.Trim() == "")
                {
                    ep.SetError(tbtransportation, "Please Enter Branch Address.");
                    tbtransportation.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvTransportationsList.CurrentRow.Cells[0].Value);
                    var result = db.TransportationTable.Where(x => x.TransportationName.ToLower() == tbtransportation.Text.ToLower() && x.TransportationId != int.Parse(ID))
                                                            .FirstOrDefault();

                    if(result != null)
                    {
                        ep.SetError(tbtransportation, "Already Registered!");
                        tbtransportation.Focus();
                        return;
                    }
                    

                    TransportationTable b = new TransportationTable();
                    b.TransportationName = tbtransportation.Text.Trim();
                    b.TransportationId = int.Parse(ID);
                    db.TransportationTable.Attach(b);
                    db.Entry(b).State = EntityState.Modified;
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisableControls();


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
