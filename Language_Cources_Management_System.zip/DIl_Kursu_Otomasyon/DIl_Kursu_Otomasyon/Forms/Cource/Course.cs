﻿using DIl_Kursu_Otomasyon.Forms.Course;
using DIl_Kursu_Otomasyon.Forms.Student;
using DIl_Kursu_Otomasyon.Forms.Teachers;
using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Deployment.Internal;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Branch_Forms.Course
{
    public partial class Course : Form
    {
        public Course()
        {
            InitializeComponent();
            cbLevel.SelectedIndex = 0;
            cbDays.SelectedIndex = 0;
            cbhours.SelectedIndex = 0;

        }

        private void Course_Load(object sender, EventArgs e)
        {
            if (LoadProfile.UserType != "System Adminstration")
            {
                btnAddBranch.Enabled = false;
            }
            Refreshbranch();
            FillGrid("");
        }
        void Refreshbranch()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Branches = db.BranchTable.ToList();
                Branches.Add(new BranchTable
                {
                    BranchName = "--Select--"

                });
                Branches.Reverse();
                cbBranch.DisplayMember = "BranchName";
                cbBranch.ValueMember = "BranchId";
                cbBranch.DataSource = Branches;
                cbBranch.Refresh();
            }
        }
        void Refreshlanguages()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
               
                    var language = db.LanguagesTable.ToList();
                    language.Add(new LanguagesTable
                    {
                        LanguageName = "--Select--"

                    });
                    language.Reverse();
                    cbLanguage.DisplayMember = "LanguageName";
                    cbLanguage.ValueMember = "LanguageId";
                    cbLanguage.DataSource = language;

                    cbLanguage.Refresh();
                
                
            }
        }
        void Refreshlevel()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
              
                    var level = db.LevelsTable.ToList();
                    level.Add(new LevelsTable
                    {
                        LevelName = "--Select--"

                    });
                    level.Reverse();
                    cbLevel.DisplayMember = "LevelName";
                    cbLevel.ValueMember = "LevelId";
                    cbLevel.DataSource = level;

                    cbLevel.Refresh();
             
                
            }
        }
        void RefreshRoom()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Rooms = db.ClassRoomInBranch.Where(x => x.Status == "Empty" && x.BranchId == int.Parse(cbBranch.SelectedValue.ToString())).ToList();
                Rooms.Add(new ClassRoomInBranch
                {
                    ClassRoomCode = "--Select--"

                });
                Rooms.Reverse();
                cbRoom.DisplayMember = "ClassRoomCode";
                cbRoom.ValueMember = "ClassRoomId";
                cbRoom.DataSource = Rooms;

                cbRoom.Refresh();
            }
        }
        void RefreshTeacher()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            { 
                var Teacher = (from t in db.TeachersTable
                               from tl in db.TeacherLanguages
                               from tb in db.TeacherBranchs
                               where (t.TeacherId == tb.TeacherId && tb.BranchId == int.Parse(cbBranch.SelectedValue.ToString())) &&
                               ( t.TeacherId == tl.TeacherId && tl.LanguageId == int.Parse(cbLanguage.SelectedValue.ToString()))
                               select t).ToList();

                Teacher.Add(new TeachersTable
                {
                    TeacherName = "--Select--"

                });
                Teacher.Reverse();
                cbTeacher.DisplayMember = "TeacherName";
                cbTeacher.ValueMember = "TeacherId";
                cbTeacher.DataSource = Teacher;
                cbTeacher.Text = "--Select--";
                cbTeacher.Refresh();
            }
        }
        void RefreshWorkingTimes()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                if (cbTeacher.SelectedIndex > 0)
                {
                    var week = (from w in db.WeekDaysHours
                                from t in db.TeachersTable
                                where w.TeacherId == t.TeacherId && t.TeacherName == cbTeacher.Text && w.DayName == cbDays.Text && w.Status == "Free"
                                select w).ToList();

                    week.Add(new WeekDaysHours
                    {
                        Hours = "--Select--"

                    });
                    week.Reverse();
                    cbhours.DisplayMember = "Hours";
                    cbhours.ValueMember = "WeekId";
                    cbhours.DataSource = week;
                    cbhours.Text = "--Select--";
                    cbhours.Refresh();
                }
            }
        }
        private void cbBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refreshlanguages();
            RefreshRoom();
            Refreshlevel();
            Refreshlevel();
        }

        private void cbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refreshlevel();
            RefreshTeacher();

        }

        private void btnRefreshBranch_Click(object sender, EventArgs e)
        {
            Refreshbranch();
        }

        private void btnAddBranch_Click(object sender, EventArgs e)
        {
            Form1 branch = new Form1();
            branch.Show();
            Refreshbranch();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Refreshlanguages();
        }

        private void AddLanguage_Click(object sender, EventArgs e)
        {
            Language l = new Language();
            l.ShowDialog();
            Refreshlanguages();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Refreshlevel();
        }

        private void AddLevel_Click(object sender, EventArgs e)
        {
            Level l = new Level();
            l.ShowDialog();
            Refreshlevel();
        }

        private void AddRoom_Click(object sender, EventArgs e)
        {
            Class_Room cr = new Class_Room();
            cr.ShowDialog();
            RefreshRoom();
        }

        private void refreshRoom_Click(object sender, EventArgs e)
        {
            RefreshRoom();
        }

        private void addteacher_Click(object sender, EventArgs e)
        {
            Teacherfrm t = new Teacherfrm();
            t.ShowDialog();
            RefreshTeacher();
        }

        private void cbDays_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshWorkingTimes();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvCources.DataSource = (from b in db.LessonsTable
                                                 from c in db.BranchTable
                                                 from d in db.TeachersTable
                                                 from f in db.ClassRoomInBranch
                                                 from w in db.WeekDaysHours
                                                 from l in db.LanguagesTable
                                                 from le in db.LevelsTable
                                                 where c.BranchId == b.BranchId && b.TeacherId == d.TeacherId && f.ClassRoomId == b.ClassRoomId && w.WeekId == b.WeekId && b.LanguageId == l.LanguageId && le.LevelId == b.LevelId
                                                  select new
                                                  {
                                                      ID = b.LessonId,
                                                      BranchName = c.BranchName,
                                                      Teacher_FullName = d.TeacherName,
                                                      Room = f.ClassRoomCode,
                                                      Language = l.LanguageName,
                                                      Level = le.LevelName,
                                                      CourceName = b.LessonName,
                                                      Day = b.DayName,
                                                      Time = w.Hours
                                                  }).ToList();
                        dgvCources.Columns[0].Width = 100;
                        dgvCources.Columns[1].Width = 100;
                        dgvCources.Columns[2].Width = 130;
                        dgvCources.Columns[3].Width = 130;
                        dgvCources.Columns[4].Visible = false;
                        dgvCources.Columns[5].Visible = false;
                        dgvCources.Columns[6].Width = 130;
                        dgvCources.Columns[7].Width = 130;
                        dgvCources.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvCources.DataSource = (from b in db.LessonsTable
                                                 from c in db.BranchTable
                                                 from d in db.TeachersTable
                                                 from f in db.ClassRoomInBranch
                                                 from w in db.WeekDaysHours
                                                 from l in db.LanguagesTable
                                                 from le in db.LevelsTable
                                                 where c.BranchId == b.BranchId && b.TeacherId == d.TeacherId && f.ClassRoomId == b.ClassRoomId && w.WeekId == b.WeekId && b.LanguageId == l.LanguageId && le.LevelId == b.LevelId
                                                 && (b.LessonName.Contains(searchvalue) || d.TeacherName.Contains(searchvalue))
                                                 select new
                                                 {
                                                     ID = b.LessonId,
                                                     BranchName = c.BranchName,
                                                     Teacher_FullName = d.TeacherName,
                                                     Room = f.ClassRoomCode,
                                                     Language = l.LanguageName,
                                                     Level = le.LevelName,
                                                     CourceName = b.LessonName,
                                                     Day = b.DayName,
                                                     Time = w.Hours
                                                 }).ToList();
                        dgvCources.Columns[0].Width = 100;
                        dgvCources.Columns[1].Width = 100;
                        dgvCources.Columns[2].Width = 130;
                        dgvCources.Columns[3].Width = 130;
                        dgvCources.Columns[4].Visible = false;
                        dgvCources.Columns[5].Visible = false;
                        dgvCources.Columns[6].Width = 130;
                        dgvCources.Columns[7].Width = 130;
                        dgvCources.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if(cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnAddBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (cbRoom.SelectedIndex == 0)
                {
                    ep.SetError(AddRoom, "Please Select Room.");
                    cbRoom.Focus();
                    return;
                }
                if (cbLanguage.SelectedIndex == 0)
                {
                    ep.SetError(AddLanguage, "Please Select Language.");
                    cbLanguage.Focus();
                    return;
                }
                if (cbLevel.SelectedIndex == 0)
                {
                    ep.SetError(AddLevel, "Please Select Level.");
                    cbLevel.Focus();
                    return;
                }
                if (cbTeacher.SelectedIndex == 0)
                {
                    ep.SetError(addteacher, "Please Select Teacher.");
                    cbTeacher.Focus();
                    return;
                }
                if (cbDays.SelectedIndex == 0)
                {
                    ep.SetError(cbDays, "Please Select Day.");
                    cbDays.Focus();
                    return;
                }
                if (cbhours.SelectedIndex == 0)
                {
                    ep.SetError(cbhours, "Please Select Hours.");
                    cbhours.Focus();
                    return;
                }
                if(tbcourcename.Text.Trim() == "")
                {
                    ep.SetError(tbcourcename, "Please Enter Cource Name");
                    return;
                }
                using(Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var ls = (from x in db.LessonsTable 
                              from y in db.WeekDaysHours
                              where x.BranchId == int.Parse(cbBranch.SelectedValue.ToString()) && x.ClassRoomId == int.Parse(cbRoom.SelectedValue.ToString()) && x.DayName == cbDays.Text && x.WeekId == y.WeekId && y.Hours == cbhours.Text && x.TeacherId != int.Parse(cbTeacher.SelectedValue.ToString())  select x).FirstOrDefault();
                    if(ls != null)
                    {
                        ep.SetError(AddRoom, "This Room Is Busy At the Selected Time");
                        return;
                    }
                    LessonsTable l = new LessonsTable();
                    l.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    l.ClassRoomId = int.Parse(cbRoom.SelectedValue.ToString());
                    l.LanguageId = int.Parse(cbLanguage.SelectedValue.ToString());
                    l.LevelId = int.Parse(cbLevel.SelectedValue.ToString());
                    l.TeacherId = int.Parse(cbTeacher.SelectedValue.ToString());
                    l.DayName = cbDays.Text;
                    l.WeekId = int.Parse(cbhours.SelectedValue.ToString());
                    l.LessonName = tbcourcename.Text.Trim();
                    db.LessonsTable.Add(l);
                    db.SaveChanges();
                    setTimeState("Reserved", int.Parse(cbhours.SelectedValue.ToString()));
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }
        void Clear()
        {
            cbDays.SelectedIndex = 0;
            cbLevel.SelectedIndex = 0;
            cbLanguage.SelectedIndex = 0;
            cbhours.SelectedIndex = 0;
            cbRoom.SelectedIndex = 0;
            cbBranch.SelectedIndex = 0;
            cbTeacher.SelectedIndex = 0;
            tbcourcename.Clear();
            ep.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvCources.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvCources.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            string ID = Convert.ToString(dgvCources.CurrentRow.Cells[0].Value);
            updateLessonTimeState("Reserved", int.Parse(ID));
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCources != null && dgvCources.Rows.Count > 0)
                {
                    if (dgvCources.SelectedRows.Count == 1)
                    {
                        string ID = Convert.ToString(dgvCources.CurrentRow.Cells[0].Value);
                        updateLessonTimeState("Free", int.Parse(ID));
                        cbBranch.Text = Convert.ToString(dgvCources.CurrentRow.Cells[1].Value);
                        cbLanguage.Text = Convert.ToString(dgvCources.CurrentRow.Cells[4].Value);
                        cbTeacher.Text = Convert.ToString(dgvCources.CurrentRow.Cells[2].Value);
                        cbRoom.Text = Convert.ToString(dgvCources.CurrentRow.Cells[3].Value);
                        cbLevel.Text = Convert.ToString(dgvCources.CurrentRow.Cells[5].Value);
                        tbcourcename.Text = Convert.ToString(dgvCources.CurrentRow.Cells[6].Value);
                        cbDays.Text = Convert.ToString(dgvCources.CurrentRow.Cells[7].Value);
                        cbhours.Text = Convert.ToString(dgvCources.CurrentRow.Cells[8].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCources != null && dgvCources.Rows.Count > 0)
                {
                    if (dgvCources.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvCources.CurrentRow.Cells[0].Value);
                                LessonsTable b = new LessonsTable();
                                var entry = db.Entry(b);
                                b.LessonId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.LessonsTable.Attach(b);
                                    db.LessonsTable.Remove(b);
                                    updateLessonTimeState("Free", int.Parse(ID));
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnAddBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (cbRoom.SelectedIndex == 0)
                {
                    ep.SetError(AddRoom, "Please Select Room.");
                    cbRoom.Focus();
                    return;
                }
                if (cbLanguage.SelectedIndex == 0)
                {
                    ep.SetError(AddLanguage, "Please Select Language.");
                    cbLanguage.Focus();
                    return;
                }
                if (cbLevel.SelectedIndex == 0)
                {
                    ep.SetError(AddLevel, "Please Select Level.");
                    cbLevel.Focus();
                    return;
                }
                if (cbTeacher.SelectedIndex == 0)
                {
                    ep.SetError(addteacher, "Please Select Teacher.");
                    cbTeacher.Focus();
                    return;
                }
                if (cbDays.SelectedIndex == 0)
                {
                    ep.SetError(cbDays, "Please Select Day.");
                    cbDays.Focus();
                    return;
                }
                if (cbhours.SelectedIndex == 0)
                {
                    ep.SetError(cbhours, "Please Select Hours.");
                    cbhours.Focus();
                    return;
                }
                if (tbcourcename.Text.Trim() == "")
                {
                    ep.SetError(tbcourcename, "Please Enter Cource Name");
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvCources.CurrentRow.Cells[0].Value);

                    var ls = (from x in db.LessonsTable
                              from y in db.WeekDaysHours
                              where x.BranchId == int.Parse(cbBranch.SelectedValue.ToString()) && x.ClassRoomId == int.Parse(cbRoom.SelectedValue.ToString()) && x.DayName == cbDays.Text && x.WeekId == y.WeekId && y.Hours == cbhours.Text && x.TeacherId != int.Parse(cbTeacher.SelectedValue.ToString()) && x.LessonId != int.Parse(ID)
                              select x).FirstOrDefault();
                    if (ls != null)
                    {
                        ep.SetError(AddRoom, "This Room Is Busy At the Selected Time");
                        return;
                    }
                    LessonsTable l = new LessonsTable();
                    l.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    l.ClassRoomId = int.Parse(cbRoom.SelectedValue.ToString());
                    l.LanguageId = int.Parse(cbLanguage.SelectedValue.ToString());
                    l.LevelId = int.Parse(cbLevel.SelectedValue.ToString());
                    l.TeacherId = int.Parse(cbTeacher.SelectedValue.ToString());
                    l.DayName = cbDays.Text;
                    l.WeekId = int.Parse(cbhours.SelectedValue.ToString());
                    l.LessonName = tbcourcename.Text.Trim();
                    l.LessonId = int.Parse(ID);
                    db.LessonsTable.Attach(l);
                    db.Entry(l).State = EntityState.Modified;
                    db.SaveChanges();
                    setTimeState("Reserved", int.Parse(cbhours.SelectedValue.ToString()));
                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");
                DisableControls();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void setTimeState(string status,int ID)
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                WeekDaysHours w = db.WeekDaysHours.Where(x => x.WeekId == ID).FirstOrDefault();
                w.Status = status;
                db.WeekDaysHours.Update(w);
                db.SaveChanges();
            }
        }
        void updateLessonTimeState(string status,int ID)
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var w = (from x in db.LessonsTable
                         from y in db.WeekDaysHours
                         where x.LessonId == ID && x.WeekId == y.WeekId
                         select y).FirstOrDefault();
                w.Status = status;
                db.WeekDaysHours.Update(w);
                db.SaveChanges();
            }
        }

   

        private void refreshTeacher_Click(object sender, EventArgs e)
        {
            RefreshTeacher();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbhours_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbLevel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbRoom_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbTeacher_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
