﻿using DIl_Kursu_Otomasyon.Forms.Branch_Forms.Course;
using DIl_Kursu_Otomasyon.Forms.Course;
using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Payment_Forms
{
    public partial class Students : Form
    {
        public Students()
        {
            InitializeComponent();
            cbGender.SelectedIndex = 0;
        }


        private void Students_Load(object sender, EventArgs e)
        {
            Refreshbranch();
            FillGrid("");
        }
        void Refreshbranch()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Branches = db.BranchTable.ToList();
                Branches.Add(new BranchTable
                {
                    BranchName = "--Select--"

                });
                Branches.Reverse();
                cbBranch.DisplayMember = "BranchName";
                cbBranch.ValueMember = "BranchId";
                cbBranch.DataSource = Branches;
                cbBranch.Refresh();
            }
        }
        void Refreshlanguages()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {

                var language = db.LanguagesTable.ToList();
                language.Add(new LanguagesTable
                {
                    LanguageName = "--Select--"

                });
                language.Reverse();
                cbLanguage.DisplayMember = "LanguageName";
                cbLanguage.ValueMember = "LanguageId";
                cbLanguage.DataSource = language;

                cbLanguage.Refresh();


            }
        }
        void RefreshCources()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {

                var Cources = db.LessonsTable.Where(x => x.LanguageId == int.Parse(cbLanguage.SelectedValue.ToString()) && x.BranchId == int.Parse(cbBranch.SelectedValue.ToString())).ToList();
                Cources.Add(new LessonsTable
                {
                    LessonName = "--Select--"

                });
                Cources.Reverse();
                cbCource.DisplayMember = "LessonName";
                cbCource.ValueMember = "LessonId";
                cbCource.DataSource = Cources;

                cbCource.Refresh();


            }
        }

        private void cbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshCources();
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvStudents.DataSource = (from x in db.StudentTable
                                                  from b in db.BranchTable
                                                  from l in db.LanguagesTable
                                                  from c in db.LessonsTable
                                                  where x.BranchId == b.BranchId && x.LanguageId == l.LanguageId && x.LessonId == c.LessonId
                                                  select new
                                                  {
                                                      ID = x.StudentId,
                                                      BranchName = b.BranchName,
                                                      FullName = x.StudentName,
                                                      Language = l.LanguageName,
                                                      Cource = c.LessonName,
                                                      Gender = x.Gender,
                                                      GSM = x.Gsm,
                                                      MobilePhone = x.ContactNo,
                                                      Address = x.Address
                                                  }).ToList();
                        dgvStudents.Columns[0].Width = 100;
                        dgvStudents.Columns[1].Width = 100;
                        dgvStudents.Columns[2].Width = 130;
                        dgvStudents.Columns[3].Visible = false;
                        dgvStudents.Columns[4].Width = 130;
                        dgvStudents.Columns[5].Width = 130;
                        dgvStudents.Columns[6].Width = 130;
                        dgvStudents.Columns[7].Width = 130;
                        dgvStudents.Columns[8].Width = 160;
                    }
                    else
                    {
                            dgvStudents.DataSource = (from x in db.StudentTable
                                                      from b in db.BranchTable
                                                      from l in db.LanguagesTable
                                                      from c in db.LessonsTable
                                                      where x.BranchId == b.BranchId && x.LanguageId == l.LanguageId && x.LessonId == c.LessonId && (c.LessonName.Contains(searchvalue) || x.StudentName.Contains(searchvalue))
                                                      select new
                                                      {
                                                          ID = x.StudentId,
                                                          BranchName = b.BranchName,
                                                          FullName = x.StudentName,
                                                          Language = l.LanguageName,
                                                          Cource = c.LessonName,
                                                          Gender = x.Gender,
                                                          GSM = x.Gsm,
                                                          MobilePhone = x.ContactNo,
                                                          Address = x.Address
                                                      }).ToList();
                            dgvStudents.Columns[0].Width = 100;
                            dgvStudents.Columns[1].Width = 100;
                            dgvStudents.Columns[2].Width = 130;
                            dgvStudents.Columns[3].Visible = false;
                            dgvStudents.Columns[4].Width = 130;
                            dgvStudents.Columns[5].Width = 130;
                            dgvStudents.Columns[6].Width = 130;
                            dgvStudents.Columns[7].Width = 130;
                            dgvStudents.Columns[8].Width = 160;
                      
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnRefreshBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (cbLanguage.SelectedIndex == 0)
                {
                    ep.SetError(btnrefreshlanguage, "Please Select Language.");
                    cbLanguage.Focus();
                    return;
                }
                if (cbCource.SelectedIndex == 0)
                {
                    ep.SetError(refreshcource, "Please Select Cource.");
                    cbCource.Focus();
                    return;
                }
                if (tbFullName.Text.Trim() == "")
                {
                    ep.SetError(tbFullName, "Please Enter FullName");
                    tbFullName.Focus();
                    return;
                }
                if (cbGender.SelectedIndex == 0)
                {
                    ep.SetError(cbGender, "Please Select Gender.");
                    cbGender.Focus();
                    return;
                }
                if (tbGsm.Text.Trim().Length == 0)
                {
                    ep.SetError(tbGsm, "Please Enter GSM Number.");
                    tbGsm.Focus();
                    return;
                }
                if (tbMobilePhone.Text.Trim().Length == 0)
                {
                    ep.SetError(tbMobilePhone, "Please Mobile Phone Number.");
                    tbMobilePhone.Focus();
                    return;

                }
                if (tbAddress.Text == "")
                {
                    ep.SetError(tbAddress, "Please Enter Address.");
                    tbAddress.Focus();
                    return;
                }
                using(Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var y = db.StudentTable.Where(x => x.StudentName.ToLower() == tbFullName.Text.Trim().ToLower() && x.ContactNo == tbMobilePhone.Text.Trim() && x.LessonId == int.Parse(cbCource.SelectedValue.ToString())).FirstOrDefault(); 
                    if(y != null)
                    {
                        ep.SetError(cbCource, "You Are Already Enrolled To This Cource!");
                        cbCource.Focus();
                        return;
                    }
                    StudentTable s = new StudentTable();
                    s.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    s.LanguageId = int.Parse(cbLanguage.SelectedValue.ToString());
                    s.LessonId = int.Parse(cbCource.SelectedValue.ToString());
                    s.Gender = cbGender.Text;
                    s.StudentName = tbFullName.Text.Trim();
                    s.Gsm = tbGsm.Text.Trim();
                    s.ContactNo = tbMobilePhone.Text.Trim();
                    s.Address = tbAddress.Text.Trim();
                    db.StudentTable.Add(s);
                    db.SaveChanges();

                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void Clear()
        {
            cbBranch.SelectedIndex = 0;
            cbCource.SelectedIndex = 0;
            cbGender.SelectedIndex = 0;
            cbLanguage.SelectedIndex = 0;
            tbFullName.Clear();
            tbGsm.Clear();
            tbMobilePhone.Clear();
            tbAddress.Clear();
            ep.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvStudents.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvStudents.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvStudents != null && dgvStudents.Rows.Count > 0)
            {
                if (dgvStudents.SelectedRows.Count == 1)
                {
                    if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                        {

                            string ID = Convert.ToString(dgvStudents.CurrentRow.Cells[0].Value);
                            StudentTable b = new StudentTable();
                            var entry = db.Entry(b);
                            b.StudentId = int.Parse(ID);
                            if (entry.State == EntityState.Detached)
                            {
                                db.StudentTable.Attach(b);
                                db.StudentTable.Remove(b);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }
                            else
                            {
                                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvStudents != null && dgvStudents.Rows.Count > 0)
            {
                if (dgvStudents.SelectedRows.Count == 1)
                {
                    cbBranch.Text = Convert.ToString(dgvStudents.CurrentRow.Cells[1].Value);
                    tbFullName.Text = (Convert.ToString(dgvStudents.CurrentRow.Cells[2].Value));
                    cbLanguage.Text = (Convert.ToString(dgvStudents.CurrentRow.Cells[3].Value));
                    cbCource.Text = (Convert.ToString(dgvStudents.CurrentRow.Cells[4].Value));
                    cbGender.Text = Convert.ToString(dgvStudents.CurrentRow.Cells[5].Value);
                    tbGsm.Text = Convert.ToString(dgvStudents.CurrentRow.Cells[6].Value);
                    tbMobilePhone.Text = Convert.ToString(dgvStudents.CurrentRow.Cells[7].Value);
                    tbAddress.Text = Convert.ToString(dgvStudents.CurrentRow.Cells[8].Value);

                    EnableControls();
                }
                else
                {
                    MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {

            try
            {
                ep.Clear();
                if (cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnRefreshBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (cbLanguage.SelectedIndex == 0)
                {
                    ep.SetError(btnrefreshlanguage, "Please Select Language.");
                    cbLanguage.Focus();
                    return;
                }
                if (cbCource.SelectedIndex == 0)
                {
                    ep.SetError(refreshcource, "Please Select Cource.");
                    cbCource.Focus();
                    return;
                }
                if (tbFullName.Text.Trim() == "")
                {
                    ep.SetError(tbFullName, "Please Enter FullName");
                    tbFullName.Focus();
                    return;
                }
                if (cbGender.SelectedIndex == 0)
                {
                    ep.SetError(cbGender, "Please Select Gender.");
                    cbGender.Focus();
                    return;
                }
                if (tbGsm.Text.Trim().Length == 0)
                {
                    ep.SetError(tbGsm, "Please Enter GSM Number.");
                    tbGsm.Focus();
                    return;
                }
                if (tbMobilePhone.Text.Trim().Length == 0)
                {
                    ep.SetError(tbMobilePhone, "Please Mobile Phone Number.");
                    tbMobilePhone.Focus();
                    return;

                }
                if (tbAddress.Text == "")
                {
                    ep.SetError(tbAddress, "Please Enter Address.");
                    tbAddress.Focus();
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvStudents.CurrentRow.Cells[0].Value);
                    var y = db.StudentTable.Where(x => x.StudentName.ToLower() == tbFullName.Text.Trim().ToLower() && x.ContactNo == tbMobilePhone.Text.Trim() && x.LessonId == int.Parse(cbCource.SelectedValue.ToString()) && x.StudentId != int.Parse(ID)).FirstOrDefault();
                    if (y != null)
                    {
                        ep.SetError(cbCource, "You Are Already Enrolled To This Cource!");
                        cbCource.Focus();
                        return;
                    }
                    StudentTable s = db.StudentTable.Where(x => x.StudentId == int.Parse(ID)).FirstOrDefault();
                    s.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    s.LanguageId = int.Parse(cbLanguage.SelectedValue.ToString());
                    s.LessonId = int.Parse(cbCource.SelectedValue.ToString());
                    s.Gender = cbGender.Text;
                    s.StudentName = tbFullName.Text.Trim();
                    s.Gsm = tbGsm.Text.Trim();
                    s.ContactNo = tbMobilePhone.Text.Trim();
                    s.Address = tbAddress.Text.Trim();
                    db.StudentTable.Update(s);
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");
                DisableControls();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddBranch_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.ShowDialog();
            Refreshbranch();
        }

        private void btnRefreshBranch_Click(object sender, EventArgs e)
        {
            Refreshbranch();
        }

        private void btnaddlanguage_Click(object sender, EventArgs e)
        {
            Language l = new Language();
            l.ShowDialog();
            Refreshlanguages();
        }

        private void btnrefreshlanguage_Click(object sender, EventArgs e)
        {
            Refreshlanguages();
        }

        private void btnaddcource_Click(object sender, EventArgs e)
        {

        }

        private void btnrefreshcource_Click(object sender, EventArgs e)
        {
            RefreshCources();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void refreshcource_Click(object sender, EventArgs e)
        {
            RefreshCources();

        }

        private void cbBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refreshlanguages();
        }
    }
}
