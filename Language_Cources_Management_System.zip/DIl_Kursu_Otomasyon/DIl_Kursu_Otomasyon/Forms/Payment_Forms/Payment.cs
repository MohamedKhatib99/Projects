﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Payment_Forms
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
            cbStatus.SelectedIndex = 0;
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            RefreshStudent();
            FillGrid("");
        }
        void RefreshStudent()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {

                var Students = db.StudentTable.ToList();
                Students.Add(new StudentTable
                {
                    StudentName = "--Select--"

                });
                Students.Reverse();
                cbstudents.DisplayMember = "StudentName";
                cbstudents.ValueMember = "StudentId";
                cbstudents.DataSource = Students;

                cbstudents.Refresh();


            }
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvPayments.DataSource = (from x in db.StudentTable
                                                  from c in db.LessonsTable
                                                  from z in db.StudentPayment
                                                  where x.StudentId == z.StudentId && x.LessonId == c.LessonId
                                                  select new
                                                  {
                                                      ID = z.PaymentId,
                                                      StudentName = x.StudentName,
                                                      CourceName = c.LessonName,
                                                      PaymentName = z.PaymentName,
                                                      PaymentType = z.PaymentType,
                                                      Amount = z.PaymentAmount,
                                                      PaymentDate = z.PaymentDate,
                                                      Status = z.PaymentStatus,
                                                  }).ToList();
                        dgvPayments.Columns[0].Width = 100;
                        dgvPayments.Columns[1].Width = 100;
                        dgvPayments.Columns[2].Width = 130;
                        dgvPayments.Columns[3].Width = 130;
                        dgvPayments.Columns[4].Width = 130;
                        dgvPayments.Columns[5].Width = 130;
                        dgvPayments.Columns[6].Width = 130;
                        dgvPayments.Columns[7].Width = 130;
                    }
                    else
                    {
                        dgvPayments.DataSource = (from x in db.StudentTable
                                                  from c in db.LessonsTable
                                                  from z in db.StudentPayment
                                                  where x.StudentId == z.StudentId && x.LessonId == c.LessonId && (x.StudentName.Contains(searchvalue)||c.LessonName.Contains(searchvalue) || z.PaymentStatus.Contains(searchvalue))
                                                  select new
                                                  {
                                                      ID = z.PaymentId,
                                                      StudentName = x.StudentName,
                                                      CourceName = c.LessonName,
                                                      PaymentName = z.PaymentName,
                                                      PaymentType = z.PaymentType,
                                                      Amount = z.PaymentAmount,
                                                      PaymentDate = z.PaymentDate,
                                                      Status = z.PaymentStatus,
                                                  }).ToList();
                        dgvPayments.Columns[0].Width = 100;
                        dgvPayments.Columns[1].Width = 100;
                        dgvPayments.Columns[2].Width = 130;
                        dgvPayments.Columns[3].Width = 130;
                        dgvPayments.Columns[4].Width = 130;
                        dgvPayments.Columns[5].Width = 130;
                        dgvPayments.Columns[6].Width = 130;
                        dgvPayments.Columns[7].Width = 130;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnRefreshStudents_Click(object sender, EventArgs e)
        {
            RefreshStudent();
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            Students s = new Students();
            s.ShowDialog();
            RefreshStudent();
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if(cbstudents.SelectedIndex == 0)
                {
                    ep.SetError(btnAddStudent, "Please Select Student. ");
                    cbstudents.Focus();
                    return;
                }
                if(tbPaymentName.Text == "")
                {
                    ep.SetError(tbPaymentName, "Please Enter Payment Name. ");
                    tbPaymentName.Focus();
                    return;
                }
                if (tbPaymentType.Text == "")
                {
                    ep.SetError(tbPaymentType, "Please Enter Payment Type. ");
                    tbPaymentType.Focus();
                    return;
                }
                if (tbPaymentAmount.Text == "")
                {
                    ep.SetError(tbPaymentAmount, "Please Enter Payment Amount. ");
                    tbPaymentAmount.Focus();
                    return;
                }
                decimal number3 = 0;
                if (!decimal.TryParse(tbPaymentAmount.Text, out number3) || tbPaymentAmount.Text.Contains('-'))
                {
                    ep.SetError(tbPaymentAmount, "Invalid Payment Amount. ");
                    tbPaymentAmount.Focus();
                    return;
                }
                if (cbStatus.SelectedIndex == 0)
                {
                    ep.SetError(cbStatus, "Please Select Payment Status. ");
                    cbStatus.Focus();
                    return;
                }
                using(Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var studentcheck = db.StudentPayment.Where(x => x.StudentId == int.Parse(cbstudents.SelectedValue.ToString()) && x.PaymentName == tbPaymentName.Text.Trim()).FirstOrDefault();
                    if(studentcheck != null)
                    {
                        ep.SetError(tbPaymentName, "Payment Already Exist.");
                        tbPaymentName.Focus();
                        return;
                    }
                    StudentPayment sp = new StudentPayment();
                    sp.StudentId = int.Parse(cbstudents.SelectedValue.ToString());
                    sp.PaymentName = tbPaymentName.Text.Trim();
                    sp.PaymentType = tbPaymentType.Text.Trim();
                    sp.PaymentDate = dtpPaymentDate.Value;
                    sp.PaymentAmount = decimal.Parse(tbPaymentAmount.Text.Trim());
                    sp.PaymentStatus = cbStatus.Text;
                    db.StudentPayment.Add(sp);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void Clear()
        {
            cbStatus.SelectedIndex = 0;
            cbstudents.SelectedIndex = 0;
            tbPaymentAmount.Clear();
            tbPaymentName.Clear();
            tbPaymentType.Clear();
            dtpPaymentDate.Value = DateTime.Now;
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvPayments.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvPayments.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPayments != null && dgvPayments.Rows.Count > 0)
                {
                    if (dgvPayments.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvPayments.CurrentRow.Cells[0].Value);
                                StudentPayment b = new StudentPayment();
                                var entry = db.Entry(b);
                                b.PaymentId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.StudentPayment.Attach(b);
                                    db.StudentPayment.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPayments != null && dgvPayments.Rows.Count > 0)
                {
                    if (dgvPayments.SelectedRows.Count == 1)
                    {
                        tbPaymentAmount.Text = Convert.ToString(dgvPayments.CurrentRow.Cells[5].Value);
                        dtpPaymentDate.Value = DateTime.Parse(Convert.ToString(dgvPayments.CurrentRow.Cells[6].Value));
                        cbStatus.Text = Convert.ToString(dgvPayments.CurrentRow.Cells[7].Value);
                        cbstudents.Text = Convert.ToString(dgvPayments.CurrentRow.Cells[1].Value);
                        tbPaymentName.Text = Convert.ToString(dgvPayments.CurrentRow.Cells[3].Value);
                        tbPaymentType.Text = (Convert.ToString(dgvPayments.CurrentRow.Cells[4].Value));

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cbstudents.SelectedIndex == 0)
                {
                    ep.SetError(btnAddStudent, "Please Select Student. ");
                    cbstudents.Focus();
                    return;
                }
                if (tbPaymentName.Text == "")
                {
                    ep.SetError(tbPaymentName, "Please Enter Payment Name. ");
                    tbPaymentName.Focus();
                    return;
                }
                if (tbPaymentType.Text == "")
                {
                    ep.SetError(tbPaymentType, "Please Enter Payment Type. ");
                    tbPaymentType.Focus();
                    return;
                }
                if (tbPaymentAmount.Text == "")
                {
                    ep.SetError(tbPaymentAmount, "Please Enter Payment Amount. ");
                    tbPaymentAmount.Focus();
                    return;
                }
                decimal number3 = 0;
                if (!decimal.TryParse(tbPaymentAmount.Text, out number3) || tbPaymentAmount.Text.Contains('-'))
                {
                    ep.SetError(tbPaymentAmount, "Invalid Payment Amount. ");
                    tbPaymentAmount.Focus();
                    return;
                }
                if (cbStatus.SelectedIndex == 0)
                {
                    ep.SetError(cbStatus, "Please Select Payment Status. ");
                    cbStatus.Focus();
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvPayments.CurrentRow.Cells[0].Value);
                    var studentcheck = db.StudentPayment.Where(x => x.StudentId == int.Parse(cbstudents.SelectedValue.ToString()) && x.PaymentName == tbPaymentName.Text.Trim() && x.PaymentId != int.Parse(ID)).FirstOrDefault();
                    if (studentcheck != null)
                    {
                        ep.SetError(tbPaymentName, "Payment Already Exist.");
                        tbPaymentName.Focus();
                        return;
                    }
                    StudentPayment sp = new StudentPayment();
                    sp.StudentId = int.Parse(cbstudents.SelectedValue.ToString());
                    sp.PaymentName = tbPaymentName.Text.Trim();
                    sp.PaymentType = tbPaymentType.Text.Trim();
                    sp.PaymentDate = dtpPaymentDate.Value;
                    sp.PaymentAmount = decimal.Parse(tbPaymentAmount.Text.Trim());
                    sp.PaymentStatus = cbStatus.Text;
                    sp.PaymentId = int.Parse(ID);
                    db.Entry(sp).State = EntityState.Modified;
                    db.SaveChanges();
                    DisableControls();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }
    }
}
