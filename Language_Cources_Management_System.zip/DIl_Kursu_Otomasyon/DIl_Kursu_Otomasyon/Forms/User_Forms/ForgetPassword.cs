﻿using DIl_Kursu_Otomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.User_Forms
{
    public partial class ForgetPassword : Form
    {
        Login login;
        public ForgetPassword(Login login)
        {
            InitializeComponent();
            cbGender.SelectedIndex = 0;
            this.login = login;
        }

        private void ForgetPassword_Load(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ep.Clear();
           
            if (tbFullName.Text.Length == 0)
            {
                ep.SetError(tbFullName, "Please Enter Your Full Name.");
                tbFullName.Focus();
                return;

            }

            if (tbFullName.Text.Length < 5 || tbFullName.Text.Length > 50)
            {
                ep.SetError(tbFullName, "Full Name Must Be Between 5 And 50 Characters.");
                tbFullName.Focus();
                return;

            }
            if (cbGender.SelectedIndex == 0)
            {
                ep.SetError(cbGender, "Please Select Gender.");
                cbGender.Focus();
                return;
            }
            if (tbContactNo.Text == "")
            {
                ep.SetError(tbContactNo, "Please Enter Your Contact No.");
                tbContactNo.Focus();
                return;

            }
            if (tbContactNo.Text.Length < 5 || tbContactNo.Text.Length > 20)
            {
                ep.SetError(tbContactNo, "Contact No Must Be Between 5 And 20 Characters.");
                tbContactNo.Focus();
                return;

            }
            if (tbEmail.Text == "")
            {
                ep.SetError(tbEmail, "Please Enter Your Email!");
                tbEmail.Focus();
                return;

            }
            if (!tbEmail.Text.Contains('@'))
            {
                ep.SetError(tbEmail, "Wrong Email Format.");
                tbEmail.Focus();
                return;
            }
            if (tbEmail.Text.Length < 8 || tbEmail.Text.Length > 50)
            {
                ep.SetError(tbEmail, "Email Must Be Between 8 And 50 Characters.");
                tbEmail.Focus();
                return;
            }
            if (tbAddress.Text == "")
            {
                ep.SetError(tbAddress, "Please Enter Your Address.");
                tbAddress.Focus();
                return;

            }

            if (tbUserName.Text == "")
            {
                ep.SetError(tbUserName, "Please Enter Your User Name.");
                tbUserName.Focus();
                return;

            }
            if (tbUserName.Text.Length < 5 || tbUserName.Text.Length > 50)
            {
                ep.SetError(tbUserName, "User Name Must Be Between 5 And 50 Characters.");
                tbUserName.Focus();
                return;

            }
            if (tbPassword.Text.Trim() == "")
            {
                ep.SetError(tbPassword, "Please Enter Your Password.");
                tbPassword.Focus();
                return;

            }
            
           
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    UsersTable user = db.UsersTable.Where(x => x.FullName.ToLower() == tbFullName.Text.Trim().ToLower() && x.Email.ToLower() == tbEmail.Text.Trim().ToLower() && x.ContactNo.ToLower() == tbContactNo.Text.Trim().ToLower() &&
                    x.Gender == cbGender.Text && x.Address.ToLower() == tbAddress.Text.ToLower() && x.UserName.ToLower() == tbUserName.Text.Trim().ToLower()).FirstOrDefault();
                    if(user != null)
                    {
                        if(user.Password == tbPassword.Text.Trim() || (user.Password.Contains(tbPassword.Text.Trim()) && tbPassword.Text.Trim().Length > 6))
                        {
                            ResetNow r = new ResetNow(user,this);
                            r.ShowDialog();
                        }

                    }
                    else
                    {
                        MessageBox.Show("User Not Found!,Check your Information Again.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
                Clear();
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        void Clear()
        {

            cbGender.SelectedIndex = 0;
            tbFullName.Clear();
            tbEmail.Clear();
            tbContactNo.Clear();
            tbAddress.Clear();
            tbUserName.Clear();
            tbPassword.Clear();
            ep.Clear();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            login.Show();
        }
    }
}
