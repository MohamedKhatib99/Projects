﻿using DIl_Kursu_Otomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.User_Forms
{
    public partial class Login : Form
    {
        private MainForm mainForm;
        private Label welcome;
        private Label lbl1;
        public Login()
        {
            InitializeComponent();
        }

        public Login(MainForm mainForm, Label lblwelcome, Label lbl1)
        {
            InitializeComponent();
            this.mainForm = mainForm;
            this.welcome = lblwelcome;
            this.lbl1 = lbl1;

        }

      

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            ep.Clear();
            lblerror.Visible = false;
            if (tbUserName.Text.Trim().Length == 0)
            {
                ep.SetError(tbUserName, "Please Enter User Name!");
                tbUserName.Focus();
                return;
            }
            if (tbPassword.Text.Trim().Length == 0)
            {
                ep.SetError(tbPassword, "Please Enter Password!");
                tbPassword.Focus();
                return;
            }
            if (tbPassword.Text.Trim().Length < 8)
            {
                ep.SetError(tbPassword, "Password Must Be At Least 8 Characters!");
                tbPassword.Focus();
                return;
            }
            UsersTable u = new UsersTable();
            bool result = u.login(tbUserName.Text.Trim(), tbPassword.Text.Trim());
            if (result)
            {
                mainForm.tsblogin.Visible = false;
                mainForm.tsblogout.Visible = true;
                mainForm.msAll.Enabled = true;
                this.lbl1.Location = new System.Drawing.Point(10, 8);
                welcome.Text = "Welcome, " + LoadProfile.FullName + " !";
                if (LoadProfile.UserType == "Employee")
                {
                    mainForm.BranchesToolStripMenuItem.Enabled = false;
                    mainForm.CourcesToolStripMenuItem.Enabled = false;
                    mainForm.userSettingToolStripMenuItem.Enabled = false;
                    mainForm.teachersSettingsToolStripMenuItem.Enabled = false;

                }
                else if (LoadProfile.UserType == "Branch Manager")
                {
                    mainForm.BranchesInfoToolStripMenuItem.Enabled = false;
                }
                this.Close();
                return;
            }
            else
            {
                lblerror.Visible = true;
                mainForm.tsblogin.Visible = true;
                mainForm.tsblogout.Visible = false;
                mainForm.msAll.Enabled = false;
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ForgetPassword forget = new ForgetPassword(this);
            forget.ShowDialog();
        }
    }
}
