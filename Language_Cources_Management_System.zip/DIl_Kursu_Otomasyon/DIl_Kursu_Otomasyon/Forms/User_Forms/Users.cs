﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.User_Forms
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
        }

        private void Users_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvUsers.DataSource = (from b in db.UsersTable
                                               from c  in db.BranchTable
                                               where b.BranchId == c.BranchId
                                                  select new
                                                  {
                                                      ID = b.UserId,
                                                      Branch = c.BranchName,
                                                      UserName = b.UserName,
                                                      Password = b.Password,
                                                      AccessType = b.UserType,
                                                      FullName = b.FullName,
                                                      Gender = b.Gender,
                                                      Email = b.Email,
                                                      MobilePhone = b.ContactNo,
                                                      Address = b.Address   
                                                  }).ToList();
                        dgvUsers.Columns[0].Width = 100;
                        dgvUsers.Columns[1].Width = 130;
                        dgvUsers.Columns[2].Width = 130;
                        dgvUsers.Columns[3].Visible = false;
                        dgvUsers.Columns[4].Width = 130;
                        dgvUsers.Columns[5].Width = 130;
                        dgvUsers.Columns[6].Width = 130;
                        dgvUsers.Columns[7].Width = 130;
                        dgvUsers.Columns[8].Width = 130;
                        dgvUsers.Columns[9].Width = 130;
                    }
                    else
                    {
                        dgvUsers.DataSource = (from b in db.UsersTable
                                               from c in db.BranchTable
                                               where b.BranchId == c.BranchId && (b.UserName.Contains(searchvalue) ||b.FullName.Contains(searchvalue))
                                               select new
                                               {
                                                   ID = b.UserId,
                                                   Branch = c.BranchName,
                                                   UserName = b.UserName,
                                                   Password = b.Password,
                                                   AccessType = b.UserType,
                                                   FullName = b.FullName,
                                                   Gender = b.Gender,
                                                   Email = b.Email,
                                                   MobilePhone = b.ContactNo,
                                                   Address = b.Address
                                               }).ToList();
                        dgvUsers.Columns[0].Width = 100;
                        dgvUsers.Columns[1].Width = 130;
                        dgvUsers.Columns[2].Width = 130;
                        dgvUsers.Columns[3].Visible = false;
                        dgvUsers.Columns[4].Width = 130;
                        dgvUsers.Columns[5].Width = 130;
                        dgvUsers.Columns[6].Width = 130;
                        dgvUsers.Columns[7].Width = 130;
                        dgvUsers.Columns[8].Width = 130;
                        dgvUsers.Columns[9].Width = 130;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            AddUser user = new AddUser();
            user.ShowDialog();
            FillGrid("");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvUsers != null && dgvUsers.Rows.Count > 0)
                {
                    if (dgvUsers.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvUsers.CurrentRow.Cells[0].Value);
                                string accesstype = Convert.ToString(dgvUsers.CurrentRow.Cells[4].Value);
                                if (LoadProfile.UserId == int.Parse(ID) )
                                {
                                    MessageBox.Show("You can't delete yourself !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                                if (LoadProfile.UserType != "System Adminstration" && accesstype !="Employee") 
                                {
                                    MessageBox.Show("You can't delete an system adminstrator or an branch manager !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                                UsersTable b = new UsersTable();
                                var entry = db.Entry(b);
                                b.UserId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.UsersTable.Attach(b);
                                    db.UsersTable.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }

                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            string ID = Convert.ToString(dgvUsers.CurrentRow.Cells[0].Value);
            UpdateAllUsers update = new UpdateAllUsers(ID);
            update.ShowDialog();
            FillGrid("");
        }
    }
}
