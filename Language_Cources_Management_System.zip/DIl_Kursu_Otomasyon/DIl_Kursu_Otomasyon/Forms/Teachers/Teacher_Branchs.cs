﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Teachers
{
    public partial class Teacher_Branchs : Form
    {
        public Teacher_Branchs()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (Teachers.SelectedItems.Count <= 0 || Branchs.SelectedItems.Count <= 0)
                {

                    return;
                }
                if (Teachers.SelectedIndex == 0)
                {
                    ep.SetError(Teachers, "Please Select Teacher !");
                    Teachers.Focus();
                    return;

                }
                if (Branchs.SelectedIndex == 0 && Branchs.SelectedItems.Count == 1)
                {
                    ep.SetError(Branchs, "Please Select Branch !");
                    Branchs.Focus();
                    return;
                }
                if (Branchs.SelectedItems.Count > 1 && Branchs.SelectedIndex == 0)
                {
                    ep.SetError(Branchs, "Invalid Branchs Selection !");
                    Branchs.Focus();
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var lan = db.TeacherBranchs.ToList();
                    foreach (BranchTable L in Branchs.SelectedItems)
                    {
                        int teacherID = int.Parse(Teachers.SelectedValue.ToString());

                        foreach (TeacherBranchs Tl in lan)
                        {
                            if (Tl.TeacherId == teacherID && Tl.BranchId == L.BranchId)
                            {

                                ep.SetError(Branchs, "One Or More Branches Already Registered,Please Check Your Selections.");
                                Branchs.Focus();
                                return;
                            }
                        }

                        TeacherBranchs tl = new TeacherBranchs();
                        tl.BranchId = L.BranchId;
                        tl.TeacherId = teacherID;
                        db.TeacherBranchs.Add(tl);

                    }
                    db.SaveChanges();
                    Clear();

                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                FillGrid("");


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Teacher_Branchs_Load(object sender, EventArgs e)
        {
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {

                    var teacher = db.TeachersTable.ToList();
                    teacher.Add(new TeachersTable
                    {
                        TeacherName = "--Select Teacher--"

                    });
                    teacher.Reverse();
                    Teachers.DisplayMember = "TeacherName";
                    Teachers.ValueMember = "TeacherId";
                    Teachers.DataSource = teacher;
                    Teachers.Refresh();

                    var Branch = db.BranchTable.ToList();
                    Branch.Add(new BranchTable
                    {
                        BranchName = "--Select Branchs--"

                    });
                    Branch.Reverse();
                    Branchs.DisplayMember = "BranchName";
                    Branchs.ValueMember = "BranchId";
                    Branchs.DataSource = Branch;

                    Branchs.Refresh();
                    FillGrid("");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvTeachersBranchs.DataSource = (from b in db.TeacherBranchs
                                                           from c in db.TeachersTable
                                                           from d in db.BranchTable
                                                           where b.BranchId == d.BranchId && b.TeacherId == c.TeacherId
                                                           select new
                                                           {
                                                               ID = b.TeacherBranchId,
                                                               TeacherName = c.TeacherName,
                                                               Branch = d.BranchName,

                                                           }).ToList();
                        dgvTeachersBranchs.Columns[0].Width = 100;
                        dgvTeachersBranchs.Columns[1].Width = 200;
                        dgvTeachersBranchs.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvTeachersBranchs.DataSource = (from b in db.TeacherBranchs
                                                         from c in db.TeachersTable
                                                         from d in db.BranchTable
                                                         where b.BranchId == d.BranchId && b.TeacherId == c.TeacherId && c.TeacherName.Contains(searchvalue)
                                                           select new
                                                           {
                                                               ID = b.TeacherBranchId,
                                                               TeacherName = c.TeacherName,
                                                               Branch = d.BranchName,

                                                           }).ToList();
                        dgvTeachersBranchs.Columns[0].Width = 100;
                        dgvTeachersBranchs.Columns[1].Width = 200;
                        dgvTeachersBranchs.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (Teachers.SelectedItems.Count <= 0 || Branchs.SelectedItems.Count <= 0)
                {

                    return;
                }
                if (Teachers.SelectedIndex == 0)
                {
                    ep.SetError(Teachers, "Please Select Teacher !");
                    Teachers.Focus();
                    return;

                }
                if (Branchs.SelectedIndex == 0 && Branchs.SelectedItems.Count == 1)
                {
                    ep.SetError(Branchs, "Please Select Branch !");
                    Branchs.Focus();
                    return;
                }
                if (Branchs.SelectedItems.Count > 1 && Branchs.SelectedIndex == 0)
                {
                    ep.SetError(Branchs, "Invalid Branchs Selection !");
                    Branchs.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {

                    string ID = Convert.ToString(dgvTeachersBranchs.CurrentRow.Cells[0].Value);
                    int BranchID = int.Parse(Branchs.SelectedValue.ToString());
                    int teacherID = int.Parse(Teachers.SelectedValue.ToString());
                    var lan = db.TeacherBranchs.Where(x => x.BranchId == BranchID && x.TeacherId == teacherID && x.TeacherBranchId != int.Parse(ID)).FirstOrDefault();
                    if (lan != null)
                    {
                        ep.SetError(Branchs, "Language Already Registered!");
                        Branchs.Focus();
                        return;
                    }
                    TeacherBranchs tl = new TeacherBranchs();
                    tl.BranchId = BranchID;
                    tl.TeacherId = teacherID;
                    tl.TeacherBranchId = int.Parse(ID);
                    db.TeacherBranchs.Attach(tl);
                    db.Entry(tl).State = EntityState.Modified;
                    db.SaveChanges();
                }


                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableControls();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvTeachersBranchs.Enabled = false;
            tbsearch.Enabled = false;
            Branchs.SelectionMode = SelectionMode.One;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvTeachersBranchs.Enabled = true;
            tbsearch.Enabled = true;
            Branchs.SelectionMode = SelectionMode.MultiExtended;
            FillGrid("");
            Clear();

        }
        void Clear()
        {
            Branchs.ClearSelected();
            Branchs.SelectedIndex = 0;
            Teachers.SelectedIndex = 0;
            ep.Clear();
        }
        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvTeachersBranchs != null && dgvTeachersBranchs.Rows.Count > 0)
            {
                if (dgvTeachersBranchs.SelectedRows.Count == 1)
                {
                    Branchs.ClearSelected();
                    Teachers.Text = Convert.ToString(dgvTeachersBranchs.CurrentRow.Cells[1].Value);
                    Branchs.Text = Convert.ToString(dgvTeachersBranchs.CurrentRow.Cells[2].Value);
                    EnableControls();

                }
                else
                {
                    MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (dgvTeachersBranchs != null && dgvTeachersBranchs.Rows.Count > 0)
            {
                if (dgvTeachersBranchs.SelectedRows.Count == 1)
                {
                    if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                        {

                            string ID = Convert.ToString(dgvTeachersBranchs.CurrentRow.Cells[0].Value);
                            TeacherBranchs b = new TeacherBranchs();
                            var entry = db.Entry(b);
                            b.TeacherBranchId = int.Parse(ID);
                            if (entry.State == EntityState.Detached)
                            {
                                db.TeacherBranchs.Attach(b);
                                db.TeacherBranchs.Remove(b);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }
                            else
                            {
                                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
