﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Teachers
{
    public partial class Teachers_Work_Days : Form
    {
        
        public Teachers_Work_Days()
        {
            InitializeComponent();
            cbStatus.SelectedIndex = 0;
            cbDays.SelectedIndex = 0;

        }

        private void Teachers_Work_Days_Load(object sender, EventArgs e)
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {

                var teacher = db.TeachersTable.ToList();
                teacher.Add(new TeachersTable
                {
                    TeacherName = "--Select--"

                });
                teacher.Reverse();
                cbTeacher.DisplayMember = "TeacherName";
                cbTeacher.ValueMember = "TeacherId";
                cbTeacher.DataSource = teacher;
                cbTeacher.Refresh();
            }
            FillGrid("");
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvDaysWorkHoursList.DataSource = (from b in db.WeekDaysHours
                                                           from t in db.TeachersTable
                                                           where b.TeacherId == t.TeacherId
                                                   select new
                                                   {
                                                       ID = b.WeekId,
                                                       TeacherName = t.TeacherName,
                                                       Day = b.DayName,
                                                       Hours = b.Hours,
                                                       Status = b.Status
                                                   }).ToList();
                        dgvDaysWorkHoursList.Columns[0].Width = 100;
                        dgvDaysWorkHoursList.Columns[1].Width = 100;
                        dgvDaysWorkHoursList.Columns[2].Width = 100;
                        dgvDaysWorkHoursList.Columns[3].Width = 100;
                        dgvDaysWorkHoursList.Columns[4].Width = 150;
                    }
                    else
                    {
                        dgvDaysWorkHoursList.DataSource = (from b in db.WeekDaysHours
                                                           from t in db.TeachersTable
                                                           where b.TeacherId == t.TeacherId && t.TeacherName.Contains(searchvalue) 
                                                           select new
                                                           {
                                                               ID = b.WeekId,
                                                               TeacherName = t.TeacherName,
                                                               Day = b.DayName,
                                                               Hours = b.Hours,
                                                               Status = b.Status
                                                           }).ToList();
                        dgvDaysWorkHoursList.Columns[0].Width = 100;
                        dgvDaysWorkHoursList.Columns[1].Width = 100;
                        dgvDaysWorkHoursList.Columns[2].Width = 100;
                        dgvDaysWorkHoursList.Columns[3].Width = 100;
                        dgvDaysWorkHoursList.Columns[4].Width = 150;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnAddTeacher_Click(object sender, EventArgs e)
        {
            Teacherfrm t = new Teacherfrm();
            t.ShowDialog();
            
        }

        private void btnRefreshTeacher_Click(object sender, EventArgs e)
        {
            Teachers_Work_Days_Load(sender, e);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if(cbAll.Checked == true)
            {
                cb1.Checked = true;
                cb2.Checked = true;
                cb3.Checked = true;
                cb4.Checked = true;
                cb5.Checked = true;
                cb6.Checked = true;
                cb7.Checked = true;

            }
            else
            {
                cb1.Checked = false;
                cb2.Checked = false;
                cb3.Checked = false;
                cb4.Checked = false;
                cb5.Checked = false;
                cb6.Checked = false;
                cb7.Checked = false;
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if(cbTeacher.SelectedIndex == 0)
                {
                    ep.SetError(btnAddTeacher, "Please Select Teacher.");
                    cbTeacher.Focus();
                    return;
                }
                if (cbDays.SelectedIndex == 0)
                {
                    ep.SetError(cbDays, "Please Select Day.");
                    cbDays.Focus();
                    return;
                }
                if (cb1.Checked == false && cb2.Checked == false && cb3.Checked == false && cb4.Checked == false && cb5.Checked == false && cb6.Checked == false && cb7.Checked == false)
                {
                    ep.SetError(cb4, "Please Select Hours.");
                    return;
                }
                if (cbStatus.SelectedIndex == 0)
                {
                    ep.SetError(cbStatus, "Please Select Status.");
                    cbStatus.Focus();
                    return;
                }
                using(Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    List<string> hours = new List<string>();
                    if(cb1.Checked == true)
                    {
                        hours.Add(cb1.Text);
                    }
                    if (cb2.Checked == true)
                    {
                        hours.Add(cb2.Text);

                    }
                    if (cb3.Checked == true)
                    {
                        hours.Add(cb3.Text);
                    }
                    if (cb4.Checked == true)
                    {
                        hours.Add(cb4.Text);
                    }
                    if (cb5.Checked == true)
                    {
                        hours.Add(cb5.Text);
                    }
                    if (cb6.Checked == true)
                    {
                        hours.Add(cb6.Text);
                    }
                    if (cb7.Checked == true)
                    {
                        hours.Add(cb7.Text);

                    }
                    foreach (var hour in hours)
                    {
                        WeekDaysHours w = new WeekDaysHours();
                        w.TeacherId = int.Parse(cbTeacher.SelectedValue.ToString());
                        w.DayName = cbDays.Text;
                        w.Status = cbStatus.Text;
                        w.Hours = hour;
                        db.WeekDaysHours.Add(w);
                        
                    }
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        void Clear()
        {
            cbAll.Checked = true;
            cbAll.Checked = false;
            cbTeacher.SelectedIndex = 0;
            cbDays.SelectedIndex = 0;
            cbStatus.SelectedIndex = 0;
        }
        private void EnableControls()
        {

            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvDaysWorkHoursList.Enabled = false;
            tbsearch.Enabled = false;
        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvDaysWorkHoursList.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (dgvDaysWorkHoursList != null && dgvDaysWorkHoursList.Rows.Count > 0)
            {
                if (dgvDaysWorkHoursList.SelectedRows.Count == 1)
                {
                    if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                        {

                            string ID = Convert.ToString(dgvDaysWorkHoursList.CurrentRow.Cells[0].Value);
                            WeekDaysHours b = new WeekDaysHours();
                            var entry = db.Entry(b);
                            b.WeekId = int.Parse(ID);
                            if (entry.State == EntityState.Detached)
                            {
                                db.WeekDaysHours.Attach(b);
                                db.WeekDaysHours.Remove(b);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }
                            else
                            {
                                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvDaysWorkHoursList != null && dgvDaysWorkHoursList.Rows.Count > 0)
            {
                if (dgvDaysWorkHoursList.SelectedRows.Count == 1)
                {
                    cbTeacher.Text = Convert.ToString(dgvDaysWorkHoursList.CurrentRow.Cells[1].Value);
                    cbDays.Text = Convert.ToString(dgvDaysWorkHoursList.CurrentRow.Cells[2].Value);
                    string hour = Convert.ToString(dgvDaysWorkHoursList.CurrentRow.Cells[3].Value);
                    cbStatus.Text = Convert.ToString(dgvDaysWorkHoursList.CurrentRow.Cells[4].Value);
                    switch (hour)
                    {
                        case "8:30-10:30":
                            cb1.Checked = true;
                            break;
                        case "10:30-11:30":
                            cb2.Checked = true;
                            break;
                        case "12:30-14:30":
                            cb3.Checked = true;
                            break;
                        case "14:30-15:30":
                            cb4.Checked = true;
                            break;
                        case "16:30-18:30":
                            cb5.Checked = true;
                            break;
                        case "18:30-19:30":
                            cb6.Checked = true;
                            break;
                        case "20:30-22:30":
                            cb7.Checked = true;
                            break;
                        default:
                         break;
                    }
                    EnableControls();

                }
                else
                {
                    MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cbTeacher.SelectedIndex == 0)
                {
                    ep.SetError(btnAddTeacher, "Please Select Teacher.");
                    cbTeacher.Focus();
                    return;
                }
                if (cbDays.SelectedIndex == 0)
                {
                    ep.SetError(cbDays, "Please Select Day.");
                    cbDays.Focus();
                    return;
                }
                if (cb1.Checked == false && cb2.Checked == false && cb3.Checked == false && cb4.Checked == false && cb5.Checked == false && cb6.Checked == false && cb7.Checked == false)
                {
                    ep.SetError(cb4, "Please Select Hours.");
                    return;
                }
                if (cbStatus.SelectedIndex == 0)
                {
                    ep.SetError(cbStatus, "Please Select Status.");
                    cbStatus.Focus();
                    return;
                }
                string hour = null;
                int i = 0;
                if (cb1.Checked == true)
                {
                    hour = cb1.Text;
                    i++;
                }
                if (cb2.Checked == true)
                {
                    hour = cb2.Text;
                    i++;

                }
                if (cb3.Checked == true)
                {
                    hour = cb3.Text;
                    i++;
                }
                if (cb4.Checked == true)
                {
                    hour = cb4.Text;
                    i++;

                }
                if (cb5.Checked == true)
                {
                    hour = cb5.Text;
                    i++;

                }
                if (cb6.Checked == true)
                {
                    hour = cb6.Text;
                    i++;

                }
                if (cb7.Checked == true)
                {
                    hour = cb7.Text;
                    i++;

                }
                if (i>1)
                {
                    ep.SetError(cb4, "Please Select Part of Time.");
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    
                    WeekDaysHours w = new WeekDaysHours();
                    string ID = Convert.ToString(dgvDaysWorkHoursList.CurrentRow.Cells[0].Value);
                    w.TeacherId = int.Parse(cbTeacher.SelectedValue.ToString());
                    w.DayName = cbDays.Text;
                    w.Status = cbStatus.Text;
                    w.Hours = hour;
                    w.WeekId = int.Parse(ID);
                    db.WeekDaysHours.Attach(w);
                    db.Entry(w).State = EntityState.Modified;
                    db.SaveChanges();
                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");
                DisableControls();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
