﻿using DIl_Kursu_Otomasyon.Forms.Course;
using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Teachers
{
    public partial class Teacher_Languages : Form
    {
        public Teacher_Languages()
        {
            InitializeComponent();
        }

        private void Teacher_Languages_Load(object sender, EventArgs e)
        {
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {

                    var teacher = db.TeachersTable.ToList();
                    teacher.Add(new TeachersTable
                    {
                        TeacherName = "--Select Teacher--"

                    });
                    teacher.Reverse();
                    Teachers.DisplayMember = "TeacherName";
                    Teachers.ValueMember = "TeacherId";
                    Teachers.DataSource = teacher;
                    Teachers.Refresh();

                    var language = db.LanguagesTable.ToList();
                    language.Add(new LanguagesTable { 
                        LanguageName = "--Select Languages--"
                        
                    });
                    language.Reverse();
                    languages.DisplayMember = "LanguageName";
                    languages.ValueMember = "LanguageId";
                    languages.DataSource = language;

                    languages.Refresh();
                    FillGrid("");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvTeachersLanguages.DataSource = (from b in db.TeacherLanguages
                                                                      from c in db.TeachersTable
                                                                      from d in db.LanguagesTable
                                                                      where b.LanguageId == d.LanguageId && b.TeacherId == c.TeacherId
                                                                      select new
                                                                      {
                                                                          ID = b.TeacherLanguageId,
                                                                          TeacherName = c.TeacherName,
                                                                          Language = d.LanguageName,
                                                                          
                                                                      }).ToList();
                        dgvTeachersLanguages.Columns[0].Width = 100;
                        dgvTeachersLanguages.Columns[1].Width = 200;
                        dgvTeachersLanguages.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvTeachersLanguages.DataSource = (from b in db.TeacherLanguages
                                                           from c in db.TeachersTable
                                                           from d in db.LanguagesTable
                                                           where b.LanguageId == d.LanguageId && b.TeacherId == c.TeacherId && c.TeacherName.Contains(searchvalue) 
                                                           select new
                                                           {
                                                               ID = b.TeacherLanguageId,
                                                               TeacherName = c.TeacherName,
                                                               Language = d.LanguageName,

                                                           }).ToList();
                        dgvTeachersLanguages.Columns[0].Width = 100;
                        dgvTeachersLanguages.Columns[1].Width = 200;
                        dgvTeachersLanguages.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (Teachers.SelectedItems.Count <= 0 || languages.SelectedItems.Count <= 0)
                {
                    
                    return;
                }
                if(Teachers.SelectedIndex == 0)
                {
                    ep.SetError(Teachers, "Please Select Teacher !");
                    Teachers.Focus();
                    return;

                }
                if (languages.SelectedIndex == 0 && languages.SelectedItems.Count == 1)
                {
                    ep.SetError(languages, "Please Select Language !");
                    languages.Focus();
                    return;
                }
                if (languages.SelectedItems.Count > 1 && languages.SelectedIndex == 0)
                {
                    ep.SetError(languages, "Invalid Languages Selection !");
                    languages.Focus();
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var lan = db.TeacherLanguages.ToList();
                    foreach (LanguagesTable L in languages.SelectedItems)
                    {
                        int teacherID = int.Parse(Teachers.SelectedValue.ToString());

                        foreach (TeacherLanguages Tl in lan)
                        {
                            if(Tl.TeacherId == teacherID && Tl.LanguageId == L.LanguageId)
                            {

                                ep.SetError(languages, "One Or More Languages Already Registered,Please Check Your Selections.");
                                languages.Focus();
                                return;
                            }
                        }
                    
                        TeacherLanguages tl = new TeacherLanguages();
                        tl.LanguageId = L.LanguageId;
                        tl.TeacherId = teacherID;
                        db.TeacherLanguages.Add(tl);
                        
                    }
                    db.SaveChanges();
                    Clear();

                }
                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                FillGrid("");


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvTeachersLanguages != null && dgvTeachersLanguages.Rows.Count > 0)
            {
                if (dgvTeachersLanguages.SelectedRows.Count == 1)
                {
                    if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                        {

                            string ID = Convert.ToString(dgvTeachersLanguages.CurrentRow.Cells[0].Value);
                            TeacherLanguages b = new TeacherLanguages();
                            var entry = db.Entry(b);
                            b.TeacherLanguageId = int.Parse(ID);
                            if (entry.State == EntityState.Detached)
                            {
                                db.TeacherLanguages.Attach(b);
                                db.TeacherLanguages.Remove(b);
                                db.SaveChanges();
                                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                FillGrid("");

                            }
                            else
                            {
                                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();

        }
        void Clear()
        {
            languages.ClearSelected();
            languages.SelectedIndex = 0;
            Teachers.SelectedIndex = 0;
            ep.Clear();
        }
        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvTeachersLanguages != null && dgvTeachersLanguages.Rows.Count > 0)
            {
                if (dgvTeachersLanguages.SelectedRows.Count == 1)
                {
                    languages.ClearSelected();
                    Teachers.Text = Convert.ToString(dgvTeachersLanguages.CurrentRow.Cells[1].Value);
                    languages.Text = Convert.ToString(dgvTeachersLanguages.CurrentRow.Cells[2].Value);
                    EnableControls();
                    
                }
                else
                {
                    MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvTeachersLanguages.Enabled = false;
            tbsearch.Enabled = false;
            languages.SelectionMode = SelectionMode.One;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvTeachersLanguages.Enabled = true;
            tbsearch.Enabled = true;
            languages.SelectionMode = SelectionMode.MultiExtended;
            FillGrid("");
            Clear();

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }



        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (Teachers.SelectedItems.Count <= 0 || languages.SelectedItems.Count <= 0)
                {

                    return;
                }
                if (Teachers.SelectedIndex == 0)
                {
                    ep.SetError(Teachers, "Please Select Teacher !");
                    Teachers.Focus();
                    return;

                }
                if (languages.SelectedIndex == 0 && languages.SelectedItems.Count == 1)
                {
                    ep.SetError(languages, "Please Select Language !");
                    languages.Focus();
                    return;
                }
                if (languages.SelectedItems.Count > 1 && languages.SelectedIndex == 0)
                {
                    ep.SetError(languages, "Invalid Languages Selection !");
                    languages.Focus();
                    return;
                }
               
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {

                    string ID = Convert.ToString(dgvTeachersLanguages.CurrentRow.Cells[0].Value);
                    int LanguageID = int.Parse(languages.SelectedValue.ToString());
                    int teacherID = int.Parse(Teachers.SelectedValue.ToString());
                    var lan = db.TeacherLanguages.Where(x => x.LanguageId == LanguageID && x.TeacherId == teacherID && x.TeacherLanguageId != int.Parse(ID)).FirstOrDefault();
                    if(lan != null)
                    {
                        ep.SetError(languages, "Language Already Registered!");
                        languages.Focus();
                        return;
                    }
                    TeacherLanguages tl = new TeacherLanguages();
                    tl.LanguageId = LanguageID;
                    tl.TeacherId = teacherID;
                    tl.TeacherLanguageId = int.Parse(ID);
                    db.TeacherLanguages.Attach(tl);
                    db.Entry(tl).State = EntityState.Modified;
                    db.SaveChanges();
                }
                

                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableControls();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
