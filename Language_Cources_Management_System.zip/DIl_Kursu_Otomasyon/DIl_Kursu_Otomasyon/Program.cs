﻿using System;
using System.Windows.Forms;
using DIl_Kursu_Otomasyon.Forms.Branch_Forms;
using DIl_Kursu_Otomasyon.Forms.Branch_Forms.Course;
using DIl_Kursu_Otomasyon.Forms.Payment_Forms;
using DIl_Kursu_Otomasyon.Forms.Teachers;
using DIl_Kursu_Otomasyon.Forms.User_Forms;
using DIl_Kursu_Otomasyon.Model;

namespace DIl_Kursu_Otomasyon
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
