﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class LanguagesTable
    {
        public LanguagesTable()
        {
            LessonsTable = new HashSet<LessonsTable>();
            StudentTable = new HashSet<StudentTable>();
            TeacherLanguages = new HashSet<TeacherLanguages>();
        }

        public int LanguageId { get; set; }
        public string LanguageName { get; set; }

        public virtual ICollection<LessonsTable> LessonsTable { get; set; }
        public virtual ICollection<StudentTable> StudentTable { get; set; }
        public virtual ICollection<TeacherLanguages> TeacherLanguages { get; set; }
    }
}
