﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class CommunicationsBranch
    {
        public int BranchCoomunicationId { get; set; }
        public int BranchId { get; set; }
        public int CommunicationId { get; set; }
        public string Description { get; set; }

        public virtual BranchTable Branch { get; set; }
        public virtual CommunicationTable Communication { get; set; }
    }
}
