﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class ClassRoomInBranch
    {
        public ClassRoomInBranch()
        {
            LessonsTable = new HashSet<LessonsTable>();
        }

        public int ClassRoomId { get; set; }
        public int BranchId { get; set; }
        public string ClassRoomCode { get; set; }
        public string Status { get; set; }

        public virtual BranchTable Branch { get; set; }
        public virtual ICollection<LessonsTable> LessonsTable { get; set; }
    }
}
