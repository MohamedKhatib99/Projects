﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class TeachersTable
    {
        public TeachersTable()
        {
            LessonsTable = new HashSet<LessonsTable>();
            TeacherBranchs = new HashSet<TeacherBranchs>();
            TeacherLanguages = new HashSet<TeacherLanguages>();
            WeekDaysHours = new HashSet<WeekDaysHours>();
        }

        public int TeacherId { get; set; }
        public string TeacherName { get; set; }
        public string Gender { get; set; }
        public string Gsm { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public DateTime StartingDate { get; set; }

        public virtual ICollection<LessonsTable> LessonsTable { get; set; }
        public virtual ICollection<TeacherBranchs> TeacherBranchs { get; set; }
        public virtual ICollection<TeacherLanguages> TeacherLanguages { get; set; }
        public virtual ICollection<WeekDaysHours> WeekDaysHours { get; set; }
    }
}
