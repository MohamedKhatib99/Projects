﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class UsersTable
    {
        public int UserId { get; set; }
        public int BranchId { get; set; }
        public string UserType { get; set; }
        public string FullName { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

        public virtual BranchTable Branch { get; set; }


        public bool login(string username, string password)
        {
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var result = db.UsersTable.Where(x => x.UserName.ToLower() == username.ToLower() && x.Password == password).FirstOrDefault();
                    if (result != null)
                    {
                        LoadProfile.UserId = result.UserId;
                        LoadProfile.BranchId = result.BranchId;
                        LoadProfile.UserType = result.UserType;
                        LoadProfile.FullName = result.FullName;
                        LoadProfile.Gender = result.Gender;
                        LoadProfile.Email = result.Email;
                        LoadProfile.ContactNo = result.ContactNo;
                        LoadProfile.Address = result.Address;
                        LoadProfile.UserName = result.UserName;
                        LoadProfile.Password = result.Password;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


        }

    }
}
