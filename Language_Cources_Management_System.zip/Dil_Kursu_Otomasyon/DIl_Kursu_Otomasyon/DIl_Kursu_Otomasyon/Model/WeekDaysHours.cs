﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class WeekDaysHours
    {
        public WeekDaysHours()
        {
            LessonsTable = new HashSet<LessonsTable>();
        }

        public int WeekId { get; set; }
        public int TeacherId { get; set; }
        public string DayName { get; set; }
        public string Hours { get; set; }
        public string Status { get; set; }

        public virtual TeachersTable Teacher { get; set; }
        public virtual ICollection<LessonsTable> LessonsTable { get; set; }
    }
}
