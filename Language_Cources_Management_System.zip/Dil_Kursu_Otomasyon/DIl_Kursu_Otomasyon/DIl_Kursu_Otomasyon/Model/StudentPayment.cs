﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class StudentPayment
    {
        public int PaymentId { get; set; }
        public int StudentId { get; set; }
        public string PaymentName { get; set; }
        public string PaymentType { get; set; }
        public decimal PaymentAmount { get; set; }
        public DateTime PaymentDate { get; set; }
        public string PaymentStatus { get; set; }

        public virtual StudentTable Student { get; set; }
    }
}
