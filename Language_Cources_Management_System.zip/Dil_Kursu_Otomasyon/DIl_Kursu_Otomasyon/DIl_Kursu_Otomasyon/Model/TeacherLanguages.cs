﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class TeacherLanguages
    {
        public int TeacherLanguageId { get; set; }
        public int TeacherId { get; set; }
        public int LanguageId { get; set; }

        public virtual LanguagesTable Language { get; set; }
        public virtual TeachersTable Teacher { get; set; }
    }
}
