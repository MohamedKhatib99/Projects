﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class TransportationTable
    {
        public int TransportationId { get; set; }
        public string TransportationName { get; set; }

        public virtual TransportationsBranch TransportationsBranch { get; set; }
    }
}
