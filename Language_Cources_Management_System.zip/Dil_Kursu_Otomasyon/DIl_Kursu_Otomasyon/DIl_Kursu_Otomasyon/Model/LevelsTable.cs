﻿using System;
using System.Collections.Generic;

namespace DIl_Kursu_Otomasyon.Model
{
    public partial class LevelsTable
    {
        public LevelsTable()
        {
            LessonsTable = new HashSet<LessonsTable>();
        }

        public int LevelId { get; set; }
        public string LevelName { get; set; }

        public virtual ICollection<LessonsTable> LessonsTable { get; set; }
    }
}
