﻿namespace DIl_Kursu_Otomasyon
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblwelcome = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.msAll = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.BranchesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suppliersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BranchesInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTransportationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTransportationsToBranchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addRoomToBranchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCommunicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCommunicationsToBranchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CourcesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.courseActionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCourseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addLevelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addLanguageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.userSettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUserTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teachersSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTeacherToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addLanguagesToTeacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addBranchsToTeacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teachersWorkingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Login = new System.Windows.Forms.ToolStrip();
            this.tsblogin = new System.Windows.Forms.ToolStripButton();
            this.tsblogout = new System.Windows.Forms.ToolStripSplitButton();
            this.UpdateProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.msAll.SuspendLayout();
            this.Login.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 1285);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(2, 0, 17, 0);
            this.statusStrip1.Size = new System.Drawing.Size(2371, 39);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(144, 30);
            this.toolStripStatusLabel1.Text = "          Ready...";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lblwelcome);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.lbl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2371, 162);
            this.panel1.TabIndex = 56;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblwelcome
            // 
            this.lblwelcome.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblwelcome.AutoSize = true;
            this.lblwelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwelcome.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblwelcome.Location = new System.Drawing.Point(12, 83);
            this.lblwelcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblwelcome.Name = "lblwelcome";
            this.lblwelcome.Size = new System.Drawing.Size(0, 42);
            this.lblwelcome.TabIndex = 32;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.SteelBlue;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(2269, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 90);
            this.button1.TabIndex = 31;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl1
            // 
            this.lbl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl1.Location = new System.Drawing.Point(17, 54);
            this.lbl1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(168, 59);
            this.lbl1.TabIndex = 19;
            this.lbl1.Text = "Home";
            // 
            // msAll
            // 
            this.msAll.BackColor = System.Drawing.Color.AliceBlue;
            this.msAll.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.msAll.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.msAll.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.msAll.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.BranchesToolStripMenuItem,
            this.CourcesToolStripMenuItem,
            this.settingsToolStripMenuItem1});
            this.msAll.Location = new System.Drawing.Point(0, 162);
            this.msAll.Name = "msAll";
            this.msAll.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.msAll.Size = new System.Drawing.Size(2371, 40);
            this.msAll.TabIndex = 57;
            this.msAll.Text = "msAll";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem2,
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.fileToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.SteelBlue;
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(101, 36);
            this.fileToolStripMenuItem.Text = "Home";
            // 
            // logoutToolStripMenuItem2
            // 
            this.logoutToolStripMenuItem2.BackColor = System.Drawing.Color.AliceBlue;
            this.logoutToolStripMenuItem2.ForeColor = System.Drawing.Color.SteelBlue;
            this.logoutToolStripMenuItem2.Name = "logoutToolStripMenuItem2";
            this.logoutToolStripMenuItem2.Size = new System.Drawing.Size(216, 40);
            this.logoutToolStripMenuItem2.Text = "Logout";
            this.logoutToolStripMenuItem2.Click += new System.EventHandler(this.logoutToolStripMenuItem2_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.BackColor = System.Drawing.Color.AliceBlue;
            this.exitToolStripMenuItem1.ForeColor = System.Drawing.Color.SteelBlue;
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(216, 40);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // BranchesToolStripMenuItem
            // 
            this.BranchesToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.BranchesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.suppliersToolStripMenuItem});
            this.BranchesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BranchesToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.BranchesToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.SteelBlue;
            this.BranchesToolStripMenuItem.Name = "BranchesToolStripMenuItem";
            this.BranchesToolStripMenuItem.Size = new System.Drawing.Size(136, 36);
            this.BranchesToolStripMenuItem.Text = "Branches";
            // 
            // suppliersToolStripMenuItem
            // 
            this.suppliersToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.suppliersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BranchesInfoToolStripMenuItem,
            this.addTransportationToolStripMenuItem,
            this.addTransportationsToBranchToolStripMenuItem,
            this.addRoomToBranchToolStripMenuItem,
            this.addCommunicationToolStripMenuItem,
            this.addCommunicationsToBranchToolStripMenuItem});
            this.suppliersToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.suppliersToolStripMenuItem.Name = "suppliersToolStripMenuItem";
            this.suppliersToolStripMenuItem.Size = new System.Drawing.Size(307, 40);
            this.suppliersToolStripMenuItem.Text = "Branchs Action";
            // 
            // BranchesInfoToolStripMenuItem
            // 
            this.BranchesInfoToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.BranchesInfoToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.BranchesInfoToolStripMenuItem.Name = "BranchesInfoToolStripMenuItem";
            this.BranchesInfoToolStripMenuItem.Size = new System.Drawing.Size(583, 40);
            this.BranchesInfoToolStripMenuItem.Text = "Branches Information";
            this.BranchesInfoToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // addTransportationToolStripMenuItem
            // 
            this.addTransportationToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addTransportationToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addTransportationToolStripMenuItem.Name = "addTransportationToolStripMenuItem";
            this.addTransportationToolStripMenuItem.Size = new System.Drawing.Size(583, 40);
            this.addTransportationToolStripMenuItem.Text = "Transportations Information";
            this.addTransportationToolStripMenuItem.Click += new System.EventHandler(this.addTransportationToolStripMenuItem_Click);
            // 
            // addTransportationsToBranchToolStripMenuItem
            // 
            this.addTransportationsToBranchToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addTransportationsToBranchToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addTransportationsToBranchToolStripMenuItem.Name = "addTransportationsToBranchToolStripMenuItem";
            this.addTransportationsToBranchToolStripMenuItem.Size = new System.Drawing.Size(583, 40);
            this.addTransportationsToBranchToolStripMenuItem.Text = "Branches Transportation Information";
            this.addTransportationsToBranchToolStripMenuItem.Click += new System.EventHandler(this.addTransportationsToBranchToolStripMenuItem_Click);
            // 
            // addRoomToBranchToolStripMenuItem
            // 
            this.addRoomToBranchToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addRoomToBranchToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addRoomToBranchToolStripMenuItem.Name = "addRoomToBranchToolStripMenuItem";
            this.addRoomToBranchToolStripMenuItem.Size = new System.Drawing.Size(583, 40);
            this.addRoomToBranchToolStripMenuItem.Text = "Branchs Rooms Information";
            this.addRoomToBranchToolStripMenuItem.Click += new System.EventHandler(this.addRoomToBranchToolStripMenuItem_Click);
            // 
            // addCommunicationToolStripMenuItem
            // 
            this.addCommunicationToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addCommunicationToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addCommunicationToolStripMenuItem.Name = "addCommunicationToolStripMenuItem";
            this.addCommunicationToolStripMenuItem.Size = new System.Drawing.Size(583, 40);
            this.addCommunicationToolStripMenuItem.Text = "Communications Information";
            this.addCommunicationToolStripMenuItem.Click += new System.EventHandler(this.addCommunicationToolStripMenuItem_Click);
            // 
            // addCommunicationsToBranchToolStripMenuItem
            // 
            this.addCommunicationsToBranchToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addCommunicationsToBranchToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addCommunicationsToBranchToolStripMenuItem.Name = "addCommunicationsToBranchToolStripMenuItem";
            this.addCommunicationsToBranchToolStripMenuItem.Size = new System.Drawing.Size(583, 40);
            this.addCommunicationsToBranchToolStripMenuItem.Text = "Branches Communications Information";
            this.addCommunicationsToBranchToolStripMenuItem.Click += new System.EventHandler(this.addCommunicationsToBranchToolStripMenuItem_Click);
            // 
            // CourcesToolStripMenuItem
            // 
            this.CourcesToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.CourcesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.courseActionsToolStripMenuItem});
            this.CourcesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourcesToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.CourcesToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.SteelBlue;
            this.CourcesToolStripMenuItem.Name = "CourcesToolStripMenuItem";
            this.CourcesToolStripMenuItem.Size = new System.Drawing.Size(123, 36);
            this.CourcesToolStripMenuItem.Text = "Courses";
            // 
            // courseActionsToolStripMenuItem
            // 
            this.courseActionsToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.courseActionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCourseToolStripMenuItem,
            this.addLevelToolStripMenuItem,
            this.addLanguageToolStripMenuItem});
            this.courseActionsToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.courseActionsToolStripMenuItem.Name = "courseActionsToolStripMenuItem";
            this.courseActionsToolStripMenuItem.Size = new System.Drawing.Size(307, 40);
            this.courseActionsToolStripMenuItem.Text = "Course Actions";
            // 
            // addCourseToolStripMenuItem
            // 
            this.addCourseToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addCourseToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addCourseToolStripMenuItem.Name = "addCourseToolStripMenuItem";
            this.addCourseToolStripMenuItem.Size = new System.Drawing.Size(402, 40);
            this.addCourseToolStripMenuItem.Text = "Courses Information";
            this.addCourseToolStripMenuItem.Click += new System.EventHandler(this.addCourseToolStripMenuItem_Click);
            // 
            // addLevelToolStripMenuItem
            // 
            this.addLevelToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addLevelToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addLevelToolStripMenuItem.Name = "addLevelToolStripMenuItem";
            this.addLevelToolStripMenuItem.Size = new System.Drawing.Size(402, 40);
            this.addLevelToolStripMenuItem.Text = "Levels Information";
            this.addLevelToolStripMenuItem.Click += new System.EventHandler(this.addLevelToolStripMenuItem_Click);
            // 
            // addLanguageToolStripMenuItem
            // 
            this.addLanguageToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addLanguageToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addLanguageToolStripMenuItem.Name = "addLanguageToolStripMenuItem";
            this.addLanguageToolStripMenuItem.Size = new System.Drawing.Size(402, 40);
            this.addLanguageToolStripMenuItem.Text = "Languages Information";
            this.addLanguageToolStripMenuItem.Click += new System.EventHandler(this.addLanguageToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem1
            // 
            this.settingsToolStripMenuItem1.BackColor = System.Drawing.Color.AliceBlue;
            this.settingsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userSettingToolStripMenuItem,
            this.teachersSettingsToolStripMenuItem,
            this.studentSettingsToolStripMenuItem});
            this.settingsToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsToolStripMenuItem1.ForeColor = System.Drawing.Color.SteelBlue;
            this.settingsToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.AliceBlue;
            this.settingsToolStripMenuItem1.Name = "settingsToolStripMenuItem1";
            this.settingsToolStripMenuItem1.Size = new System.Drawing.Size(125, 36);
            this.settingsToolStripMenuItem1.Text = "Settings";
            // 
            // userSettingToolStripMenuItem
            // 
            this.userSettingToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.userSettingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addUserTypeToolStripMenuItem});
            this.userSettingToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.userSettingToolStripMenuItem.Name = "userSettingToolStripMenuItem";
            this.userSettingToolStripMenuItem.Size = new System.Drawing.Size(332, 40);
            this.userSettingToolStripMenuItem.Text = "User Setting";
            // 
            // addUserTypeToolStripMenuItem
            // 
            this.addUserTypeToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addUserTypeToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addUserTypeToolStripMenuItem.Name = "addUserTypeToolStripMenuItem";
            this.addUserTypeToolStripMenuItem.Size = new System.Drawing.Size(342, 40);
            this.addUserTypeToolStripMenuItem.Text = "Users Information";
            this.addUserTypeToolStripMenuItem.Click += new System.EventHandler(this.addUserTypeToolStripMenuItem_Click);
            // 
            // teachersSettingsToolStripMenuItem
            // 
            this.teachersSettingsToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.teachersSettingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTeacherToolStripMenuItem1,
            this.addLanguagesToTeacherToolStripMenuItem,
            this.addBranchsToTeacherToolStripMenuItem,
            this.teachersWorkingToolStripMenuItem});
            this.teachersSettingsToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.teachersSettingsToolStripMenuItem.Name = "teachersSettingsToolStripMenuItem";
            this.teachersSettingsToolStripMenuItem.Size = new System.Drawing.Size(332, 40);
            this.teachersSettingsToolStripMenuItem.Text = "Teachers Settings";
            // 
            // addTeacherToolStripMenuItem1
            // 
            this.addTeacherToolStripMenuItem1.BackColor = System.Drawing.Color.AliceBlue;
            this.addTeacherToolStripMenuItem1.ForeColor = System.Drawing.Color.SteelBlue;
            this.addTeacherToolStripMenuItem1.Name = "addTeacherToolStripMenuItem1";
            this.addTeacherToolStripMenuItem1.Size = new System.Drawing.Size(524, 40);
            this.addTeacherToolStripMenuItem1.Text = "Teachers Information";
            this.addTeacherToolStripMenuItem1.Click += new System.EventHandler(this.addTeacherToolStripMenuItem1_Click);
            // 
            // addLanguagesToTeacherToolStripMenuItem
            // 
            this.addLanguagesToTeacherToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addLanguagesToTeacherToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addLanguagesToTeacherToolStripMenuItem.Name = "addLanguagesToTeacherToolStripMenuItem";
            this.addLanguagesToTeacherToolStripMenuItem.Size = new System.Drawing.Size(524, 40);
            this.addLanguagesToTeacherToolStripMenuItem.Text = "Teachers Language Information";
            this.addLanguagesToTeacherToolStripMenuItem.Click += new System.EventHandler(this.addLanguagesToTeacherToolStripMenuItem_Click);
            // 
            // addBranchsToTeacherToolStripMenuItem
            // 
            this.addBranchsToTeacherToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.addBranchsToTeacherToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.addBranchsToTeacherToolStripMenuItem.Name = "addBranchsToTeacherToolStripMenuItem";
            this.addBranchsToTeacherToolStripMenuItem.Size = new System.Drawing.Size(524, 40);
            this.addBranchsToTeacherToolStripMenuItem.Text = "Teachers Branch Information";
            this.addBranchsToTeacherToolStripMenuItem.Click += new System.EventHandler(this.addBranchsToTeacherToolStripMenuItem_Click);
            // 
            // teachersWorkingToolStripMenuItem
            // 
            this.teachersWorkingToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.teachersWorkingToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.teachersWorkingToolStripMenuItem.Name = "teachersWorkingToolStripMenuItem";
            this.teachersWorkingToolStripMenuItem.Size = new System.Drawing.Size(524, 40);
            this.teachersWorkingToolStripMenuItem.Text = "Teachers Schedualing Information";
            this.teachersWorkingToolStripMenuItem.Click += new System.EventHandler(this.teachersWorkingToolStripMenuItem_Click);
            // 
            // studentSettingsToolStripMenuItem
            // 
            this.studentSettingsToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.studentSettingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentToolStripMenuItem,
            this.paymentToolStripMenuItem1});
            this.studentSettingsToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.studentSettingsToolStripMenuItem.Name = "studentSettingsToolStripMenuItem";
            this.studentSettingsToolStripMenuItem.Size = new System.Drawing.Size(332, 40);
            this.studentSettingsToolStripMenuItem.Text = "Student Settings";
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.studentToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(485, 40);
            this.studentToolStripMenuItem.Text = "Students Information";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.studentToolStripMenuItem_Click);
            // 
            // paymentToolStripMenuItem1
            // 
            this.paymentToolStripMenuItem1.BackColor = System.Drawing.Color.AliceBlue;
            this.paymentToolStripMenuItem1.ForeColor = System.Drawing.Color.SteelBlue;
            this.paymentToolStripMenuItem1.Name = "paymentToolStripMenuItem1";
            this.paymentToolStripMenuItem1.Size = new System.Drawing.Size(485, 40);
            this.paymentToolStripMenuItem1.Text = "Students Payment Information";
            this.paymentToolStripMenuItem1.Click += new System.EventHandler(this.paymentToolStripMenuItem1_Click);
            // 
            // Login
            // 
            this.Login.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.Login.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsblogin,
            this.tsblogout});
            this.Login.Location = new System.Drawing.Point(0, 202);
            this.Login.Name = "Login";
            this.Login.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
            this.Login.Size = new System.Drawing.Size(2371, 72);
            this.Login.TabIndex = 58;
            this.Login.Text = "tsAll";
            // 
            // tsblogin
            // 
            this.tsblogin.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsblogin.Image = ((System.Drawing.Image)(resources.GetObject("tsblogin.Image")));
            this.tsblogin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsblogin.Name = "tsblogin";
            this.tsblogin.Size = new System.Drawing.Size(68, 66);
            this.tsblogin.Text = "Login";
            this.tsblogin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsblogin.ToolTipText = "Login";
            this.tsblogin.Click += new System.EventHandler(this.tsblogin_Click);
            // 
            // tsblogout
            // 
            this.tsblogout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsblogout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UpdateProfileToolStripMenuItem,
            this.logOutToolStripMenuItem1});
            this.tsblogout.Image = global::DIl_Kursu_Otomasyon.Properties.Resources.iconfinder_Exit_132037;
            this.tsblogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsblogout.Name = "tsblogout";
            this.tsblogout.Size = new System.Drawing.Size(102, 66);
            this.tsblogout.Text = "Logout";
            this.tsblogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsblogout.ToolTipText = "Logout";
            this.tsblogout.Visible = false;
            this.tsblogout.ButtonClick += new System.EventHandler(this.tsblogout_ButtonClick);
            // 
            // UpdateProfileToolStripMenuItem
            // 
            this.UpdateProfileToolStripMenuItem.BackColor = System.Drawing.Color.AliceBlue;
            this.UpdateProfileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateProfileToolStripMenuItem.ForeColor = System.Drawing.Color.SteelBlue;
            this.UpdateProfileToolStripMenuItem.Name = "UpdateProfileToolStripMenuItem";
            this.UpdateProfileToolStripMenuItem.Size = new System.Drawing.Size(298, 40);
            this.UpdateProfileToolStripMenuItem.Text = "Update Profile";
            this.UpdateProfileToolStripMenuItem.Click += new System.EventHandler(this.UpdateProfileToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem1
            // 
            this.logOutToolStripMenuItem1.BackColor = System.Drawing.Color.AliceBlue;
            this.logOutToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutToolStripMenuItem1.ForeColor = System.Drawing.Color.SteelBlue;
            this.logOutToolStripMenuItem1.Name = "logOutToolStripMenuItem1";
            this.logOutToolStripMenuItem1.Size = new System.Drawing.Size(298, 40);
            this.logOutToolStripMenuItem1.Text = "Logout";
            this.logOutToolStripMenuItem1.Click += new System.EventHandler(this.logOutToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(172, 40);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(210, 40);
            this.logOutToolStripMenuItem.Text = "Logout";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::DIl_Kursu_Otomasyon.Properties.Resources.logo_laci_png;
            this.pictureBox1.Location = new System.Drawing.Point(964, 418);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(522, 506);
            this.pictureBox1.TabIndex = 59;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2371, 1324);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.msAll);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.msAll.ResumeLayout(false);
            this.msAll.PerformLayout();
            this.Login.ResumeLayout(false);
            this.Login.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl1;
        public System.Windows.Forms.MenuStrip msAll;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suppliersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTransportationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTransportationsToBranchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addRoomToBranchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCommunicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCommunicationsToBranchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem courseActionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCourseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addLevelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addLanguageToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addUserTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTeacherToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addLanguagesToTeacherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addBranchsToTeacherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teachersWorkingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem1;
        public System.Windows.Forms.ToolStrip Login;
        public System.Windows.Forms.ToolStripButton tsblogin;
        public System.Windows.Forms.ToolStripSplitButton tsblogout;
        private System.Windows.Forms.ToolStripMenuItem UpdateProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem1;
        private System.Windows.Forms.Label lblwelcome;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem BranchesToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem CourcesToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem userSettingToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem teachersSettingsToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem BranchesInfoToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}