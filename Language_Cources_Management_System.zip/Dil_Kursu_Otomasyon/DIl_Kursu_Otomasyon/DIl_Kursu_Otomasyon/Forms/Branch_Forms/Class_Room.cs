﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Branch_Forms
{
    public partial class Class_Room : Form
    {
        public Class_Room()
        {
            InitializeComponent();
            cbStatus.SelectedIndex = 0;
        }

        private void Class_Room_Load(object sender, EventArgs e)
        {
            if (LoadProfile.UserType != "System Adminstration")
            {
                btnAddBranch.Enabled = false;
            }
            refreshbranch();
            FillGrid("");
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvRoomsList.DataSource = (from b in db.ClassRoomInBranch
                                                   from c in db.BranchTable
                                                   where c.BranchId == b.BranchId
                                                   select new
                                                      {
                                                          ID = b.ClassRoomId,
                                                          Branch = c.BranchName,
                                                          RoomCode = b.ClassRoomCode,
                                                          Status = b.Status
                                                      }).ToList();
                        dgvRoomsList.Columns[0].Width = 100;
                        dgvRoomsList.Columns[1].Width = 150;
                        dgvRoomsList.Columns[2].Width = 150;
                        dgvRoomsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvRoomsList.DataSource = (from b in db.ClassRoomInBranch
                                                   from c in db.BranchTable
                                                   where c.BranchId == b.BranchId && c.BranchName.Contains(searchvalue)
                                                   select new
                                                   {
                                                       ID = b.ClassRoomId,
                                                       Branch = c.BranchName,
                                                       RoomCode = b.ClassRoomCode,
                                                       Status = b.Status
                                                   }).ToList();
                        dgvRoomsList.Columns[0].Width = 100;
                        dgvRoomsList.Columns[1].Width = 150;
                        dgvRoomsList.Columns[2].Width = 150;
                        dgvRoomsList.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnAddBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (tbRoomCode.Text.Length == 0)
                {
                    ep.SetError(tbRoomCode, "Please Enter Room Code.");
                    tbRoomCode.Focus();
                    return;

                }
                if (cbStatus.SelectedIndex == 0)
                {
                    ep.SetError(cbStatus, "Please Select Room Status.");
                    cbStatus.Focus();
                    return;
                }


                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var query = (from a in db.ClassRoomInBranch
                                 from d in db.BranchTable
                                 where d.BranchId == a.BranchId
                                 select new
                                 {
                                     ID = a.ClassRoomId,
                                     code = a.ClassRoomCode,
                                     branch = d.BranchName
                                 }).ToList();
                    foreach (var item in query)
                    {

                        if ( item.branch.ToUpper() == cbBranch.Text.Trim().ToUpper() && item.code == tbRoomCode.Text)
                        {
                            ep.SetError(btnAddBranch, "Already Registered!");
                            cbBranch.Focus();
                            return;
                        }
                    }
                    ClassRoomInBranch c = new ClassRoomInBranch();
                    c.BranchId= int.Parse(cbBranch.SelectedValue.ToString());
                    c.ClassRoomCode = tbRoomCode.Text.Trim();
                    c.Status = cbStatus.Text.Trim();
                    db.ClassRoomInBranch.Add(c);

                    db.SaveChanges();

                MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Clear()
        {
            cbBranch.Text = "--Select--";
            cbStatus.SelectedIndex = 0;
            tbRoomCode.Text = "";
            ep.Clear();
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvRoomsList.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvRoomsList.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }
        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvRoomsList != null && dgvRoomsList.Rows.Count > 0)
                {
                    if (dgvRoomsList.SelectedRows.Count == 1)
                    {
                        cbBranch.Text = Convert.ToString(dgvRoomsList.CurrentRow.Cells[1].Value);
                        cbStatus.Text = Convert.ToString(dgvRoomsList.CurrentRow.Cells[3].Value);
                        tbRoomCode.Text = Convert.ToString(dgvRoomsList.CurrentRow.Cells[2].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            
        }

        private void btncancel_Click(object sender, EventArgs e)
        {

            Clear();
            DisableControls();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvRoomsList != null && dgvRoomsList.Rows.Count > 0)
                {
                    if (dgvRoomsList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvRoomsList.CurrentRow.Cells[0].Value);
                                ClassRoomInBranch c = new ClassRoomInBranch();
                                var entry = db.Entry(c);
                                c.ClassRoomId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.ClassRoomInBranch.Attach(c);
                                    db.ClassRoomInBranch.Remove(c);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            
            try
            {
                ep.Clear();
                if (cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnAddBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (tbRoomCode.Text.Length == 0)
                {
                    ep.SetError(tbRoomCode, "Please Enter Room Code.");
                    tbRoomCode.Focus();
                    return;

                }
                if (cbStatus.SelectedIndex == 0)
                {
                    ep.SetError(cbStatus, "Please Select Room Status.");
                    cbStatus.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvRoomsList.CurrentRow.Cells[0].Value);
                    var query = (from c in db.ClassRoomInBranch
                                 from d in db.BranchTable
                                 where d.BranchId == c.BranchId 
                                 select new
                                 {
                                     ID = c.ClassRoomId,
                                     code = c.ClassRoomCode,
                                     branch = d.BranchName
                                 }).ToList();
                    foreach (var item in query)
                    {

                        if (item.ID != int.Parse(ID) && item.branch.ToUpper() == cbBranch.Text.Trim().ToUpper() && item.code == tbRoomCode.Text)
                        {
                            ep.SetError(btnAddBranch, "Already Registered!");
                            cbBranch.Focus();
                            return;
                        }
                    }

                    ClassRoomInBranch b = new ClassRoomInBranch();
                    b.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    b.ClassRoomCode = tbRoomCode.Text.Trim();
                    b.Status = cbStatus.Text.Trim();
                    b.ClassRoomId = int.Parse(ID);
                    db.ClassRoomInBranch.Attach(b);
                    db.Entry(b).State = EntityState.Modified;
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisableControls();


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddBranch_Click(object sender, EventArgs e)
        {
            Form1 b = new Form1();
            b.ShowDialog();
            refreshbranch();
        }

        private void btnRefreshBranch_Click(object sender, EventArgs e)
        {
            refreshbranch();
        }
        void refreshbranch()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Branches = db.BranchTable.ToList();
                Branches.Add(new BranchTable
                {
                    BranchName = "--Select--"

                });
                Branches.Reverse();
                cbBranch.DisplayMember = "BranchName";
                cbBranch.ValueMember = "BranchId";
                cbBranch.DataSource = Branches;
                cbBranch.Refresh();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
