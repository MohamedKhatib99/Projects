﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Branch_Forms
{
    public partial class Communication : Form
    {
        public Communication()
        {
            InitializeComponent();
        }

        private void Communication_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvCommunicationList.DataSource = (from b in db.CommunicationTable
                                                           select new
                                                           {
                                                               ID = b.CommunicationId,
                                                               CommunicationName = b.CommunicationName
                                                           }).ToList();
                        dgvCommunicationList.Columns[0].Width = 100;
                        dgvCommunicationList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvCommunicationList.DataSource = db.CommunicationTable.Where(x => x.CommunicationName.Contains(searchvalue))
                                                        .Select(b => new
                                                        {
                                                            ID = b.CommunicationId,
                                                            CommunicationName = b.CommunicationName
                                                        })
                                                        .ToList();
                        dgvCommunicationList.Columns[0].Width = 100;
                        dgvCommunicationList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {
               
                if (tb_CmmName.Text.Trim() == "")
                {
                    ep.SetError(tb_CmmName, "Please Enter Communication Name.");
                    tb_CmmName.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var query = (from c in db.CommunicationTable
                                 select new
                                 {
                                     Type = c.CommunicationName
                                 }).ToList();
                    foreach (var item in query)
                    {

                        if (item.Type.ToUpper() == tb_CmmName.Text.Trim().ToUpper())
                        {
                            ep.SetError(tb_CmmName, "Already Registered!");
                            tb_CmmName.Focus();
                            return;
                        }
                    }
                    CommunicationTable b = new CommunicationTable();
                    b.CommunicationName = tb_CmmName.Text.Trim();
                    db.CommunicationTable.Add(b);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");


            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void Clear()
        {
            tb_CmmName.Text = "";
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvCommunicationList.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvCommunicationList.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCommunicationList != null && dgvCommunicationList.Rows.Count > 0)
                {
                    if (dgvCommunicationList.SelectedRows.Count == 1)
                    {
                        tb_CmmName.Text = Convert.ToString(dgvCommunicationList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCommunicationList != null && dgvCommunicationList.Rows.Count > 0)
                {
                    if (dgvCommunicationList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvCommunicationList.CurrentRow.Cells[0].Value);
                                CommunicationTable b = new CommunicationTable();
                                var entry = db.Entry(b);
                                b.CommunicationId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.CommunicationTable.Attach(b);
                                    db.CommunicationTable.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {
            
                if (tb_CmmName.Text.Trim() == "")
                {
                    ep.SetError(tb_CmmName, "Please Enter Communication Name.");
                    tb_CmmName.Focus();
                    return;
                }

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvCommunicationList.CurrentRow.Cells[0].Value);
                    var query = (from c in db.CommunicationTable
                                 select new
                                 {
                                     ID = c.CommunicationId,
                                     Name = c.CommunicationName
                                 }).ToList();
                    foreach (var item in query)
                    {

                        if (item.ID != int.Parse(ID) && item.Name.ToUpper() == tb_CmmName.Text.Trim().ToUpper())
                        {
                            ep.SetError(tb_CmmName, "Already Registered!");
                            tb_CmmName.Focus();
                            return;
                        }
                    }

                    CommunicationTable b = new CommunicationTable();
                    b.CommunicationName = tb_CmmName.Text.Trim();
                    b.CommunicationId = int.Parse(ID);
                    db.CommunicationTable.Attach(b);
                    db.Entry(b).State = EntityState.Modified;
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisableControls();


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
