﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DIl_Kursu_Otomasyon.Forms.Branch_Forms;

namespace DIl_Kursu_Otomasyon.Forms.Branch_Forms
{
    public partial class Communication_Branch : Form
    {
        public Communication_Branch()
        {
            InitializeComponent();
        }

        private void Communication_Branch_Load(object sender, EventArgs e)
        {
            try
            {
                if(LoadProfile.UserType != "System Adminstration")
                {
                    btnAddBranch.Enabled = false;
                }
                refreshbranch();
                refreshCommunication();
                FillGrid("");
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgv_Comm_Branch_List.DataSource = (from b in db.CommunicationsBranch
                                                                      from c in db.CommunicationTable
                                                                      from d in db.BranchTable
                                                                      where c.CommunicationId == b.CommunicationId && d.BranchId == b.BranchId
                                                                      select new
                                                                      {
                                                                          ID = b.BranchCoomunicationId,
                                                                          BranchName = d.BranchName,
                                                                          Communication = c.CommunicationName,
                                                                          Description = b.Description
                                                                      }).ToList();
                        dgv_Comm_Branch_List.Columns[0].Width = 100;
                        dgv_Comm_Branch_List.Columns[1].Width = 150;
                        dgv_Comm_Branch_List.Columns[2].Width = 150;
                        dgv_Comm_Branch_List.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgv_Comm_Branch_List.DataSource = (from b in db.CommunicationsBranch
                                                                      from c in db.CommunicationTable
                                                                      from d in db.BranchTable
                                                                      where c.CommunicationId == b.CommunicationId && d.BranchId == b.BranchId && d.BranchName.Contains(searchvalue)
                                                                      select new
                                                                      {
                                                                          ID = b.BranchCoomunicationId,
                                                                          BranchName = d.BranchName,
                                                                          Communication = c.CommunicationName,
                                                                          Description = b.Description
                                                                      }).ToList();
                        dgv_Comm_Branch_List.Columns[0].Width = 100;
                        dgv_Comm_Branch_List.Columns[1].Width = 150;
                        dgv_Comm_Branch_List.Columns[2].Width = 150;
                        dgv_Comm_Branch_List.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cbBranch.SelectedIndex == 0)
            {
                ep.SetError(btnAddBranch, "Please Select Branch.");
                cbBranch.Focus();
                return;
            }
            if (cbCommunication.SelectedIndex == 0)
            {
                ep.SetError(btnAddCommunication, "Please Select Communication.");
                cbCommunication.Focus();
                return;
            }
            if (tbDescription.Text.Length == 0)
            {
                ep.SetError(tbDescription, "Please Enter Description.");
                tbDescription.Focus();
                return;

            }
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var check = db.CommunicationsBranch.Where(x => x.BranchId == int.Parse(cbBranch.SelectedValue.ToString()) && x.CommunicationId == int.Parse(cbCommunication.SelectedValue.ToString())).FirstOrDefault();
                    if (check != null)
                    {
                        ep.SetError(btnAddBranch, "Already Registered.");
                        btnAddBranch.Focus();
                        return;
                    }
                    CommunicationsBranch cb = new CommunicationsBranch();
                    cb.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    cb.CommunicationId = int.Parse(cbCommunication.SelectedValue.ToString());
                    cb.Description = tbDescription.Text.Trim();
                    db.CommunicationsBranch.Add(cb);
                    db.SaveChanges();
                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                FillGrid("");
                Clear();
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgv_Comm_Branch_List.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgv_Comm_Branch_List.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void Clear()
        {
            cbBranch.SelectedIndex = 0;
            cbCommunication.SelectedIndex = 0;
            tbDescription.Text = "";
            ep.Clear();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_Comm_Branch_List != null && dgv_Comm_Branch_List.Rows.Count > 0)
                {
                    if (dgv_Comm_Branch_List.SelectedRows.Count == 1)
                    {
                        cbBranch.Text = Convert.ToString(dgv_Comm_Branch_List.CurrentRow.Cells[1].Value);
                        cbCommunication.Text = Convert.ToString(dgv_Comm_Branch_List.CurrentRow.Cells[2].Value);
                        tbDescription.Text = Convert.ToString(dgv_Comm_Branch_List.CurrentRow.Cells[3].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            try
            {

                if (cbBranch.SelectedIndex == 0)
                {
                    ep.SetError(btnAddBranch, "Please Select Branch.");
                    cbBranch.Focus();
                    return;
                }
                if (cbCommunication.SelectedIndex == 0)
                {
                    ep.SetError(btnAddCommunication, "Please Select Communication.");
                    cbCommunication.Focus();
                    return;
                }
                if (tbDescription.Text.Length == 0)
                {
                    ep.SetError(tbDescription, "Please Enter Description.");
                    tbDescription.Focus();
                    return;

                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgv_Comm_Branch_List.CurrentRow.Cells[0].Value);
                    var check = db.CommunicationsBranch.Where(x => x.BranchId == int.Parse(cbBranch.SelectedValue.ToString()) && x.CommunicationId == int.Parse(cbCommunication.SelectedValue.ToString()) && x.BranchCoomunicationId != int.Parse(ID)).FirstOrDefault();
                    if (check != null)
                    {
                        ep.SetError(btnAddBranch, "Already Registered.");
                        btnAddBranch.Focus();
                        return;
                    }
                    CommunicationsBranch tb = new CommunicationsBranch();
                    tb.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    tb.CommunicationId = int.Parse(cbCommunication.SelectedValue.ToString());
                    tb.Description = tbDescription.Text.Trim();
                    tb.BranchCoomunicationId = int.Parse(ID);
                    db.CommunicationsBranch.Attach(tb);
                    db.Entry(tb).State = EntityState.Modified;
                    db.SaveChanges();

                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisableControls();


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_Comm_Branch_List != null && dgv_Comm_Branch_List.Rows.Count > 0)
                {
                    if (dgv_Comm_Branch_List.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgv_Comm_Branch_List.CurrentRow.Cells[0].Value);
                                CommunicationsBranch b = new CommunicationsBranch();
                                var entry = db.Entry(b);
                                b.BranchCoomunicationId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.CommunicationsBranch.Attach(b);
                                    db.CommunicationsBranch.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnAddBranch_Click(object sender, EventArgs e)
        {
            Form1 b = new Form1();
            b.ShowDialog();
            refreshbranch();
        }

        private void btnAddCommunication_Click(object sender, EventArgs e)
        {
            Communication com = new Communication();
            com.ShowDialog();
            refreshCommunication();
        }

        private void btnRefreshBranch_Click(object sender, EventArgs e)
        {
            refreshbranch();

        }
        void refreshbranch()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Branches = db.BranchTable.ToList();
                Branches.Add(new BranchTable
                {
                    BranchName = "--Select--"

                });
                Branches.Reverse();
                cbBranch.DisplayMember = "BranchName";
                cbBranch.ValueMember = "BranchId";
                cbBranch.DataSource = Branches;
                cbBranch.Refresh();
            }
        }
        private void btnRefreshCommunications_Click(object sender, EventArgs e)
        {
            refreshCommunication();
        }
        void refreshCommunication()
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {

                var Communication = (from d in db.CommunicationTable
                                     select d)
                                  .ToList();
                Communication.Add(new CommunicationTable
                {
                    CommunicationName = "--Select--"

                });
                Communication.Reverse();
                cbCommunication.DisplayMember = "CommunicationName";
                cbCommunication.ValueMember = "CommunicationId";
                cbCommunication.DataSource = Communication;
                cbCommunication.Text = "--Select--";
                cbCommunication.Refresh();


            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
