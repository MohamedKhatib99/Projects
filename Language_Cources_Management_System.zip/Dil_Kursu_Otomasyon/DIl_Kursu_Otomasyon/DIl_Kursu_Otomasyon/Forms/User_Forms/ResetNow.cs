﻿using DIl_Kursu_Otomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.User_Forms
{
    public partial class ResetNow : Form
    {
        UsersTable user;
        ForgetPassword forget;
        public ResetNow(UsersTable user, ForgetPassword forgetPassword)
        {
            InitializeComponent();
            this.user = user;
            this.forget = forgetPassword;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbPassword.Text.Trim() == "")
                {
                    ep.SetError(tbPassword, "Please Enter Your Password.");
                    tbPassword.Focus();
                    return;

                }
                if (tbPassword.Text.Trim().Length < 8 || tbPassword.Text.Trim().Length > 50)
                {
                    ep.SetError(tbPassword, "Password Must Be Between 8 And 50 Characters.");
                    tbPassword.Focus();
                    return;

                }
                if (tbConfirmPassword.Text.Trim() == "")
                {
                    ep.SetError(tbConfirmPassword, "Please Confirm Your Password!");
                    tbConfirmPassword.Focus();


                    return;

                }

                if (tbConfirmPassword.Text.Trim().Length < 8 || tbConfirmPassword.Text.Trim().Length > 50)
                {
                    ep.SetError(tbConfirmPassword, "Password Must Be Between 8 And 50 Characters.");
                    tbConfirmPassword.Focus();
                    return;
                }
                if (tbPassword.Text.Trim() != tbConfirmPassword.Text.Trim())
                {
                    ep.SetError(tbConfirmPassword, "Passwords is not match!");
                    tbConfirmPassword.Focus();
                    return;
                }
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    user.Password = tbPassword.Text.Trim();
                    db.Update(user);
                    db.SaveChanges();

                    MessageBox.Show("Password Reset Succussfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                    forget.Close();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
