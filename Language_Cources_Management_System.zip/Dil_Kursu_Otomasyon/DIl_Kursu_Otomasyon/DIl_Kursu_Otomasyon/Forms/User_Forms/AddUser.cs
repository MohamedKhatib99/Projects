﻿using DIl_Kursu_Otomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.User_Forms
{
    public partial class AddUser : Form
    {
        public AddUser()
        {
            InitializeComponent();
            cbUsertype.SelectedIndex = 0;
            cbGender.SelectedIndex = 0;
        }

        private void AddUser_Load(object sender, EventArgs e)
        {
            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                var Branches = (from d in db.BranchTable
                                select new { d.BranchId, d.BranchName })
                                  .ToList();

                cbBranch.DisplayMember = "BranchName";
                cbBranch.ValueMember = "BranchId";
                cbBranch.DataSource = Branches;
                cbBranch.Text = "--Select--";

            }
            if (LoadProfile.UserType != "System Adminstration")
            {
                cbUsertype.Enabled = false;
                cbUsertype.SelectedIndex = 3;
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cbBranch.Text == "--Select--")
            {
                ep.SetError(cbBranch, "Please Select Branch.");
                cbBranch.Focus();
                return;
            }
            if (cbUsertype.SelectedIndex == 0)
            {
                ep.SetError(cbUsertype, "Please Select User Type.");
                cbUsertype.Focus();
                return;
            }
            if (tbFullName.Text.Length == 0)
            {
                ep.SetError(tbFullName, "Please Enter Your Full Name.");
                tbFullName.Focus();
                return;

            }

            if (tbFullName.Text.Length < 5 || tbFullName.Text.Length > 50)
            {
                ep.SetError(tbFullName, "Full Name Must Be Between 5 And 50 Characters.");
                tbFullName.Focus();
                return;

            }
            if (cbGender.SelectedIndex == 0)
            {
                ep.SetError(cbGender, "Please Select Gender.");
                cbGender.Focus();
                return;
            }
            if (tbContactNo.Text == "")
            {
                ep.SetError(tbContactNo, "Please Enter Your Contact No.");
                tbContactNo.Focus();
                return;

            }
            if (tbContactNo.Text.Length < 5 || tbContactNo.Text.Length > 20)
            {
                ep.SetError(tbContactNo, "Contact No Must Be Between 5 And 20 Characters.");
                tbContactNo.Focus();
                return;

            }
            if (tbEmail.Text == "")
            {
                ep.SetError(tbEmail, "Please Enter Your Email!");
                tbEmail.Focus();
                return;

            }
            if (!tbEmail.Text.Contains('@'))
            {
                ep.SetError(tbEmail, "Wrong Email Format.");
                tbEmail.Focus();
                return;
            }
            if (tbEmail.Text.Length < 8 || tbEmail.Text.Length > 50)
            {
                ep.SetError(tbEmail, "Email Must Be Between 8 And 50 Characters.");
                tbEmail.Focus();
                return;
            }
            if (tbAddress.Text == "")
            {
                ep.SetError(tbAddress, "Please Enter Your Address.");
                tbAddress.Focus();
                return;

            }

            if (tbUserName.Text == "")
            {
                ep.SetError(tbUserName, "Please Enter Your User Name.");
                tbUserName.Focus();
                return;

            }
            if (tbUserName.Text.Length < 5 || tbUserName.Text.Length > 50)
            {
                ep.SetError(tbUserName, "User Name Must Be Between 5 And 50 Characters.");
                tbUserName.Focus();
                return;

            }
            if (tbPassword.Text.Trim() == "")
            {
                ep.SetError(tbPassword, "Please Enter Your Password.");
                tbPassword.Focus();
                return;

            }
            if (tbPassword.Text.Trim().Length < 8 || tbPassword.Text.Trim().Length > 50)
            {
                ep.SetError(tbPassword, "Password Must Be Between 8 And 50 Characters.");
                tbPassword.Focus();
                return;

            }
            if (tbConfirmPassword.Text.Trim() == "")
            {
                ep.SetError(tbConfirmPassword, "Please Confirm Your Password!");
                tbConfirmPassword.Focus();


                return;

            }

            if (tbConfirmPassword.Text.Trim().Length < 8 || tbConfirmPassword.Text.Trim().Length > 50)
            {
                ep.SetError(tbConfirmPassword, "Password Must Be Between 8 And 50 Characters.");
                tbConfirmPassword.Focus();
                return;
            }
            if (tbPassword.Text.Trim() != tbConfirmPassword.Text.Trim())
            {
                ep.SetError(tbConfirmPassword, "Passwords is not match!");
                tbConfirmPassword.Focus();
                return;
            }
            try
            {
                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var query = (from u in db.UsersTable
                                 select new
                                 {
                                     UserName = u.UserName ,
                                     FullName = u.FullName,
                                     Phone = u.ContactNo
                                 }).ToList();
                    foreach (var item in query)
                    {

                        if (item.UserName.ToUpper() == tbUserName.Text.Trim().ToUpper())
                        {
                            ep.SetError(tbUserName, "User Name Already Registered!");
                            tbUserName.Focus();
                            return;
                        }
                        if (item.FullName.ToUpper() == tbFullName.Text.Trim().ToUpper() && item.Phone.ToUpper() == tbContactNo.Text.Trim().ToUpper())
                        {
                            ep.SetError(tbFullName, "User Already Registered!");
                            tbFullName.Focus();
                            return;
                        }

                    }
                    UsersTable us = new UsersTable();
                    us.BranchId = int.Parse(cbBranch.SelectedValue.ToString());
                    us.UserType = cbUsertype.Text.Trim();
                    us.FullName = tbFullName.Text.Trim();
                    us.Gender = cbGender.Text.Trim();
                    us.ContactNo = tbContactNo.Text.Trim();
                    us.Email = tbEmail.Text.Trim();
                    us.Address = tbAddress.Text.Trim();
                    us.UserName = tbUserName.Text.Trim();
                    us.Password = tbPassword.Text.Trim();
                    db.UsersTable.Add(us);
                    db.SaveChanges();
                    MessageBox.Show("Registered Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                this.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        void Clear()
        {
            cbBranch.Text = "--Select--";
            cbUsertype.SelectedIndex = 0;
            cbGender.SelectedIndex = 0;
            tbFullName.Clear();
            tbEmail.Clear();
            tbContactNo.Clear();
            tbAddress.Clear();
            tbUserName.Clear();
            tbPassword.Clear();
            tbConfirmPassword.Clear();
            ep.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
