﻿using DIl_Kursu_Otomasyon.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIl_Kursu_Otomasyon.Forms.Teachers
{
    public partial class Teacherfrm : Form
    {
        public Teacherfrm()
        {
            InitializeComponent();
        }

    

        private void Teacherfrm_Load(object sender, EventArgs e)
        {
            FillGrid("");
            cbGender.SelectedIndex = 0;
            dtpStartDate.Value = DateTime.Today;
        }
        void FillGrid(string searchvalue)
        {
            try
            {

                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
                    {
                        dgvTeachers.DataSource = (from b in db.TeachersTable
                                                  select new
                                                  {
                                                      ID = b.TeacherId,
                                                      StartDate = b.StartingDate,
                                                      FullName = b.TeacherName,
                                                      Gender = b.Gender,
                                                      GSM = b.Gsm,
                                                      MobilePhone = b.Phone,
                                                      Address = b.Address
                                                  }).ToList();
                        dgvTeachers.Columns[0].Width = 100;
                        dgvTeachers.Columns[1].Width = 100;
                        dgvTeachers.Columns[2].Width = 130;
                        dgvTeachers.Columns[3].Width = 130;
                        dgvTeachers.Columns[4].Width = 130;
                        dgvTeachers.Columns[5].Width = 130;
                        dgvTeachers.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                    else
                    {
                        dgvTeachers.DataSource = (from b in db.TeachersTable
                                                  where b.TeacherName.Contains(searchvalue)
                                                  select new
                                                  {
                                                      ID = b.TeacherId,
                                                      StartDate = b.StartingDate,
                                                      FullName = b.TeacherName,
                                                      Gender = b.Gender,
                                                      GSM = b.Gsm,
                                                      MobilePhone = b.Phone,
                                                      Address = b.Address
                                                  }).ToList();
                        dgvTeachers.Columns[0].Width = 100;
                        dgvTeachers.Columns[1].Width = 100;
                        dgvTeachers.Columns[2].Width = 130;
                        dgvTeachers.Columns[3].Width = 130;
                        dgvTeachers.Columns[4].Width = 130;
                        dgvTeachers.Columns[5].Width = 130;
                        dgvTeachers.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void Clear()
        {
            tbAddress.Clear();
            tbFullName.Clear();
            tbGsm.Clear();
            tbMobilePhone.Clear();
            cbGender.SelectedIndex = 0;
            ep.Clear();
            dtpStartDate.Value = DateTime.Today;


        }
        private void EnableControls()
        {
            btnedit.Enabled = true;
            btncancel.Enabled = true;
            btnsave.Enabled = false;
            dgvTeachers.Enabled = false;
            tbsearch.Enabled = false;

        }
        private void DisableControls()
        {
            btnedit.Enabled = false;
            btncancel.Enabled = false;
            btnsave.Enabled = true;
            dgvTeachers.Enabled = true;
            tbsearch.Enabled = true;
            FillGrid("");
            Clear();

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (tbFullName.Text.Trim().Length == 0)
                {
                    ep.SetError(tbFullName, "Please Enter Full Name.");
                    tbFullName.Focus();
                    return;
                }
                if (cbGender.SelectedIndex == 0)
                {
                    ep.SetError(cbGender, "Please Select Gender.");
                    cbGender.Focus();
                    return;

                }
                if (dtpStartDate.Checked != true)
                {
                    ep.SetError(dtpStartDate, "Please Select Start Date.");
                    dtpStartDate.Focus();
                    return;
                }
                if (tbGsm.Text.Trim().Length == 0)
                {
                    ep.SetError(tbGsm, "Please Enter GSM Number.");
                    tbGsm.Focus();
                    return;
                }
                if (tbMobilePhone.Text.Trim().Length == 0)
                {
                    ep.SetError(tbMobilePhone, "Please Mobile Phone Number.");
                    tbMobilePhone.Focus();
                    return;

                }
                if (tbAddress.Text == "")
                {
                    ep.SetError(tbAddress, "Please Enter Address.");
                    tbAddress.Focus();
                    return;
                }


                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    var result = db.TeachersTable.Where(x => x.TeacherName.ToLower() == tbFullName.Text.Trim().ToLower() && x.Phone == tbMobilePhone.Text.Trim()).FirstOrDefault();

                    if (result != null)
                    {
                        ep.SetError(tbFullName, "Teacher Already Registered!");
                        tbFullName.Focus();
                        return;
                    }
                    TeachersTable c = new TeachersTable();
                    c.TeacherName = tbFullName.Text.Trim();
                    c.Gender = cbGender.Text;
                    c.StartingDate = dtpStartDate.Value;
                    c.Gsm = tbGsm.Text.Trim();
                    c.Phone = tbMobilePhone.Text.Trim();
                    c.Address = tbAddress.Text.Trim();
                    db.TeachersTable.Add(c);

                    db.SaveChanges();

                    MessageBox.Show("Saved Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (tbFullName.Text.Trim().Length == 0)
                {
                    ep.SetError(tbFullName, "Please Enter Full Name.");
                    tbFullName.Focus();
                    return;
                }
                if (cbGender.SelectedIndex == 0)
                {
                    ep.SetError(cbGender, "Please Select Gender.");
                    cbGender.Focus();
                    return;

                }
                if (dtpStartDate.Checked != true)
                {
                    ep.SetError(dtpStartDate, "Please Select Start Date.");
                    dtpStartDate.Focus();
                    return;
                }
                if (tbGsm.Text.Trim().Length == 0)
                {
                    ep.SetError(tbGsm, "Please Enter GSM Number.");
                    tbGsm.Focus();
                    return;
                }
                if (tbMobilePhone.Text.Trim().Length == 0)
                {
                    ep.SetError(tbMobilePhone, "Please Mobile Phone Number.");
                    tbMobilePhone.Focus();
                    return;

                }
                if (tbAddress.Text == "")
                {
                    ep.SetError(tbAddress, "Please Enter Address.");
                    tbAddress.Focus();
                    return;
                }


                using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                {
                    string ID = Convert.ToString(dgvTeachers.CurrentRow.Cells[0].Value);
                    var result = db.TeachersTable.Where(x => x.TeacherName.ToLower() == tbFullName.Text.Trim().ToLower() && x.Phone == tbMobilePhone.Text.Trim() && x.TeacherId != int.Parse(ID)).FirstOrDefault();

                    if (result != null)
                    {
                        ep.SetError(tbFullName, "Teacher Already Registered!");
                        tbFullName.Focus();
                        return;
                    }
                    TeachersTable c = new TeachersTable();
                    c.TeacherName = tbFullName.Text.Trim();
                    c.Gender = cbGender.Text;
                    c.StartingDate = dtpStartDate.Value;
                    c.Gsm = tbGsm.Text.Trim();
                    c.Phone = tbMobilePhone.Text.Trim();
                    c.Address = tbAddress.Text.Trim();
                    c.TeacherId = int.Parse(ID);
                    db.Entry(c).State = EntityState.Modified;
                    db.SaveChanges();
                    DisableControls();
                    MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Clear();
                FillGrid("");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvTeachers != null && dgvTeachers.Rows.Count > 0)
            {
                if (dgvTeachers.SelectedRows.Count == 1)
                {
                    dtpStartDate.Value = DateTime.Parse(Convert.ToString(dgvTeachers.CurrentRow.Cells[1].Value));
                    tbFullName.Text = (Convert.ToString(dgvTeachers.CurrentRow.Cells[2].Value));
                    cbGender.Text = Convert.ToString(dgvTeachers.CurrentRow.Cells[3].Value);
                    tbGsm.Text = Convert.ToString(dgvTeachers.CurrentRow.Cells[4].Value);
                    tbMobilePhone.Text = Convert.ToString(dgvTeachers.CurrentRow.Cells[5].Value);
                    tbAddress.Text = Convert.ToString(dgvTeachers.CurrentRow.Cells[6].Value);

                    EnableControls();
                }
                else
                {
                    MessageBox.Show("Please Select One Record.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTeachers != null && dgvTeachers.Rows.Count > 0)
                {
                    if (dgvTeachers.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
                            {

                                string ID = Convert.ToString(dgvTeachers.CurrentRow.Cells[0].Value);
                                TeachersTable b = new TeachersTable();
                                var entry = db.Entry(b);
                                b.TeacherId = int.Parse(ID);
                                if (entry.State == EntityState.Detached)
                                {
                                    db.TeachersTable.Attach(b);
                                    db.TeachersTable.Remove(b);
                                    db.SaveChanges();
                                    MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    FillGrid("");

                                }
                                else
                                {
                                    MessageBox.Show("Unexpected Error Occure! , Please Contact To Concern Person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("List is Empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void tbsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(tbsearch.Text);
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
