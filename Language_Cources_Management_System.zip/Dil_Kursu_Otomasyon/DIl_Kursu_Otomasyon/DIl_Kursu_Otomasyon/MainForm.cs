﻿using DIl_Kursu_Otomasyon.Forms.User_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DIl_Kursu_Otomasyon.Forms.Branch_Forms;
using DIl_Kursu_Otomasyon.Model;
using DIl_Kursu_Otomasyon.Forms.Student;
using DIl_Kursu_Otomasyon.Forms.Course;
using DIl_Kursu_Otomasyon.Forms.Teachers;
using DIl_Kursu_Otomasyon.Forms.Branch_Forms.Course;
using DIl_Kursu_Otomasyon.Forms.Payment_Forms;

namespace DIl_Kursu_Otomasyon
{
    public partial class MainForm : Form
    {
        Login ln;
        public MainForm()
        {
            using(Dil_Kursu_Otomasyon_DBContext db = new Dil_Kursu_Otomasyon_DBContext())
            {
                db.BranchTable.ToList();
            }
            InitializeComponent();
        }
        private void tsblogin_Click(object sender, EventArgs e)
        {
            ln = new Login(this,lblwelcome,lbl1);
            ln.ShowDialog();
        }

        private void logOutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure you want to logout ?","Question",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                lblwelcome.Text = "";
                this.lbl1.Location = new System.Drawing.Point(17, 35);

                this.tsblogin.Visible = true;
                this.tsblogout.Visible = false;
                this.msAll.Enabled = false;
                ln.ShowDialog();
            }
      
            
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
       
            tsblogin.Visible = true;
            tsblogout.Visible = false;
            msAll.Enabled = false;
        }

        private void addUserTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Users au = new Users();
            au.ShowDialog();
        }

       

        private void tsblogout_ButtonClick(object sender, EventArgs e)
        {

            if (MessageBox.Show("Are you sure you want to logout ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                lblwelcome.Text = "";
                this.lbl1.Location = new System.Drawing.Point(17, 35);

                this.tsblogin.Visible = true;
                this.tsblogout.Visible = false;
                this.msAll.Enabled = false;
                ln.ShowDialog();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Exit ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                lblwelcome.Text = "";
                this.lbl1.Location = new System.Drawing.Point(17, 35);
                this.tsblogin.Visible = true;
                this.tsblogout.Visible = false;
                this.msAll.Enabled = false;
                ln.ShowDialog();
            }
        }

        private void UpdateProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateUser us = new UpdateUser();
            us.ShowDialog();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 b = new Form1();
            b.ShowDialog();
        }

        private void addTransportationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Transportation t = new Transportation();
            t.ShowDialog();
        }

        private void addTransportationsToBranchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Transportation_Branch tb = new Transportation_Branch();
            tb.ShowDialog();
        }

        private void addRoomToBranchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Class_Room cr = new Class_Room();
            cr.ShowDialog();
        }

        private void addLevelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Level l = new Level();
            l.ShowDialog();
        }

        private void addLanguageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Language l = new Language();
            l.ShowDialog();
        }

        private void addCommunicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Communication com = new Communication();
            com.ShowDialog();
        }

        private void addCommunicationsToBranchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Communication_Branch cb = new Communication_Branch();
            cb.ShowDialog();
        }

        private void addTeacherToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Teacherfrm t = new Teacherfrm();
            t.ShowDialog();
        }

        private void addLanguagesToTeacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Teacher_Languages tl = new Teacher_Languages();
            tl.ShowDialog();
        }

        private void teachersSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addBranchsToTeacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Teacher_Branchs tb = new Teacher_Branchs();
            tb.ShowDialog();

        }

        private void addCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Course c = new Course();
            c.ShowDialog();
        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Students s = new Students();
            s.ShowDialog();
        }

        private void paymentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Payment p = new Payment();
            p.ShowDialog();
        }

        private void teachersWorkingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Teachers_Work_Days c = new Teachers_Work_Days();
            c.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            exitToolStripMenuItem_Click(sender,e);
        }

        private void logoutToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            logOutToolStripMenuItem_Click(sender, e);
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            exitToolStripMenuItem_Click(sender, e);
        }
    }
}
